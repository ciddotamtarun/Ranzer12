/// <reference types="vite/client" />

interface ImportMetaEnv {
  /** Optional absolute API origin when the frontend is hosted apart from the API. Empty = same origin. */
  readonly VITE_API_URL?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
