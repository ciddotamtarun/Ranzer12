import type {
  User,
  Merchant,
  Product,
  Customer,
  Order,
  Transaction,
  Payment,
  AIInsight,
  AgentTask,
  Approval,
  AuditLog,
  CartItem,
  ChartPoint,
  DashboardMetrics,
  LiveAnalytics,
  Pagination,
} from '../types/index.ts';

const TOKEN_KEY = 'razorgrowth_auth_token';

// Same-origin by default: on Vercel the API lives at /api on the same domain,
// and in development Vite proxies /api to the local Express server. Set
// VITE_API_URL only if the frontend is hosted separately from the API.
const API_BASE = (import.meta.env.VITE_API_URL ?? '').replace(/\/+$/, '');

// localStorage can be unavailable (private mode, blocked storage); fail soft.
export function getStoredToken(): string | null {
  try {
    return localStorage.getItem(TOKEN_KEY);
  } catch {
    return null;
  }
}

export function setStoredToken(token: string): void {
  try {
    localStorage.setItem(TOKEN_KEY, token);
  } catch {
    // ignore: the session will simply not survive a reload
  }
}

export function removeStoredToken(): void {
  try {
    localStorage.removeItem(TOKEN_KEY);
  } catch {
    // ignore
  }
}

/** Error thrown for non-2xx API responses. */
export class ApiError extends Error {
  readonly status: number;
  readonly code?: string;

  constructor(status: number, message: string, code?: string) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.code = code;
  }
}

// Lets AuthContext react when the server rejects the stored session
// (expired/revoked token) so the user is returned to the sign-in screen.
let unauthorizedHandler: (() => void) | null = null;
export function setUnauthorizedHandler(handler: (() => void) | null): void {
  unauthorizedHandler = handler;
}

type QueryValue = string | number | boolean | null | undefined;

/** Builds a query string, skipping undefined/null/empty values. */
function toQuery(params?: Record<string, QueryValue>): string {
  if (!params) return '';
  const search = new URLSearchParams();
  for (const [key, value] of Object.entries(params)) {
    if (value === undefined || value === null || value === '') continue;
    search.set(key, String(value));
  }
  const query = search.toString();
  return query ? `?${query}` : '';
}

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const token = getStoredToken();
  const headers: Record<string, string> = {
    ...((options.headers as Record<string, string>) || {}),
  };
  if (options.body !== undefined) headers['Content-Type'] = 'application/json';
  if (token) headers['Authorization'] = `Bearer ${token}`;

  let response: Response;
  try {
    response = await fetch(`${API_BASE}${endpoint}`, { ...options, headers });
  } catch {
    throw new ApiError(0, 'Cannot reach the server. Check your connection and try again.', 'NETWORK_ERROR');
  }

  let data: unknown = null;
  const text = await response.text();
  if (text) {
    try {
      data = JSON.parse(text);
    } catch {
      data = null;
    }
  }

  if (!response.ok) {
    const body = (data ?? {}) as { error?: string; message?: string; code?: string };
    const message =
      body.error ||
      body.message ||
      (response.status === 429
        ? 'Too many requests. Please wait a moment and try again.'
        : response.status >= 500
          ? 'The server encountered an error. Please try again.'
          : `Request failed (HTTP ${response.status}).`);
    if (response.status === 401 && token && !endpoint.startsWith('/api/auth/login')) {
      unauthorizedHandler?.();
    }
    throw new ApiError(response.status, message, body.code);
  }

  return data as T;
}

const json = (body: unknown): RequestInit => ({ method: 'POST', body: JSON.stringify(body) });

export const api = {
  // Auth
  auth: {
    signup: (data: { name: string; email: string; password: string; merchantName: string; currency?: string }) =>
      request<{ token: string; user: User; merchant: Merchant }>('/api/auth/signup', json(data)),
    login: (data: { email: string; password: string }) =>
      request<{ token: string; user: User; merchant: Merchant }>('/api/auth/login', json(data)),
    me: () => request<{ user: User; merchant: Merchant }>('/api/auth/me'),
    logout: () => request<{ message: string }>('/api/auth/logout', { method: 'POST' }),
  },

  // Dashboard
  dashboard: {
    getStats: () =>
      request<{
        metrics: DashboardMetrics;
        recentTransactions: Transaction[];
        recentOrders: Order[];
        chartData: ChartPoint[];
      }>('/api/dashboard/stats'),
  },

  // Products
  products: {
    list: (params?: { category?: string; search?: string; status?: string; limit?: number; offset?: number }) =>
      request<{ products: Product[]; pagination: Pagination }>(`/api/products${toQuery(params)}`),
    get: (id: string) => request<{ product: Product }>(`/api/products/${encodeURIComponent(id)}`),
    create: (data: Partial<Product>) => request<{ product: Product }>('/api/products', json(data)),
    update: (id: string, data: Partial<Product>) =>
      request<{ product: Product }>(`/api/products/${encodeURIComponent(id)}`, { method: 'PUT', body: JSON.stringify(data) }),
    delete: (id: string) => request<{ message: string }>(`/api/products/${encodeURIComponent(id)}`, { method: 'DELETE' }),
  },

  // Customers
  customers: {
    list: (params?: { search?: string; status?: string; limit?: number; offset?: number }) =>
      request<{ customers: Customer[]; pagination: Pagination }>(`/api/customers${toQuery(params)}`),
    create: (data: { name: string; email: string; phone?: string; status?: Customer['status'] }) =>
      request<{ customer: Customer }>('/api/customers', json(data)),
    update: (id: string, data: Partial<Pick<Customer, 'name' | 'email' | 'phone' | 'status'>>) =>
      request<{ customer: Customer }>(`/api/customers/${encodeURIComponent(id)}`, { method: 'PUT', body: JSON.stringify(data) }),
    delete: (id: string) => request<{ message: string }>(`/api/customers/${encodeURIComponent(id)}`, { method: 'DELETE' }),
  },

  // Orders
  orders: {
    list: (params?: { status?: string; search?: string; limit?: number; offset?: number }) =>
      request<{ orders: Order[]; pagination: Pagination }>(`/api/orders${toQuery(params)}`),
    get: (id: string) => request<{ order: Order; transactions: Transaction[] }>(`/api/orders/${encodeURIComponent(id)}`),
    create: (data: {
      customerId?: string;
      customerName: string;
      customerEmail: string;
      items: Array<{ productId: string; quantity?: number } | { title: string; price: number; quantity?: number }>;
    }) => request<{ order: Order }>('/api/orders', json(data)),
    cancel: (id: string) =>
      request<{ order: Order }>(`/api/orders/${encodeURIComponent(id)}`, { method: 'PATCH', body: JSON.stringify({ status: 'CANCELLED' }) }),
  },

  // Transactions
  transactions: {
    list: (params?: { status?: string; orderId?: string; limit?: number; offset?: number }) =>
      request<{ transactions: Transaction[]; pagination: Pagination }>(`/api/transactions${toQuery(params)}`),
  },

  // Payments
  payments: {
    create: (data: { orderId: string; method?: string }) =>
      request<{ payment: Payment; order: Order }>('/api/payments/create', json(data)),
    simulate: (data: {
      paymentId?: string;
      orderId?: string;
      outcome: 'SUCCESS' | 'FAILURE';
      failureReason?: string;
      paymentMethod?: string;
      clientSecret?: string;
    }) =>
      request<{
        success: boolean;
        status: string;
        message: string;
        order: Order;
        payment: Payment;
        transaction: Transaction;
      }>('/api/payments/simulate', json(data)),
  },

  // AI Insights
  ai: {
    getInsights: () => request<{ insights: AIInsight[]; liveAnalytics: LiveAnalytics }>('/api/ai/insights'),
    generateOpportunity: (focusArea?: string) =>
      request<{ insight: AIInsight; agentTask: AgentTask; approval: Approval }>(
        '/api/ai/generate-opportunity',
        json(focusArea ? { focusArea } : {})
      ),
  },

  // Agents
  agents: {
    list: () => request<{ agentTasks: AgentTask[] }>('/api/agents'),
    run: (data: { agentType: string; title: string; triggerReason?: string; proposedAction: string; impactMetric?: string }) =>
      request<{ agentTask: AgentTask; approval: Approval }>('/api/agents/run', json(data)),
  },

  // Approvals
  approvals: {
    list: (params?: { status?: string }) => request<{ approvals: Approval[] }>(`/api/approvals${toQuery(params)}`),
    decide: (id: string, data: { decision: 'APPROVE' | 'REJECT'; notes?: string }) =>
      request<{
        success: boolean;
        decision: string;
        message: string;
        approval: Approval;
        agentTask: AgentTask;
      }>(`/api/approvals/${encodeURIComponent(id)}/decide`, json(data)),
  },

  // Audit Logs
  auditLogs: {
    list: (params?: { action?: string; entityType?: string; limit?: number; offset?: number }) =>
      request<{ auditLogs: AuditLog[]; pagination: Pagination }>(`/api/audit-logs${toQuery(params)}`),
  },

  // System
  system: {
    health: () => request<{ status: string; database: string; timestamp: string }>('/api/health'),
  },

  // AI Buyer Storefront & Cart (public endpoints, scoped by merchantId + session)
  buyer: {
    search: (data: { merchantId: string; query?: string; maxPrice?: number; category?: string }) =>
      request<{
        results: Product[];
        query: string;
        totalMatches: number;
        extractedMaxPrice?: number | null;
      }>('/api/buyer/search', json(data)),
    compare: (data: { merchantId: string; productIds: string[] }) =>
      request<{ products: Product[] }>('/api/buyer/compare', json(data)),
    checkout: (data: {
      merchantId: string;
      customerName: string;
      customerEmail: string;
      customerPhone?: string;
      items: Array<{ productId: string; quantity: number }>;
      sessionId?: string;
    }) => request<{ order: Order; payment: Payment; message: string }>('/api/buyer/checkout', json(data)),
    getCart: (merchantId: string, sessionId: string) =>
      request<{ items: CartItem[] }>(`/api/cart${toQuery({ merchantId, sessionId })}`),
    addToCart: (data: { merchantId: string; sessionId: string; productId: string; quantity?: number }) =>
      request<{ items: CartItem[]; message: string }>('/api/cart/items', json(data)),
    updateCartItem: (productId: string, data: { merchantId: string; sessionId: string; quantity: number }) =>
      request<{ items: CartItem[] }>(`/api/cart/items/${encodeURIComponent(productId)}`, {
        method: 'PUT',
        body: JSON.stringify(data),
      }),
    removeCartItem: (productId: string, merchantId: string, sessionId: string) =>
      request<{ items: CartItem[]; message: string }>(
        `/api/cart/items/${encodeURIComponent(productId)}${toQuery({ merchantId, sessionId })}`,
        { method: 'DELETE' }
      ),
    clearCart: (merchantId: string, sessionId: string) =>
      request<{ items: CartItem[]; message: string }>(`/api/cart${toQuery({ merchantId, sessionId })}`, {
        method: 'DELETE',
      }),
  },
};
