import React, { useState, useEffect, useCallback } from 'react';
import { AuthProvider } from './context/AuthContext.tsx';
import { useAuth } from './context/useAuth.ts';
import { Navbar } from './components/Navbar.tsx';
import { Sidebar } from './components/Sidebar.tsx';
import { DashboardPage } from './pages/DashboardPage.tsx';
import { ProductsPage } from './pages/ProductsPage.tsx';
import { CustomersPage } from './pages/CustomersPage.tsx';
import { OrdersPage } from './pages/OrdersPage.tsx';
import { TransactionsPage } from './pages/TransactionsPage.tsx';
import { AIGrowthPage } from './pages/AIGrowthPage.tsx';
import { AgentCenterPage } from './pages/AgentCenterPage.tsx';
import { ApprovalsPage } from './pages/ApprovalsPage.tsx';
import { AuditLogsPage } from './pages/AuditLogsPage.tsx';
import { AIBuyerPage } from './pages/AIBuyerPage.tsx';
import { AuthPage } from './pages/AuthPage.tsx';
import { api } from './api/client.ts';
import { RefreshCw } from 'lucide-react';

const MainApp: React.FC = () => {
  const { isAuthenticated, isLoading, merchant } = useAuth();
  const [currentView, setCurrentView] = useState<string>('dashboard');
  const [pendingApprovalsCount, setPendingApprovalsCount] = useState<number>(0);
  const [activeOpportunitiesCount, setActiveOpportunitiesCount] = useState<number>(0);
  const [badgeVersion, setBadgeVersion] = useState<number>(0);

  // Pages call this after actions that change approval/insight counts.
  const fetchBadges = useCallback(() => setBadgeVersion((v) => v + 1), []);

  useEffect(() => {
    if (!isAuthenticated) return;
    let cancelled = false;
    Promise.all([
      api.approvals.list({ status: 'PENDING' }).catch(() => ({ approvals: [] })),
      api.ai.getInsights().catch(() => ({ insights: [] }))
    ]).then(([appRes, aiRes]) => {
      if (cancelled) return;
      setPendingApprovalsCount(appRes.approvals.filter((a) => a.status === 'PENDING').length);
      setActiveOpportunitiesCount(aiRes.insights.filter((i) => i.status === 'ACTIVE').length);
    });
    return () => {
      cancelled = true;
    };
  }, [isAuthenticated, merchant?.id, currentView, badgeVersion]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center text-slate-400">
        <div className="flex items-center space-x-3">
          <RefreshCw className="w-6 h-6 animate-spin text-blue-500" />
          <span className="text-sm font-medium">Connecting to RazorGrowth AI Kernel...</span>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <AuthPage />;
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      <Navbar currentView={currentView} onNavigate={setCurrentView} />

      <div className="flex-1 flex overflow-hidden">
        {/* If user is in AI Buyer Storefront mode, show full-width storefront */}
        {currentView === 'buyer' ? (
          <AIBuyerPage onNavigate={setCurrentView} onRefreshStats={fetchBadges} />
        ) : (
          <>
            <Sidebar
              currentView={currentView}
              onNavigate={setCurrentView}
              pendingApprovalsCount={pendingApprovalsCount}
              activeOpportunitiesCount={activeOpportunitiesCount}
            />

            <main className="flex-1 flex overflow-hidden bg-slate-950">
              {currentView === 'dashboard' && <DashboardPage onNavigate={setCurrentView} />}
              {currentView === 'products' && <ProductsPage />}
              {currentView === 'customers' && <CustomersPage />}
              {currentView === 'orders' && <OrdersPage onRefreshStats={fetchBadges} />}
              {currentView === 'transactions' && <TransactionsPage />}
              {currentView === 'ai-growth' && <AIGrowthPage onNavigate={setCurrentView} />}
              {currentView === 'agents' && <AgentCenterPage onNavigate={setCurrentView} />}
              {currentView === 'approvals' && <ApprovalsPage onRefreshStats={fetchBadges} />}
              {currentView === 'audit-logs' && <AuditLogsPage />}
            </main>
          </>
        )}
      </div>
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}
