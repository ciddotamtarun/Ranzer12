import { useCallback, useEffect, useState } from 'react';

interface ResourceState<T> {
  data: T | undefined;
  error: Error | null;
  /** The loader + reload version this state belongs to. */
  loader: (() => Promise<T>) | null;
  version: number;
}

/**
 * Loads data for a component and keeps it in sync with the loader's inputs.
 *
 * - Pass a loader memoised with useCallback; whenever its dependencies change
 *   (e.g. a filter), the data is re-fetched.
 * - Responses that arrive after the inputs changed are ignored, so a slow
 *   earlier request can never overwrite newer results.
 * - `isLoading` is derived, not stored, so it is always accurate.
 */
export function useAsyncResource<T>(loader: () => Promise<T>) {
  const [version, setVersion] = useState(0);
  const [state, setState] = useState<ResourceState<T>>({ data: undefined, error: null, loader: null, version: -1 });

  useEffect(() => {
    let cancelled = false;
    loader().then(
      (data) => {
        if (!cancelled) setState({ data, error: null, loader, version });
      },
      (err: unknown) => {
        if (cancelled) return;
        console.error('Failed to load data:', err);
        setState((prev) => ({
          data: prev.data,
          error: err instanceof Error ? err : new Error(String(err)),
          loader,
          version,
        }));
      }
    );
    return () => {
      cancelled = true;
    };
  }, [loader, version]);

  const reload = useCallback(() => setVersion((v) => v + 1), []);
  const isLoading = state.loader !== loader || state.version !== version;

  return { data: state.data, error: state.error, isLoading, reload };
}
