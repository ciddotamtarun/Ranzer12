import { createContext } from 'react';
import type { User, Merchant } from '../types/index.ts';

export interface AuthContextType {
  user: User | null;
  merchant: Merchant | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<void>;
  signup: (data: { name: string; email: string; password: string; merchantName: string; currency?: string }) => Promise<void>;
  logout: () => void;
  refreshAuth: () => Promise<void>;
}

export const AuthContext = createContext<AuthContextType | undefined>(undefined);
