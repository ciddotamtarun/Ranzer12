import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { AuthContext, type AuthContextType } from './auth-context.ts';
import type { User, Merchant } from '../types/index.ts';
import { api, getStoredToken, setStoredToken, removeStoredToken, setUnauthorizedHandler } from '../api/client.ts';

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [merchant, setMerchant] = useState<Merchant | null>(null);
  // Only show the loading screen when there is a stored session to restore.
  const [isLoading, setIsLoading] = useState<boolean>(() => Boolean(getStoredToken()));

  const clearSession = useCallback(() => {
    removeStoredToken();
    setUser(null);
    setMerchant(null);
  }, []);

  // Restores the session after a page refresh by validating the stored token.
  const refreshAuth = useCallback(async () => {
    if (!getStoredToken()) {
      clearSession();
      setIsLoading(false);
      return;
    }
    try {
      const data = await api.auth.me();
      setUser(data.user);
      setMerchant(data.merchant);
    } catch (err) {
      console.error('Session expired or invalid token:', err);
      clearSession();
    } finally {
      setIsLoading(false);
    }
  }, [clearSession]);

  useEffect(() => {
    if (!getStoredToken()) return;
    let cancelled = false;
    api.auth
      .me()
      .then((data) => {
        if (cancelled) return;
        setUser(data.user);
        setMerchant(data.merchant);
      })
      .catch((err: unknown) => {
        if (cancelled) return;
        console.error('Session expired or invalid token:', err);
        clearSession();
      })
      .finally(() => {
        if (!cancelled) setIsLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [clearSession]);

  // If any API call reports the session is no longer valid, sign out locally.
  useEffect(() => {
    setUnauthorizedHandler(clearSession);
    return () => setUnauthorizedHandler(null);
  }, [clearSession]);

  const login = useCallback(async (email: string, password: string) => {
    const data = await api.auth.login({ email, password });
    setStoredToken(data.token);
    setUser(data.user);
    setMerchant(data.merchant);
  }, []);

  const signup = useCallback(
    async (signupData: { name: string; email: string; password: string; merchantName: string; currency?: string }) => {
      const data = await api.auth.signup(signupData);
      setStoredToken(data.token);
      setUser(data.user);
      setMerchant(data.merchant);
    },
    []
  );

  const logout = useCallback(() => {
    // Best effort: record the sign-out server-side, then drop the token locally.
    api.auth.logout().catch(() => undefined);
    clearSession();
  }, [clearSession]);

  const contextValue = useMemo<AuthContextType>(
    () => ({
      user,
      merchant,
      isLoading,
      isAuthenticated: !!user && !!merchant,
      login,
      signup,
      logout,
      refreshAuth,
    }),
    [user, merchant, isLoading, login, signup, logout, refreshAuth]
  );

  return <AuthContext.Provider value={contextValue}>{children}</AuthContext.Provider>;
};
