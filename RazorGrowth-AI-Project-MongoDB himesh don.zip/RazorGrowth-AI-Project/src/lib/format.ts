/**
 * Short, human-friendly reference for a MongoDB ObjectId.
 *
 * ObjectIds created in the same second share their leading characters
 * (timestamp + process id), so the unique part is the tail.
 */
export function shortId(id: string | null | undefined, length = 10): string {
  if (!id) return '';
  return id.slice(-length);
}
