import React, { useCallback, useState } from 'react';
import { api } from '../api/client.ts';
import type { Order } from '../types/index.ts';
import { useAsyncResource } from '../hooks/useAsyncResource.ts';
import { LoadError } from '../components/LoadError.tsx';
import { useDebouncedValue } from '../hooks/useDebouncedValue.ts';
import { shortId } from '../lib/format.ts';
import {
  ShoppingBag,
  Search,
  RefreshCw,
  Eye,
  CreditCard,
  CheckCircle2,
  AlertTriangle,
  Clock,
  XCircle
} from 'lucide-react';

interface OrdersPageProps {
  onRefreshStats?: () => void;
}

const errorMessage = (err: unknown) => (err instanceof Error ? err.message : String(err));

export const OrdersPage: React.FC<OrdersPageProps> = ({ onRefreshStats }) => {
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [paymentModalOrder, setPaymentModalOrder] = useState<Order | null>(null);
  const [isSimulating, setIsSimulating] = useState<boolean>(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  const debouncedSearch = useDebouncedValue(searchTerm);
  const loadOrders = useCallback(
    () => api.orders.list({ search: debouncedSearch || undefined, status: statusFilter || undefined }),
    [debouncedSearch, statusFilter]
  );
  const { data, error: loadError, isLoading, reload: fetchOrders } = useAsyncResource(loadOrders);
  const orders: Order[] = data?.orders ?? [];

  const handleSimulatePayment = async (orderId: string, outcome: 'SUCCESS' | 'FAILURE') => {
    setIsSimulating(true);
    try {
      const res = await api.payments.simulate({
        orderId,
        outcome,
        failureReason: outcome === 'FAILURE' ? '3D Secure authentication timeout / Insufficient balance' : undefined,
        paymentMethod: outcome === 'SUCCESS' ? 'Visa ending in 4242' : 'Mastercard ending in 8812'
      });

      if (res.success) {
        setFeedback(`Payment SUCCEEDED for Order #${shortId(orderId)}. Order is now PAID!`);
      } else {
        setFeedback(`Payment FAILED for Order #${shortId(orderId)}. Reason: ${res.message}`);
      }

      setPaymentModalOrder(null);
      fetchOrders();
      if (onRefreshStats) onRefreshStats();
    } catch (err) {
      alert(`Simulation Error: ${errorMessage(err)}`);
    } finally {
      setIsSimulating(false);
    }
  };

  const handleCancelOrder = async (order: Order) => {
    if (!confirm(`Cancel order #${shortId(order.id)}? A cancelled order can no longer be paid.`)) return;
    try {
      await api.orders.cancel(order.id);
      setFeedback(`Order #${shortId(order.id)} cancelled.`);
      fetchOrders();
      if (onRefreshStats) onRefreshStats();
    } catch (err) {
      alert(`Could not cancel order: ${errorMessage(err)}`);
    }
  };

  return (
    <div className="flex-1 p-6 space-y-6 overflow-y-auto">
      <LoadError error={loadError} onRetry={fetchOrders} what="orders" />
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            Orders & Checkout Fulfillment
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20">
              {orders.length} Orders
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Live orders generated through merchant checkout and consumer AI Buyer flows.
          </p>
        </div>

        <button
          onClick={fetchOrders}
          className="flex items-center space-x-1.5 px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-300 border border-slate-700 transition-colors self-start sm:self-auto"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
          <span>Refresh Orders</span>
        </button>
      </div>

      {feedback && (
        <div className="p-3 rounded-xl bg-blue-500/10 border border-blue-500/20 text-blue-300 text-xs flex items-center justify-between animate-in fade-in">
          <span>{feedback}</span>
          <button onClick={() => setFeedback(null)} className="text-blue-400 font-bold ml-4">
            ×
          </button>
        </div>
      )}

      {/* Filter Bar */}
      <div className="flex flex-col sm:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search by order ID, customer name or email..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-blue-500"
          />
        </div>

        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="w-full sm:w-48 py-2 px-3 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-200 focus:outline-none focus:border-blue-500"
        >
          <option value="">All Statuses</option>
          <option value="PAID">PAID</option>
          <option value="PENDING">PENDING</option>
          <option value="FAILED">FAILED</option>
          <option value="CANCELLED">CANCELLED</option>
        </select>
      </div>

      {/* Orders Table */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/60 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-800/40 text-[10px] text-slate-400 uppercase tracking-wider border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Order Reference</th>
                <th className="py-3 px-4">Customer</th>
                <th className="py-3 px-4">Items</th>
                <th className="py-3 px-4">Total Amount</th>
                <th className="py-3 px-4">Fulfillment Status</th>
                <th className="py-3 px-4">Payment State</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {orders.map((ord) => (
                <tr key={ord.id} className="hover:bg-slate-800/30 transition-colors">
                  <td className="py-3 px-4">
                    <span className="font-mono text-white font-semibold">#{shortId(ord.id)}</span>
                    <div className="text-[10px] text-slate-400">
                      {new Date(ord.created_at).toLocaleDateString()} {new Date(ord.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <div className="font-medium text-white">{ord.customer_name}</div>
                    <div className="text-[11px] text-slate-400">{ord.customer_email}</div>
                  </td>
                  <td className="py-3 px-4">
                    <span className="font-medium text-slate-300">{ord.items_count} items</span>
                  </td>
                  <td className="py-3 px-4 font-semibold text-white">
                    ${ord.total_amount.toFixed(2)}
                  </td>
                  <td className="py-3 px-4">
                    <span
                      className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${
                        ord.status === 'PAID'
                          ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                          : ord.status === 'FAILED'
                          ? 'bg-rose-500/10 text-rose-400 border-rose-500/20'
                          : ord.status === 'CANCELLED'
                          ? 'bg-slate-800 text-slate-400 border-slate-700'
                          : 'bg-amber-500/10 text-amber-400 border-amber-500/20'
                      }`}
                    >
                      {ord.status === 'PAID' && <CheckCircle2 className="w-3 h-3" />}
                      {ord.status === 'FAILED' && <AlertTriangle className="w-3 h-3" />}
                      {ord.status === 'PENDING' && <Clock className="w-3 h-3" />}
                      {ord.status === 'CANCELLED' && <XCircle className="w-3 h-3" />}
                      {ord.status}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-mono uppercase ${
                        ord.payment_status === 'PAID'
                          ? 'bg-emerald-950/60 text-emerald-400'
                          : ord.payment_status === 'FAILED'
                          ? 'bg-rose-950/60 text-rose-400'
                          : 'bg-slate-800 text-slate-300'
                      }`}
                    >
                      {ord.payment_status}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right space-x-2">
                    <button
                      onClick={() => setSelectedOrder(ord)}
                      className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-colors"
                      title="Inspect items"
                    >
                      <Eye className="w-3.5 h-3.5" />
                    </button>

                    {ord.status !== 'PAID' && ord.status !== 'CANCELLED' && (
                      <>
                        <button
                          onClick={() => setPaymentModalOrder(ord)}
                          className="px-2 py-1 rounded-lg bg-blue-600/20 hover:bg-blue-600 text-blue-400 hover:text-white border border-blue-500/30 text-[10px] font-semibold transition-colors"
                        >
                          Simulate Payment
                        </button>
                        <button
                          onClick={() => handleCancelOrder(ord)}
                          className="p-1.5 rounded-lg bg-slate-800 hover:bg-rose-600/30 text-slate-400 hover:text-rose-300 border border-slate-700 transition-colors align-middle"
                          title="Cancel order"
                        >
                          <XCircle className="w-3.5 h-3.5" />
                        </button>
                      </>
                    )}
                  </td>
                </tr>
              ))}
              {orders.length === 0 && !isLoading && (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-500">
                    <ShoppingBag className="w-8 h-8 mx-auto mb-2 opacity-40" />
                    No orders recorded. Checkout using the AI Buyer Storefront to generate orders automatically.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Order Items Inspection Modal */}
      {selectedOrder && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-lg w-full p-6 shadow-2xl animate-in zoom-in-95">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h2 className="text-base font-bold text-white">
                  Order #{shortId(selectedOrder.id)}
                </h2>
                <span className="text-xs text-slate-400">{selectedOrder.customer_name} • {selectedOrder.customer_email}</span>
              </div>
              <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold border ${
                selectedOrder.status === 'PAID'
                  ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                  : 'bg-amber-500/10 text-amber-400 border-amber-500/20'
              }`}>
                {selectedOrder.status}
              </span>
            </div>

            <div className="border-t border-b border-slate-800 py-3 my-4 space-y-2 max-h-60 overflow-y-auto">
              {(selectedOrder.items || []).map((itm, idx) => (
                <div key={idx} className="flex items-center justify-between text-xs py-1.5 border-b border-slate-800/40 last:border-0">
                  <div>
                    <div className="font-semibold text-white">{itm.title}</div>
                    <div className="text-[10px] text-slate-400 font-mono">
                      Qty: {itm.quantity} × ${itm.price.toFixed(2)}
                    </div>
                  </div>
                  <div className="font-bold text-slate-200">
                    ${itm.subtotal.toFixed(2)}
                  </div>
                </div>
              ))}
            </div>

            <div className="flex items-center justify-between font-bold text-sm text-white mb-6">
              <span>Total Amount:</span>
              <span className="text-emerald-400 text-base">
                ${selectedOrder.total_amount.toFixed(2)}
              </span>
            </div>

            <div className="flex justify-end">
              <button
                onClick={() => setSelectedOrder(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Payment Simulation Trigger Modal */}
      {paymentModalOrder && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-md w-full p-6 shadow-2xl animate-in zoom-in-95">
            <div className="flex items-center space-x-3 mb-2">
              <div className="p-2 rounded-xl bg-blue-600/20 text-blue-400 border border-blue-500/30">
                <CreditCard className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base font-bold text-white">Simulate Payment Gateway</h2>
                <span className="text-xs text-slate-400">Order #{shortId(paymentModalOrder.id)}</span>
              </div>
            </div>

            <p className="text-xs text-slate-300 mt-2">
              Test end-to-end synchronization. Simulating success or failure immediately updates the Order, Transaction ledger, and Dashboard KPIs.
            </p>

            <div className="my-4 p-3 rounded-xl bg-slate-800/80 border border-slate-700 text-xs flex items-center justify-between">
              <span className="text-slate-400">Checkout Total:</span>
              <span className="font-bold text-white text-base">
                ${paymentModalOrder.total_amount.toFixed(2)}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <button
                disabled={isSimulating}
                onClick={() => handleSimulatePayment(paymentModalOrder.id, 'FAILURE')}
                className="py-2.5 px-3 rounded-xl bg-rose-600/20 hover:bg-rose-600 text-rose-300 hover:text-white border border-rose-500/30 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors disabled:opacity-50"
              >
                <AlertTriangle className="w-4 h-4" />
                <span>Simulate Failure</span>
              </button>

              <button
                disabled={isSimulating}
                onClick={() => handleSimulatePayment(paymentModalOrder.id, 'SUCCESS')}
                className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-lg shadow-emerald-600/25 flex items-center justify-center gap-1.5 transition-colors disabled:opacity-50"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Simulate Success</span>
              </button>
            </div>

            <button
              onClick={() => setPaymentModalOrder(null)}
              className="w-full mt-3 py-2 text-center text-xs text-slate-400 hover:text-slate-300"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
