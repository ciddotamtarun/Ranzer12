import React, { useState } from 'react';
import { api } from '../api/client.ts';
import type { DashboardMetrics } from '../types/index.ts';
import { useAsyncResource } from '../hooks/useAsyncResource.ts';
import { LoadError } from '../components/LoadError.tsx';
import { shortId } from '../lib/format.ts';
import { MetricCard } from '../components/MetricCard.tsx';
import {
  DollarSign,
  TrendingUp,
  ShoppingBag,
  Target,
  Percent,
  CheckCircle2,
  AlertTriangle,
  Flame,
  Sparkles,
  ArrowUpRight,
  RefreshCw,
  CreditCard
} from 'lucide-react';

const errorMessage = (err: unknown) => (err instanceof Error ? err.message : String(err));
const loadDashboard = () => api.dashboard.getStats();

interface DashboardPageProps {
  onNavigate: (view: string) => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({ onNavigate }) => {
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [message, setMessage] = useState<string | null>(null);

  const { data, error: loadError, isLoading, reload: fetchDashboardData } = useAsyncResource(loadDashboard);
  const metrics = data?.metrics ?? null;
  const recentTransactions = data?.recentTransactions ?? [];
  const recentOrders = data?.recentOrders ?? [];
  const chartData = data?.chartData ?? [];

  const handleGenerateOpportunity = async () => {
    setIsGenerating(true);
    setMessage(null);
    try {
      const res = await api.ai.generateOpportunity();
      setMessage(`AI Agent created: '${res.agentTask.title}'. Check the Approvals page to authorize!`);
      fetchDashboardData();
    } catch (err) {
      setMessage(`Error: ${errorMessage(err)}`);
    } finally {
      setIsGenerating(false);
    }
  };

  if (isLoading && !metrics) {
    return (
      <div className="flex-1 p-8 flex items-center justify-center">
        <div className="flex items-center space-x-3 text-slate-400">
          <RefreshCw className="w-5 h-5 animate-spin text-blue-500" />
          <span>Synchronizing real-time merchant metrics...</span>
        </div>
      </div>
    );
  }

  const m: DashboardMetrics = metrics || {
    gmv: 0,
    revenue: 0,
    orders: 0,
    paidOrders: 0,
    aov: 0,
    conversionRate: 0,
    paymentSuccess: 0,
    paymentSuccessRate: 0,
    paymentFailure: 0,
    paymentFailureRate: 0,
    revenueLeakage: 0,
    aiOpportunities: 0,
    aiPotentialLift: 0
  };

  return (
    <div className="flex-1 p-6 space-y-6 overflow-y-auto">
      <LoadError error={loadError} onRetry={fetchDashboardData} what="dashboard metrics" />
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            Merchant Executive Dashboard
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              Live DB
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Real-time telemetry, payment gateway observability, and autonomous AI growth levers.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={fetchDashboardData}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-300 border border-slate-700 transition-colors"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>

          <button
            onClick={handleGenerateOpportunity}
            disabled={isGenerating}
            className="flex items-center space-x-2 px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-xs font-semibold text-white shadow-lg shadow-blue-500/25 border border-blue-400/30 transition-all disabled:opacity-50"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{isGenerating ? 'Analyzing...' : 'Discover AI Opportunity'}</span>
          </button>
        </div>
      </div>

      {/* Notification Banner */}
      {message && (
        <div className="p-3 rounded-xl bg-blue-500/10 border border-blue-500/20 text-blue-300 text-xs flex items-center justify-between animate-in fade-in">
          <span>{message}</span>
          <button onClick={() => setMessage(null)} className="text-blue-400 hover:text-white font-bold ml-4">
            ×
          </button>
        </div>
      )}

      {/* AI Growth Opportunities Highlight Banner */}
      <div className="rounded-2xl border border-indigo-500/30 bg-gradient-to-r from-indigo-950/40 via-slate-900 to-blue-950/40 p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xl">
        <div className="flex items-start space-x-4">
          <div className="p-3 rounded-xl bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 shrink-0">
            <Flame className="w-6 h-6 text-amber-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-bold text-white">RazorGrowth Autonomous AI Engine</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 font-semibold">
                {m.aiOpportunities} Active Opportunities
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-1 max-w-2xl">
              We detected <strong className="text-white">${m.revenueLeakage.toFixed(2)}</strong> in revenue leakage.
              Autonomous agents can recover an estimated <strong className="text-emerald-400">+${m.aiPotentialLift.toFixed(2)}</strong> in monthly revenue lift upon approval.
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-3 shrink-0">
          <button
            onClick={() => onNavigate('approvals')}
            className="px-3.5 py-2 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <span>Review Pending Approvals</span>
            <ArrowUpRight className="w-4 h-4" />
          </button>
          <button
            onClick={() => onNavigate('ai-growth')}
            className="px-3.5 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-lg shadow-indigo-600/30 transition-colors"
          >
            Open Growth Center
          </button>
        </div>
      </div>

      {/* Empty State Onboarding Prompt when store has no data */}
      {m.orders === 0 && m.revenue === 0 && (
        <div className="rounded-2xl border border-dashed border-slate-800 bg-slate-900/40 p-6 sm:p-8 text-center space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-blue-500/10 text-blue-400 border border-blue-500/20 flex items-center justify-center mx-auto">
            <ShoppingBag className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold text-white">No business data yet</h3>
          <p className="text-xs text-slate-400 max-w-md mx-auto">
            Your merchant workspace is active. Create products, manage customers, or simulate checkouts to populate real analytics.
          </p>
          <div className="flex items-center justify-center gap-3 pt-2">
            <button
              onClick={() => onNavigate('products')}
              className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold shadow-lg shadow-blue-500/20 transition-all cursor-pointer"
            >
              Add Your First Product
            </button>
            <button
              onClick={() => onNavigate('buyer')}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold border border-slate-700 transition-all cursor-pointer"
            >
              Explore AI Storefront
            </button>
          </div>
        </div>
      )}

      {/* 8 Primary Required KPI Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* 1. GMV */}
        <MetricCard
          title="Gross Merchandise Value (GMV)"
          value={`$${m.gmv.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}
          subtitle="Cumulative order pipeline"
          icon={DollarSign}
          trend={m.gmv > 0 ? "Cumulative Volume" : "No orders yet"}
          trendType={m.gmv > 0 ? "positive" : "neutral"}
          highlight
        />

        {/* 2. Revenue */}
        <MetricCard
          title="Net Settled Revenue"
          value={`$${m.revenue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}
          subtitle={`${m.paidOrders} paid out orders`}
          icon={TrendingUp}
          trend={m.revenue > 0 ? "Bank Settlements" : "Awaiting sales"}
          trendType={m.revenue > 0 ? "positive" : "neutral"}
          highlight
        />

        {/* 3. Orders */}
        <MetricCard
          title="Total Orders Count"
          value={m.orders}
          subtitle={`${m.paidOrders} paid • ${m.orders - m.paidOrders} pending/failed`}
          icon={ShoppingBag}
          trend={m.orders > 0 ? `${m.paidOrders} Captured` : "No activity"}
          trendType="neutral"
        />

        {/* 4. Average Order Value (AOV) */}
        <MetricCard
          title="Average Order Value (AOV)"
          value={`$${m.aov.toFixed(2)}`}
          subtitle="Revenue per paid checkout"
          icon={Target}
          trend={m.aov > 0 ? "Per paid order" : "Baseline: $0.00"}
          trendType={m.aov > 0 ? "positive" : "neutral"}
        />

        {/* 5. Conversion Rate */}
        <MetricCard
          title="Storefront Conversion Rate"
          value={`${m.conversionRate}%`}
          subtitle="Visitors to completed checkouts"
          icon={Percent}
          trend={m.conversionRate > 0 ? "Active Funnel" : "0% conversion"}
          trendType={m.conversionRate > 0 ? "positive" : "neutral"}
        />

        {/* 6. Payment Success */}
        <MetricCard
          title="Payment Success Rate"
          value={`${m.paymentSuccessRate}%`}
          subtitle={`${m.paymentSuccess} successful transactions`}
          icon={CheckCircle2}
          trend={m.paymentSuccess > 0 ? "Verified Successful" : "No payments yet"}
          trendType={m.paymentSuccess > 0 ? "positive" : "neutral"}
        />

        {/* 7. Payment Failure */}
        <MetricCard
          title="Payment Failure Rate"
          value={`${m.paymentFailureRate}%`}
          subtitle={`${m.paymentFailure} rejected charges`}
          icon={AlertTriangle}
          trend={m.paymentFailure > 0 ? 'Requires Action' : 'Zero Failures'}
          trendType={m.paymentFailure > 0 ? 'warning' : 'positive'}
        />

        {/* 8. Revenue Leakage */}
        <MetricCard
          title="Revenue Leakage"
          value={`$${m.revenueLeakage.toFixed(2)}`}
          subtitle="Lost to 3DS timeouts & card errors"
          icon={Flame}
          trend={m.revenueLeakage > 0 ? "Recoverable via Agent" : "No Leakage"}
          trendType={m.revenueLeakage > 0 ? "negative" : "positive"}
        />
      </div>

      {/* Visual Revenue & Settlement Trends */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Revenue Velocity Chart */}
        <div className="lg:col-span-2 rounded-xl border border-slate-800 bg-slate-900/60 p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-semibold text-white">Daily Revenue & Order Velocity</h2>
              <p className="text-xs text-slate-400">Past 7 days settled volume</p>
            </div>
            <div className="flex items-center space-x-3 text-xs">
              <span className="flex items-center gap-1.5 text-blue-400 font-medium">
                <span className="w-2.5 h-2.5 rounded bg-blue-500" /> Revenue
              </span>
              <span className="flex items-center gap-1.5 text-slate-400 font-medium">
                <span className="w-2.5 h-2.5 rounded bg-slate-700" /> Pipeline GMV
              </span>
            </div>
          </div>

          {m.revenue === 0 && m.gmv === 0 ? (
            <div className="h-48 flex flex-col items-center justify-center text-slate-500 space-y-2 border border-dashed border-slate-800/80 rounded-lg">
              <CreditCard className="w-8 h-8 opacity-40 text-slate-500" />
              <span className="text-xs">No transaction velocity recorded yet. Run payments to visualize live trends.</span>
            </div>
          ) : (
            <div className="h-48 flex items-end justify-between gap-3 pt-4 px-2">
              {chartData.map((item) => {
                const maxRev = Math.max(...chartData.map((c) => c.revenue), 100);
                const heightPct = Math.max(15, Math.round((item.revenue / maxRev) * 100));

                return (
                  <div key={item.day} className="flex-1 flex flex-col items-center gap-2 group">
                    <div className="text-[10px] text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity font-mono">
                      ${item.revenue}
                    </div>
                    <div className="w-full bg-slate-800/80 rounded-t-lg flex items-end overflow-hidden h-36">
                      <div
                        style={{ height: `${heightPct}%` }}
                        className="w-full bg-gradient-to-t from-blue-600 to-indigo-500 rounded-t-md group-hover:brightness-110 transition-all duration-300 shadow-lg shadow-blue-500/20"
                      />
                    </div>
                    <span className="text-[11px] font-medium text-slate-400">{item.day}</span>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Payment Gateway Health */}
        <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-5 flex flex-col justify-between">
          <div>
            <h2 className="text-sm font-semibold text-white">Payment Health Breakdown</h2>
            <p className="text-xs text-slate-400">Gateway success vs failure ratio</p>

            <div className="mt-6 space-y-4">
              <div>
                <div className="flex justify-between text-xs mb-1.5">
                  <span className="text-slate-300 font-medium flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Approved Transactions
                  </span>
                  <span className="text-emerald-400 font-bold">{m.paymentSuccessRate}%</span>
                </div>
                <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                  <div
                    style={{ width: `${m.paymentSuccessRate}%` }}
                    className="h-full bg-emerald-500 rounded-full"
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs mb-1.5">
                  <span className="text-slate-300 font-medium flex items-center gap-1.5">
                    <AlertTriangle className="w-3.5 h-3.5 text-rose-400" /> Gateway Failures & 3DS Drop
                  </span>
                  <span className="text-rose-400 font-bold">{m.paymentFailureRate}%</span>
                </div>
                <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                  <div
                    style={{ width: `${m.paymentFailureRate}%` }}
                    className="h-full bg-rose-500 rounded-full"
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-800 mt-6">
            <button
              onClick={() => onNavigate('transactions')}
              className="w-full py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 border border-slate-700 flex items-center justify-center gap-2 transition-colors"
            >
              <CreditCard className="w-3.5 h-3.5 text-blue-400" />
              <span>Inspect All Transactions</span>
            </button>
          </div>
        </div>
      </div>

      {/* Recent Activity Tables */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Transactions */}
        <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-5">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-semibold text-white">Recent Transactions</h2>
            <button
              onClick={() => onNavigate('transactions')}
              className="text-xs text-blue-400 hover:text-blue-300 font-medium"
            >
              View all →
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="text-[10px] text-slate-400 uppercase tracking-wider border-b border-slate-800">
                <tr>
                  <th className="py-2">Reference</th>
                  <th className="py-2">Amount</th>
                  <th className="py-2">Method</th>
                  <th className="py-2">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {recentTransactions.map((tx) => (
                  <tr key={tx.id} className="hover:bg-slate-800/30 transition-colors">
                    <td className="py-2.5 font-mono text-slate-300">
                      {tx.gateway_reference || shortId(tx.id)}
                    </td>
                    <td className="py-2.5 font-semibold text-white">
                      ${tx.amount.toFixed(2)}
                    </td>
                    <td className="py-2.5 text-slate-400 truncate max-w-[120px]">
                      {tx.payment_method}
                    </td>
                    <td className="py-2.5">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                          tx.status === 'SUCCESS'
                            ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                            : 'bg-rose-500/10 text-rose-400 border-rose-500/20'
                        }`}
                      >
                        {tx.status}
                      </span>
                    </td>
                  </tr>
                ))}
                {recentTransactions.length === 0 && (
                  <tr>
                    <td colSpan={4} className="py-4 text-center text-slate-500">
                      No transactions recorded yet.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Recent Orders */}
        <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-5">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-semibold text-white">Recent Customer Orders</h2>
            <button
              onClick={() => onNavigate('orders')}
              className="text-xs text-blue-400 hover:text-blue-300 font-medium"
            >
              View all →
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="text-[10px] text-slate-400 uppercase tracking-wider border-b border-slate-800">
                <tr>
                  <th className="py-2">Order ID</th>
                  <th className="py-2">Customer</th>
                  <th className="py-2">Total</th>
                  <th className="py-2">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {recentOrders.map((ord) => (
                  <tr key={ord.id} className="hover:bg-slate-800/30 transition-colors">
                    <td className="py-2.5 font-mono text-slate-300 truncate max-w-[100px]">
                      #{shortId(ord.id)}
                    </td>
                    <td className="py-2.5 text-slate-200">
                      <div className="font-medium truncate max-w-[130px]">{ord.customer_name}</div>
                      <div className="text-[10px] text-slate-400 truncate max-w-[130px]">{ord.customer_email}</div>
                    </td>
                    <td className="py-2.5 font-semibold text-white">
                      ${ord.total_amount.toFixed(2)}
                    </td>
                    <td className="py-2.5">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                          ord.status === 'PAID'
                            ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                            : ord.status === 'FAILED'
                            ? 'bg-rose-500/10 text-rose-400 border-rose-500/20'
                            : 'bg-amber-500/10 text-amber-400 border-amber-500/20'
                        }`}
                      >
                        {ord.status}
                      </span>
                    </td>
                  </tr>
                ))}
                {recentOrders.length === 0 && (
                  <tr>
                    <td colSpan={4} className="py-4 text-center text-slate-500">
                      No orders created yet.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
