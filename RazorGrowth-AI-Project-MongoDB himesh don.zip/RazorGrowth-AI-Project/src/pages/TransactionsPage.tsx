import React, { useCallback, useState } from 'react';
import { api } from '../api/client.ts';
import type { Transaction } from '../types/index.ts';
import { useAsyncResource } from '../hooks/useAsyncResource.ts';
import { LoadError } from '../components/LoadError.tsx';
import { shortId } from '../lib/format.ts';
import {
  CreditCard,
  Search,
  RefreshCw,
  CheckCircle2,
  AlertTriangle
} from 'lucide-react';

export const TransactionsPage: React.FC = () => {
  const [statusFilter, setStatusFilter] = useState<string>('');
  const [searchTerm, setSearchTerm] = useState<string>('');

  const loadTransactions = useCallback(
    () => api.transactions.list({ status: statusFilter || undefined }),
    [statusFilter]
  );
  const { data, error: loadError, isLoading, reload: fetchTransactions } = useAsyncResource(loadTransactions);
  const transactions: Transaction[] = data?.transactions ?? [];

  const filtered = transactions.filter((tx) => {
    if (!searchTerm) return true;
    const term = searchTerm.toLowerCase();
    return (
      tx.id.toLowerCase().includes(term) ||
      (tx.gateway_reference && tx.gateway_reference.toLowerCase().includes(term)) ||
      (tx.customer_name && tx.customer_name.toLowerCase().includes(term)) ||
      (tx.customer_email && tx.customer_email.toLowerCase().includes(term)) ||
      (tx.failure_reason && tx.failure_reason.toLowerCase().includes(term))
    );
  });

  return (
    <div className="flex-1 p-6 space-y-6 overflow-y-auto">
      <LoadError error={loadError} onRetry={fetchTransactions} what="transactions" />
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            Payment Transactions & Gateway Ledger
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20">
              {transactions.length} Records
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Auditable transaction logs containing gateway references, payment outcomes, and failure diagnostics.
          </p>
        </div>

        <button
          onClick={fetchTransactions}
          className="flex items-center space-x-1.5 px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-300 border border-slate-700 transition-colors self-start sm:self-auto"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
          <span>Refresh Ledger</span>
        </button>
      </div>

      {/* Filter / Search Bar */}
      <div className="flex flex-col sm:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search gateway ref, transaction ID, customer, or failure error..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-blue-500"
          />
        </div>

        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="w-full sm:w-48 py-2 px-3 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-200 focus:outline-none focus:border-blue-500"
        >
          <option value="">All Transactions</option>
          <option value="SUCCESS">SUCCESS Only</option>
          <option value="FAILED">FAILED Only</option>
        </select>
      </div>

      {/* Transactions Table */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/60 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-800/40 text-[10px] text-slate-400 uppercase tracking-wider border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Gateway Reference</th>
                <th className="py-3 px-4">Order Link</th>
                <th className="py-3 px-4">Customer</th>
                <th className="py-3 px-4">Amount</th>
                <th className="py-3 px-4">Method</th>
                <th className="py-3 px-4">Status & Reason</th>
                <th className="py-3 px-4">Date & Time</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filtered.map((tx) => (
                <tr key={tx.id} className="hover:bg-slate-800/30 transition-colors">
                  <td className="py-3 px-4">
                    <div className="font-mono text-white font-semibold flex items-center gap-1.5">
                      <CreditCard className="w-3.5 h-3.5 text-blue-400" />
                      <span>{tx.gateway_reference || shortId(tx.id)}</span>
                    </div>
                    <div className="text-[10px] font-mono text-slate-500">{tx.id}</div>
                  </td>
                  <td className="py-3 px-4 font-mono text-slate-300">
                    #{shortId(tx.order_id)}
                  </td>
                  <td className="py-3 px-4">
                    <div className="font-medium text-white">{tx.customer_name || 'Buyer'}</div>
                    <div className="text-[10px] text-slate-400">{tx.customer_email || 'Direct Checkout'}</div>
                  </td>
                  <td className="py-3 px-4 font-semibold text-white">
                    ${tx.amount.toFixed(2)}
                  </td>
                  <td className="py-3 px-4 text-slate-300">
                    {tx.payment_method}
                  </td>
                  <td className="py-3 px-4">
                    <span
                      className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${
                        tx.status === 'SUCCESS'
                          ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                          : 'bg-rose-500/10 text-rose-400 border-rose-500/20'
                      }`}
                    >
                      {tx.status === 'SUCCESS' ? (
                        <CheckCircle2 className="w-3 h-3" />
                      ) : (
                        <AlertTriangle className="w-3 h-3" />
                      )}
                      {tx.status}
                    </span>
                    {tx.failure_reason && (
                      <div className="text-[10px] text-rose-400 mt-1 max-w-xs truncate" title={tx.failure_reason}>
                        {tx.failure_reason}
                      </div>
                    )}
                  </td>
                  <td className="py-3 px-4 text-slate-400 text-[11px]">
                    {new Date(tx.created_at).toLocaleDateString()} {new Date(tx.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && !isLoading && (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-500">
                    No transactions recorded matching the filter.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
