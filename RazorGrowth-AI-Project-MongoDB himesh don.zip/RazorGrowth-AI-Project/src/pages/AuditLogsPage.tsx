import React, { useCallback, useState } from 'react';
import { api } from '../api/client.ts';
import type { AuditLog } from '../types/index.ts';
import { useAsyncResource } from '../hooks/useAsyncResource.ts';
import { LoadError } from '../components/LoadError.tsx';
import { shortId } from '../lib/format.ts';
import {
  FileText,
  Search,
  RefreshCw,
  User,
  Bot,
  Shield,
  ShoppingBag
} from 'lucide-react';

export const AuditLogsPage: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [actionFilter, setActionFilter] = useState<string>('');

  const loadLogs = useCallback(
    () => api.auditLogs.list({ action: actionFilter || undefined, limit: 100 }),
    [actionFilter]
  );
  const { data, error: loadError, isLoading, reload: fetchLogs } = useAsyncResource(loadLogs);
  const logs: AuditLog[] = data?.auditLogs ?? [];

  const filteredLogs = logs.filter((l) => {
    if (!searchTerm) return true;
    const term = searchTerm.toLowerCase();
    return (
      l.action.toLowerCase().includes(term) ||
      l.entity_type.toLowerCase().includes(term) ||
      (l.details && l.details.toLowerCase().includes(term)) ||
      (l.actor_email && l.actor_email.toLowerCase().includes(term))
    );
  });

  const getActorBadge = (actorType: string, email?: string | null) => {
    switch (actorType) {
      case 'AGENT':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-indigo-400">
            <Bot className="w-3.5 h-3.5" /> Autonomous Agent
          </span>
        );
      case 'USER':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-blue-400">
            <User className="w-3.5 h-3.5" /> {email || 'Merchant User'}
          </span>
        );
      case 'BUYER':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-purple-400">
            <ShoppingBag className="w-3.5 h-3.5" /> Consumer Buyer
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-slate-400">
            <Shield className="w-3.5 h-3.5" /> System Kernel
          </span>
        );
    }
  };

  return (
    <div className="flex-1 p-6 space-y-6 overflow-y-auto">
      <LoadError error={loadError} onRetry={fetchLogs} what="audit logs" />
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            Compliance & System Audit Trail
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20">
              {logs.length} Audit Events
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Immutable chronicle of all state mutations across authentication, payments, approvals, and product records.
          </p>
        </div>

        <button
          onClick={fetchLogs}
          className="flex items-center space-x-1.5 px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-300 border border-slate-700 transition-colors self-start sm:self-auto"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
          <span>Refresh Audit Logs</span>
        </button>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search audit trail by action, email, or details..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-blue-500"
          />
        </div>

        <select
          value={actionFilter}
          onChange={(e) => setActionFilter(e.target.value)}
          className="w-full sm:w-56 py-2 px-3 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-200 focus:outline-none focus:border-blue-500"
        >
          <option value="">All Action Types</option>
          <option value="PAYMENT_SUCCEEDED">PAYMENT_SUCCEEDED</option>
          <option value="PAYMENT_FAILED">PAYMENT_FAILED</option>
          <option value="ORDER_CREATED">ORDER_CREATED</option>
          <option value="APPROVAL_GRANTED">APPROVAL_GRANTED</option>
          <option value="APPROVAL_REJECTED">APPROVAL_REJECTED</option>
          <option value="AGENT_ACTION_EXECUTED">AGENT_ACTION_EXECUTED</option>
          <option value="PRODUCT_CREATED">PRODUCT_CREATED</option>
          <option value="CUSTOMER_CREATED">CUSTOMER_CREATED</option>
          <option value="USER_LOGIN">USER_LOGIN</option>
        </select>
      </div>

      {/* Audit Log Table */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/60 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-800/40 text-[10px] text-slate-400 uppercase tracking-wider border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Timestamp</th>
                <th className="py-3 px-4">Actor</th>
                <th className="py-3 px-4">Action</th>
                <th className="py-3 px-4">Target Entity</th>
                <th className="py-3 px-4">Event Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredLogs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-800/30 transition-colors">
                  <td className="py-3 px-4 text-slate-400 whitespace-nowrap text-[11px]">
                    {new Date(log.created_at).toLocaleDateString()} {new Date(log.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                  </td>
                  <td className="py-3 px-4">
                    {getActorBadge(log.actor_type, log.actor_email)}
                  </td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-slate-800 text-slate-200 border border-slate-700">
                      {log.action}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-mono text-[11px] text-slate-300">
                    <span className="text-slate-400">{log.entity_type}</span>
                    {log.entity_id && (
                      <span className="text-[10px] text-slate-500 block">
                        #{shortId(log.entity_id)}
                      </span>
                    )}
                  </td>
                  <td className="py-3 px-4 text-slate-300 leading-relaxed max-w-md">
                    {log.details}
                  </td>
                </tr>
              ))}
              {filteredLogs.length === 0 && !isLoading && (
                <tr>
                  <td colSpan={5} className="py-8 text-center text-slate-500">
                    <FileText className="w-8 h-8 mx-auto mb-2 opacity-40" />
                    No audit records match the current filter.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
