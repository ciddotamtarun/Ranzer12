import React, { useState } from 'react';
import { api } from '../api/client.ts';
import type { Approval } from '../types/index.ts';
import { useAsyncResource } from '../hooks/useAsyncResource.ts';
import { LoadError } from '../components/LoadError.tsx';
import {
  CheckCircle2,
  XCircle,
  Clock,
  RefreshCw,
  Sparkles,
  Bot,
  UserCheck
} from 'lucide-react';

const errorMessage = (err: unknown) => (err instanceof Error ? err.message : String(err));
const loadApprovals = () => api.approvals.list();

interface ApprovalsPageProps {
  onRefreshStats?: () => void;
}

export const ApprovalsPage: React.FC<ApprovalsPageProps> = ({ onRefreshStats }) => {
  const [isProcessingId, setIsProcessingId] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<string | null>(null);

  const { data, error: loadError, isLoading, reload: fetchApprovals } = useAsyncResource(loadApprovals);
  const approvals: Approval[] = data?.approvals ?? [];

  const handleDecision = async (id: string, decision: 'APPROVE' | 'REJECT') => {
    setIsProcessingId(id);
    try {
      await api.approvals.decide(id, {
        decision,
        notes: decision === 'APPROVE' ? 'Approved via RazorGrowth AI Web Dashboard' : 'Rejected by merchant'
      });

      if (decision === 'APPROVE') {
        setFeedback(`Agent action authorized and executed! Audit log created and impact monitoring active.`);
      } else {
        setFeedback(`Agent action rejected.`);
      }

      fetchApprovals();
      if (onRefreshStats) onRefreshStats();
    } catch (err) {
      alert(`Error deciding approval: ${errorMessage(err)}`);
    } finally {
      setIsProcessingId(null);
    }
  };

  const pendingApprovals = approvals.filter((a) => a.status === 'PENDING');
  const pastApprovals = approvals.filter((a) => a.status !== 'PENDING');

  return (
    <div className="flex-1 p-6 space-y-6 overflow-y-auto">
      <LoadError error={loadError} onRetry={fetchApprovals} what="approvals" />
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            Human-in-the-Loop Approvals
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20">
              {pendingApprovals.length} Pending
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Authorize or decline proposed autonomous agent actions before they alter production database rules.
          </p>
        </div>

        <button
          onClick={fetchApprovals}
          className="flex items-center space-x-1.5 px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-300 border border-slate-700 transition-colors self-start sm:self-auto"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
          <span>Refresh Queue</span>
        </button>
      </div>

      {feedback && (
        <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs flex items-center justify-between animate-in fade-in">
          <span>{feedback}</span>
          <button onClick={() => setFeedback(null)} className="text-emerald-400 font-bold ml-4">
            ×
          </button>
        </div>
      )}

      {/* Pending Approvals Section */}
      <div className="space-y-4">
        <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
          <Clock className="w-4 h-4 text-amber-400" />
          Pending Authorizations Requiring Merchant Review
        </h2>

        <div className="grid grid-cols-1 gap-4">
          {pendingApprovals.map((app) => (
            <div
              key={app.id}
              className="rounded-2xl border border-amber-500/30 bg-slate-900/80 p-5 shadow-xl space-y-4 relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/5 rounded-full blur-2xl pointer-events-none" />

              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex items-center space-x-2.5">
                  <div className="p-2 rounded-xl bg-amber-500/15 text-amber-400 border border-amber-500/30">
                    <Bot className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-white">{app.title}</h3>
                    <div className="text-[11px] text-slate-400 font-mono">
                      Requested by: <span className="text-slate-300">{app.requested_by}</span> • {new Date(app.created_at).toLocaleString()}
                    </div>
                  </div>
                </div>

                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/30 self-start sm:self-auto">
                  Awaiting Decision
                </span>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/60 text-xs space-y-2">
                <div className="text-slate-300 leading-relaxed font-medium">
                  {app.description}
                </div>
                {app.proposed_action && (
                  <div className="text-blue-300 font-mono text-[11px]">
                    Action Payload: {app.proposed_action}
                  </div>
                )}
                {app.impact_metric && (
                  <div className="text-emerald-400 font-semibold text-xs flex items-center gap-1">
                    <Sparkles className="w-3 h-3" />
                    <span>Projected Impact: {app.impact_metric}</span>
                  </div>
                )}
              </div>

              <div className="flex items-center justify-end space-x-3 pt-2 border-t border-slate-800">
                <button
                  disabled={isProcessingId === app.id}
                  onClick={() => handleDecision(app.id, 'REJECT')}
                  className="px-4 py-2 rounded-xl bg-rose-600/20 hover:bg-rose-600 text-rose-300 hover:text-white border border-rose-500/30 text-xs font-semibold flex items-center gap-1.5 transition-colors disabled:opacity-50"
                >
                  <XCircle className="w-4 h-4" />
                  <span>Reject Action</span>
                </button>

                <button
                  disabled={isProcessingId === app.id}
                  onClick={() => handleDecision(app.id, 'APPROVE')}
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-lg shadow-emerald-600/30 flex items-center gap-1.5 transition-all disabled:opacity-50"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{isProcessingId === app.id ? 'Executing...' : 'Approve & Execute'}</span>
                </button>
              </div>
            </div>
          ))}

          {pendingApprovals.length === 0 && (
            <div className="p-8 text-center text-slate-500 rounded-xl border border-slate-800 bg-slate-900/40">
              <UserCheck className="w-8 h-8 mx-auto mb-2 opacity-40 text-emerald-400" />
              <p className="text-sm font-medium text-slate-300">All agent actions reviewed!</p>
              <p className="text-xs text-slate-500 mt-1">
                No pending approval requests in queue. Generate an opportunity from AI Growth Center to test.
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Resolved History Section */}
      {pastApprovals.length > 0 && (
        <div className="space-y-4 pt-4 border-t border-slate-800">
          <h2 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
            Decision Audit Trail History
          </h2>

          <div className="rounded-xl border border-slate-800 bg-slate-900/60 overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-800/40 text-[10px] text-slate-400 uppercase tracking-wider border-b border-slate-800">
                <tr>
                  <th className="py-2.5 px-4">Title</th>
                  <th className="py-2.5 px-4">Decision</th>
                  <th className="py-2.5 px-4">Resolved By</th>
                  <th className="py-2.5 px-4">Timestamp</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {pastApprovals.map((app) => (
                  <tr key={app.id} className="hover:bg-slate-800/30 transition-colors">
                    <td className="py-2.5 px-4">
                      <div className="font-semibold text-white">{app.title}</div>
                      <div className="text-[10px] text-slate-400 truncate max-w-sm">{app.description}</div>
                    </td>
                    <td className="py-2.5 px-4">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                          app.status === 'APPROVED'
                            ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                            : 'bg-rose-500/10 text-rose-400 border-rose-500/20'
                        }`}
                      >
                        {app.status}
                      </span>
                    </td>
                    <td className="py-2.5 px-4 text-slate-300">{app.resolved_by || 'Admin'}</td>
                    <td className="py-2.5 px-4 text-slate-400">
                      {app.resolved_at ? new Date(app.resolved_at).toLocaleString() : '-'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
