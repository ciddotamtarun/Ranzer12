import React, { useCallback, useState } from 'react';
import { api } from '../api/client.ts';
import type { Product } from '../types/index.ts';
import { useAsyncResource } from '../hooks/useAsyncResource.ts';
import { LoadError } from '../components/LoadError.tsx';
import { useDebouncedValue } from '../hooks/useDebouncedValue.ts';

const errorMessage = (err: unknown) => (err instanceof Error ? err.message : String(err));
import {
  Package,
  Plus,
  Search,
  Trash2,
  Edit2,
  RefreshCw
} from 'lucide-react';

export const ProductsPage: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [feedback, setFeedback] = useState<string | null>(null);

  // Form State
  const [formTitle, setFormTitle] = useState('');
  const [formDesc, setFormDesc] = useState('');
  const [formPrice, setFormPrice] = useState('');
  const [formComparePrice, setFormComparePrice] = useState('');
  const [formCategory, setFormCategory] = useState('Electronics');
  const [formInventory, setFormInventory] = useState('20');
  const [formSku, setFormSku] = useState('');
  const [formImg, setFormImg] = useState('');

  const debouncedSearch = useDebouncedValue(searchTerm);
  const loadProducts = useCallback(
    () => api.products.list({ search: debouncedSearch || undefined, category: selectedCategory || undefined }),
    [debouncedSearch, selectedCategory]
  );
  const { data, error: loadError, isLoading, reload: fetchProducts } = useAsyncResource(loadProducts);
  const products: Product[] = data?.products ?? [];

  const openCreateModal = () => {
    setEditingProduct(null);
    setFormTitle('');
    setFormDesc('');
    setFormPrice('');
    setFormComparePrice('');
    setFormCategory('Electronics');
    setFormInventory('25');
    setFormSku('');
    setFormImg('');
    setIsModalOpen(true);
  };

  const openEditModal = (prod: Product) => {
    setEditingProduct(prod);
    setFormTitle(prod.title);
    setFormDesc(prod.description || '');
    setFormPrice(String(prod.price));
    setFormComparePrice(prod.compare_at_price ? String(prod.compare_at_price) : '');
    setFormCategory(prod.category || 'General');
    setFormInventory(String(prod.inventory));
    setFormSku(prod.sku || '');
    setFormImg(prod.image_url || '');
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingProduct) {
        await api.products.update(editingProduct.id, {
          title: formTitle,
          description: formDesc,
          price: parseFloat(formPrice),
          compare_at_price: formComparePrice ? parseFloat(formComparePrice) : null,
          category: formCategory,
          inventory: parseInt(formInventory, 10),
          sku: formSku,
          image_url: formImg
        });
        setFeedback(`Product '${formTitle}' updated successfully.`);
      } else {
        await api.products.create({
          title: formTitle,
          description: formDesc,
          price: parseFloat(formPrice),
          compare_at_price: formComparePrice ? parseFloat(formComparePrice) : null,
          category: formCategory,
          inventory: parseInt(formInventory, 10),
          sku: formSku,
          image_url: formImg
        });
        setFeedback(`Product '${formTitle}' created in catalog.`);
      }
      setIsModalOpen(false);
      fetchProducts();
    } catch (err) {
      alert(`Error saving product: ${errorMessage(err)}`);
    }
  };

  const handleDelete = async (id: string, title: string) => {
    if (!confirm(`Are you sure you want to delete '${title}'? This immediately removes it from the database.`)) {
      return;
    }
    try {
      await api.products.delete(id);
      setFeedback(`Product '${title}' deleted.`);
      fetchProducts();
    } catch (err) {
      alert(`Error: ${errorMessage(err)}`);
    }
  };

  return (
    <div className="flex-1 p-6 space-y-6 overflow-y-auto">
      <LoadError error={loadError} onRetry={fetchProducts} what="products" />
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            Product Catalog & Inventory
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20">
              {products.length} Products
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Manage your store items, pricing, real-time stock levels, and SKUs.
          </p>
        </div>

        <button
          onClick={openCreateModal}
          className="flex items-center space-x-1.5 px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-xs font-semibold text-white shadow-lg shadow-blue-500/25 border border-blue-400/30 transition-colors shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Product</span>
        </button>
      </div>

      {feedback && (
        <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs flex items-center justify-between animate-in fade-in">
          <span>{feedback}</span>
          <button onClick={() => setFeedback(null)} className="text-emerald-400 font-bold ml-4">
            ×
          </button>
        </div>
      )}

      {/* Filter / Search bar */}
      <div className="flex flex-col sm:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search by title, SKU, or keyword..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-blue-500"
          />
        </div>

        <select
          value={selectedCategory}
          onChange={(e) => setSelectedCategory(e.target.value)}
          className="w-full sm:w-48 py-2 px-3 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-200 focus:outline-none focus:border-blue-500"
        >
          <option value="">All Categories</option>
          <option value="Audio">Audio</option>
          <option value="Computers">Computers</option>
          <option value="Workstation">Workstation</option>
          <option value="Accessories">Accessories</option>
          <option value="Tops">Tops</option>
          <option value="Outerwear">Outerwear</option>
          <option value="General">General</option>
        </select>

        <button
          onClick={fetchProducts}
          className="p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white border border-slate-700 transition-colors"
          title="Reload products"
        >
          <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {/* Products Table */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/60 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-800/40 text-[10px] text-slate-400 uppercase tracking-wider border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Product Details</th>
                <th className="py-3 px-4">SKU</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Price</th>
                <th className="py-3 px-4">Inventory</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {products.map((prod) => (
                <tr key={prod.id} className="hover:bg-slate-800/30 transition-colors">
                  <td className="py-3 px-4 flex items-center space-x-3">
                    <img
                      src={prod.image_url || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&auto=format&fit=crop&q=80'}
                      alt={prod.title}
                      className="w-10 h-10 rounded-lg object-cover bg-slate-800 border border-slate-700 shrink-0"
                    />
                    <div>
                      <div className="font-semibold text-white">{prod.title}</div>
                      <div className="text-[11px] text-slate-400 line-clamp-1 max-w-sm">
                        {prod.description}
                      </div>
                    </div>
                  </td>
                  <td className="py-3 px-4 font-mono text-slate-400">{prod.sku}</td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-slate-800 text-slate-300 border border-slate-700">
                      {prod.category}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-semibold text-white">
                    ${prod.price.toFixed(2)}
                    {prod.compare_at_price && (
                      <span className="ml-1.5 text-[10px] line-through text-slate-500">
                        ${prod.compare_at_price.toFixed(2)}
                      </span>
                    )}
                  </td>
                  <td className="py-3 px-4">
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                        prod.inventory > 10
                          ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                          : prod.inventory > 0
                          ? 'bg-amber-500/10 text-amber-400 border-amber-500/20'
                          : 'bg-rose-500/10 text-rose-400 border-rose-500/20'
                      }`}
                    >
                      {prod.inventory > 0 ? `${prod.inventory} in stock` : 'Out of Stock'}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right space-x-2">
                    <button
                      onClick={() => openEditModal(prod)}
                      className="p-1.5 rounded-lg bg-slate-800 hover:bg-blue-600/20 text-slate-300 hover:text-blue-400 border border-slate-700 transition-colors"
                      title="Edit product"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleDelete(prod.id, prod.title)}
                      className="p-1.5 rounded-lg bg-slate-800 hover:bg-rose-600/20 text-slate-300 hover:text-rose-400 border border-slate-700 transition-colors"
                      title="Delete product"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
              {products.length === 0 && !isLoading && (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-500">
                    <Package className="w-8 h-8 mx-auto mb-2 opacity-40" />
                    No products found matching the criteria. Click "Add New Product" to populate your catalog.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-lg w-full p-6 shadow-2xl animate-in zoom-in-95">
            <h2 className="text-lg font-bold text-white mb-1">
              {editingProduct ? 'Edit Product' : 'Add New Product to Catalog'}
            </h2>
            <p className="text-xs text-slate-400 mb-4">
              Saved changes are committed directly to the merchant's MongoDB catalog.
            </p>

            <form onSubmit={handleSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Product Title *</label>
                <input
                  type="text"
                  required
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none focus:border-blue-500"
                  placeholder="e.g. Ultra Gaming Headphones"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Description</label>
                <textarea
                  rows={2}
                  value={formDesc}
                  onChange={(e) => setFormDesc(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none focus:border-blue-500"
                  placeholder="Key features and technical specifications"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Price ($) *</label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={formPrice}
                    onChange={(e) => setFormPrice(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none focus:border-blue-500"
                    placeholder="99.99"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Compare At Price ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={formComparePrice}
                    onChange={(e) => setFormComparePrice(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none focus:border-blue-500"
                    placeholder="129.99"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Category</label>
                  <input
                    type="text"
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none focus:border-blue-500"
                    placeholder="Electronics"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Inventory Quantity *</label>
                  <input
                    type="number"
                    required
                    value={formInventory}
                    onChange={(e) => setFormInventory(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none focus:border-blue-500"
                    placeholder="50"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">SKU</label>
                  <input
                    type="text"
                    value={formSku}
                    onChange={(e) => setFormSku(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none focus:border-blue-500"
                    placeholder="SKU-AUTO"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Image URL</label>
                  <input
                    type="url"
                    value={formImg}
                    onChange={(e) => setFormImg(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none focus:border-blue-500"
                    placeholder="https://images.unsplash.com/..."
                  />
                </div>
              </div>

              <div className="flex items-center justify-end space-x-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-300 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-xs font-semibold text-white shadow-lg shadow-blue-500/25 transition-colors"
                >
                  {editingProduct ? 'Save Changes' : 'Create Product'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
