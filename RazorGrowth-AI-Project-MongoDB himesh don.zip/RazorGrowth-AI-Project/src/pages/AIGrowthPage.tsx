import React, { useState } from 'react';
import { api } from '../api/client.ts';
import type { AIInsight } from '../types/index.ts';
import { useAsyncResource } from '../hooks/useAsyncResource.ts';
import { LoadError } from '../components/LoadError.tsx';
import {
  Sparkles,
  Flame,
  ArrowUpRight,
  TrendingUp,
  Package,
  Cpu
} from 'lucide-react';

const errorMessage = (err: unknown) => (err instanceof Error ? err.message : String(err));
const loadInsights = () => api.ai.getInsights();

interface AIGrowthPageProps {
  onNavigate: (view: string) => void;
}

export const AIGrowthPage: React.FC<AIGrowthPageProps> = ({ onNavigate }) => {
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  const { data, error: loadError, isLoading, reload: fetchInsights } = useAsyncResource(loadInsights);
  const insights: AIInsight[] = data?.insights ?? [];
  const liveAnalytics = data?.liveAnalytics ?? null;

  const handleGenerateOpportunity = async () => {
    setIsGenerating(true);
    setFeedback(null);
    try {
      const res = await api.ai.generateOpportunity();
      setFeedback(`Discovered new growth lever: '${res.insight.title}'. An autonomous agent task was staged for human approval!`);
      fetchInsights();
    } catch (err) {
      setFeedback(`Generation Error: ${errorMessage(err)}`);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="flex-1 p-6 space-y-6 overflow-y-auto">
      <LoadError error={loadError} onRetry={fetchInsights} what="AI insights" />
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            AI Growth Center
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
              Active Telemetry
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Data-driven intelligence engine identifying revenue leakage, conversion bottlenecks, and autonomous lift strategies.
          </p>
        </div>

        <button
          onClick={handleGenerateOpportunity}
          disabled={isGenerating}
          className="flex items-center space-x-2 px-4 py-2 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-xs font-semibold text-white shadow-lg shadow-blue-500/25 border border-blue-400/30 transition-all disabled:opacity-50 shrink-0"
        >
          <Sparkles className="w-4 h-4" />
          <span>{isGenerating ? 'Analyzing Store Telemetry...' : 'Discover New Growth Opportunity'}</span>
        </button>
      </div>

      {feedback && (
        <div className="p-3 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 text-xs flex items-center justify-between animate-in fade-in">
          <span>{feedback}</span>
          <button onClick={() => setFeedback(null)} className="text-indigo-400 font-bold ml-4">
            ×
          </button>
        </div>
      )}

      {/* Live Observability Telemetry Cards */}
      {liveAnalytics && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="rounded-xl border border-rose-500/30 bg-rose-950/20 p-4">
            <div className="flex items-center justify-between text-xs text-slate-300">
              <span className="font-medium">Identified Revenue Leakage</span>
              <Flame className="w-4 h-4 text-rose-400" />
            </div>
            <div className="text-2xl font-bold text-rose-400 mt-2">
              ${liveAnalytics.revenueLeakageDetected.toFixed(2)}
            </div>
            <div className="text-[11px] text-slate-400 mt-1">
              {liveAnalytics.failedTransactionsCount} failed payment attempts recorded
            </div>
          </div>

          <div className="rounded-xl border border-amber-500/30 bg-amber-950/20 p-4">
            <div className="flex items-center justify-between text-xs text-slate-300">
              <span className="font-medium">Inventory Stock Warnings</span>
              <Package className="w-4 h-4 text-amber-400" />
            </div>
            <div className="text-2xl font-bold text-amber-400 mt-2">
              {liveAnalytics.lowStockProductsCount} Products
            </div>
            <div className="text-[11px] text-slate-400 mt-1">
              Stock under 20 units risks stockout during promotions
            </div>
          </div>

          <div className="rounded-xl border border-indigo-500/30 bg-indigo-950/20 p-4">
            <div className="flex items-center justify-between text-xs text-slate-300">
              <span className="font-medium">Autonomous Agent Pipeline</span>
              <Cpu className="w-4 h-4 text-indigo-400" />
            </div>
            <div className="text-2xl font-bold text-indigo-400 mt-2">
              {insights.filter((i) => i.status === 'ACTIVE').length} Active
            </div>
            <div className="text-[11px] text-slate-400 mt-1">
              Awaiting human authorization or currently executing
            </div>
          </div>
        </div>
      )}

      {/* Insights List */}
      <div className="space-y-4">
        <h2 className="text-sm font-bold text-white uppercase tracking-wider text-slate-300">
          Identified Growth Levers & Strategic Recommendations
        </h2>

        <div className="grid grid-cols-1 gap-4">
          {insights.map((ins) => (
            <div
              key={ins.id}
              className="rounded-2xl border border-slate-800 bg-slate-900/60 p-5 hover:border-slate-700 transition-colors shadow-lg space-y-3"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex items-center space-x-2">
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-indigo-500/15 text-indigo-400 border border-indigo-500/30">
                    {ins.category.replace('_', ' ')}
                  </span>
                  <span className="text-[10px] text-slate-500 font-mono">
                    ID: {ins.id}
                  </span>
                </div>

                <div className="flex items-center space-x-3">
                  <div className="text-right">
                    <span className="text-[10px] text-slate-400 block">Est. Revenue Lift</span>
                    <span className="text-sm font-bold text-emerald-400 flex items-center gap-0.5 justify-end">
                      <TrendingUp className="w-3.5 h-3.5" />
                      +${ins.potential_revenue_lift.toFixed(2)}/mo
                    </span>
                  </div>
                  <div className="pl-3 border-l border-slate-800">
                    <span className="text-[10px] text-slate-400 block">Impact Score</span>
                    <span className="text-sm font-extrabold text-white">
                      {ins.impact_score}/100
                    </span>
                  </div>
                </div>
              </div>

              <h3 className="text-base font-bold text-white">{ins.title}</h3>
              <p className="text-xs text-slate-300 leading-relaxed">{ins.summary}</p>

              <div className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/60">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-blue-400 mb-1">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Autonomous Agent Recommendation:</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">{ins.recommendation}</p>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-slate-800/60 text-xs">
                <span className="text-[11px] text-slate-500">
                  Status:{' '}
                  <span className={`font-semibold ${ins.status === 'ACTIVE' ? 'text-amber-400' : 'text-emerald-400'}`}>
                    {ins.status}
                  </span>
                </span>

                <div className="space-x-2">
                  <button
                    onClick={() => onNavigate('approvals')}
                    className="px-3.5 py-1.5 rounded-lg bg-indigo-600/20 hover:bg-indigo-600 text-indigo-300 hover:text-white border border-indigo-500/30 text-xs font-semibold transition-colors inline-flex items-center gap-1"
                  >
                    <span>View Staged Agent Approval</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}

          {insights.length === 0 && !isLoading && (
            <div className="p-8 text-center text-slate-500 rounded-xl border border-slate-800 bg-slate-900/40">
              <Sparkles className="w-8 h-8 mx-auto mb-2 opacity-40 text-blue-400" />
              <p className="text-sm font-medium text-slate-300">No opportunities detected yet.</p>
              <p className="text-xs text-slate-500 mt-1">
                Click "Discover New Growth Opportunity" above to analyze your database telemetry.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
