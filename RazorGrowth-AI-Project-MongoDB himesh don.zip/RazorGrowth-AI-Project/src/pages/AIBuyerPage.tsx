import React, { useEffect, useRef, useState } from 'react';
import { api } from '../api/client.ts';
import { useAuth } from '../context/useAuth.ts';
import type { Product, CartItem, Order, Payment } from '../types/index.ts';
import { shortId } from '../lib/format.ts';
import {
  Search,
  ShoppingBag,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  CreditCard,
  Trash2,
  Plus,
  Minus,
  ArrowRight,
  Columns,
  X,
  PackageCheck
} from 'lucide-react';

interface AIBuyerPageProps {
  onNavigate: (view: string) => void;
  onRefreshStats?: () => void;
}

const SESSION_KEY = 'razorgrowth_buyer_session_id';

const errorMessage = (err: unknown) => (err instanceof Error ? err.message : String(err));

// Opaque, unguessable storefront session id (identifies the shopper's cart).
function loadOrCreateSessionId(): string {
  const fresh = () =>
    'buyer_' +
    (typeof crypto !== 'undefined' && 'randomUUID' in crypto
      ? crypto.randomUUID().replace(/-/g, '')
      : Array.from({ length: 4 }, () => Math.random().toString(36).slice(2, 10)).join(''));
  try {
    const existing = localStorage.getItem(SESSION_KEY);
    if (existing && /^[A-Za-z0-9_-]{8,128}$/.test(existing)) return existing;
    const created = fresh();
    localStorage.setItem(SESSION_KEY, created);
    return created;
  } catch {
    return fresh();
  }
}

export const AIBuyerPage: React.FC<AIBuyerPageProps> = ({ onNavigate, onRefreshStats }) => {
  const { merchant } = useAuth();
  const [sessionId] = useState<string>(loadOrCreateSessionId);

  const [searchQuery, setSearchQuery] = useState<string>('');
  const [products, setProducts] = useState<Product[]>([]);
  const [isSearching, setIsSearching] = useState<boolean>(true);
  const searchSeq = useRef(0);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);

  // Comparison State
  const [compareIds, setCompareIds] = useState<string[]>([]);
  const [compareProducts, setCompareProducts] = useState<Product[]>([]);
  const [isCompareOpen, setIsCompareOpen] = useState<boolean>(false);

  // Checkout & Payment Simulation Modal State
  const [isCheckoutOpen, setIsCheckoutOpen] = useState<boolean>(false);
  const [customerName, setCustomerName] = useState<string>('');
  const [customerEmail, setCustomerEmail] = useState<string>('');
  const [customerPhone, setCustomerPhone] = useState<string>('');
  const [createdOrder, setCreatedOrder] = useState<Order | null>(null);
  const [createdPayment, setCreatedPayment] = useState<Payment | null>(null);
  const [isProcessingCheckout, setIsProcessingCheckout] = useState<boolean>(false);
  const [isSimulatingPayment, setIsSimulatingPayment] = useState<boolean>(false);
  const [paymentSimulationResult, setPaymentSimulationResult] = useState<{
    success: boolean;
    status: string;
    message: string;
  } | null>(null);

  const merchantId = merchant?.id || '';

  // Runs a catalog search; responses to superseded searches are ignored.
  const executeSearch = async (q: string = searchQuery) => {
    if (!merchantId) return;
    const seq = ++searchSeq.current;
    setIsSearching(true);
    try {
      const res = await api.buyer.search({ merchantId, query: q });
      if (seq === searchSeq.current) setProducts(res.results);
    } catch (err) {
      console.error('Buyer search error:', err);
    } finally {
      if (seq === searchSeq.current) setIsSearching(false);
    }
  };

  // Load the catalog and the persisted cart when the storefront opens.
  useEffect(() => {
    if (!merchantId) return;
    let cancelled = false;
    const seq = ++searchSeq.current;
    api.buyer
      .search({ merchantId, query: '' })
      .then((res) => {
        if (!cancelled && seq === searchSeq.current) setProducts(res.results);
      })
      .catch((err: unknown) => console.error('Buyer search error:', err))
      .finally(() => {
        if (!cancelled && seq === searchSeq.current) setIsSearching(false);
      });
    api.buyer
      .getCart(merchantId, sessionId)
      .then((res) => {
        if (!cancelled) setCartItems(res.items);
      })
      .catch((err: unknown) => console.error('Failed to fetch cart:', err));
    return () => {
      cancelled = true;
    };
  }, [merchantId, sessionId]);

  const handleAddToCart = async (product: Product) => {
    try {
      const res = await api.buyer.addToCart({
        merchantId,
        sessionId,
        productId: product.id,
        quantity: 1
      });
      setCartItems(res.items);
      setIsCartOpen(true);
    } catch (err) {
      alert(`Could not add to cart: ${errorMessage(err)}`);
    }
  };

  const handleUpdateQuantity = async (productId: string, qty: number) => {
    try {
      const res = await api.buyer.updateCartItem(productId, {
        merchantId,
        sessionId,
        quantity: qty
      });
      setCartItems(res.items);
    } catch (err) {
      alert(errorMessage(err));
    }
  };

  const handleRemoveItem = async (productId: string) => {
    try {
      const res = await api.buyer.removeCartItem(productId, merchantId, sessionId);
      setCartItems(res.items);
    } catch (err) {
      alert(errorMessage(err));
    }
  };

  // Toggle compare
  const toggleCompare = async (product: Product) => {
    let nextIds: string[];
    if (compareIds.includes(product.id)) {
      nextIds = compareIds.filter((id) => id !== product.id);
    } else {
      if (compareIds.length >= 3) {
        alert('You can compare up to 3 products at a time.');
        return;
      }
      nextIds = [...compareIds, product.id];
    }
    setCompareIds(nextIds);

    if (nextIds.length > 0) {
      try {
        const res = await api.buyer.compare({ merchantId, productIds: nextIds });
        setCompareProducts(res.products);
        setIsCompareOpen(true);
      } catch (err) {
        alert(`Could not compare products: ${errorMessage(err)}`);
      }
    } else {
      setCompareProducts([]);
      setIsCompareOpen(false);
    }
  };

  // Initiate Checkout
  const handleStartCheckout = () => {
    if (cartItems.length === 0) return;
    setIsCartOpen(false);
    setCreatedOrder(null);
    setCreatedPayment(null);
    setPaymentSimulationResult(null);
    setIsCheckoutOpen(true);
  };

  // Submit Order Creation
  const handleProceedToPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessingCheckout(true);
    try {
      const res = await api.buyer.checkout({
        merchantId,
        customerName,
        customerEmail,
        customerPhone: customerPhone.trim() || undefined,
        items: cartItems.map((i) => ({ productId: i.productId, quantity: i.quantity })),
        sessionId
      });

      setCreatedOrder(res.order);
      setCreatedPayment(res.payment);
      setCartItems([]); // Cleared in cart table upon successful checkout
    } catch (err) {
      alert(`Checkout Validation Failed: ${errorMessage(err)}`);
    } finally {
      setIsProcessingCheckout(false);
    }
  };

  // Simulate Payment Outcome
  const handleSimulatePayment = async (outcome: 'SUCCESS' | 'FAILURE') => {
    if (!createdOrder) return;
    setIsSimulatingPayment(true);
    try {
      const res = await api.payments.simulate({
        orderId: createdOrder.id,
        // One-time secret from checkout: authorises paying this order as the buyer.
        clientSecret: createdPayment?.client_secret,
        outcome,
        failureReason: outcome === 'FAILURE' ? '3DS Authentication Failed: Bank declined transaction' : undefined,
        paymentMethod: outcome === 'SUCCESS' ? 'Visa ending in 4242' : 'Mastercard ending in 9122'
      });

      setPaymentSimulationResult({
        success: res.success,
        status: res.status,
        message: res.message
      });

      if (res.order) {
        setCreatedOrder(res.order);
      }

      if (onRefreshStats) {
        onRefreshStats();
      }
    } catch (err) {
      alert(`Simulation Error: ${errorMessage(err)}`);
    } finally {
      setIsSimulatingPayment(false);
    }
  };

  const cartSubtotal = cartItems.reduce((acc, item) => acc + item.subtotal, 0);

  return (
    <div className="flex-1 p-6 space-y-6 overflow-y-auto relative">
      {/* AI Buyer Storefront Header */}
      <div className="rounded-3xl border border-purple-500/30 bg-gradient-to-r from-purple-950/40 via-slate-900 to-indigo-950/40 p-6 md:p-8 relative overflow-hidden shadow-2xl">
        <div className="max-w-3xl space-y-3 relative z-10">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5 text-purple-400" />
            <span>Autonomous AI Buyer Agent Storefront • {merchant?.name}</span>
          </div>

          <h1 className="text-2xl md:text-4xl font-extrabold text-white tracking-tight">
            Find the exact product with natural language.
          </h1>

          <p className="text-xs md:text-sm text-slate-300">
            Ask for specifications, budget constraints, or feature comparisons. The AI ranking engine analyzes real-time inventory and pricing from MongoDB.
          </p>

          {/* Search Form */}
          <div className="pt-2">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                executeSearch();
              }}
              className="relative flex items-center shadow-2xl rounded-2xl overflow-hidden border border-purple-500/40 bg-slate-900/90"
            >
              <Search className="w-5 h-5 absolute left-4 text-purple-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Try: 'fast gaming laptop with 32gb under 2000' or 'noise cancelling headphones'..."
                className="w-full pl-12 pr-28 py-3.5 bg-transparent text-sm text-white placeholder-slate-400 focus:outline-none"
              />
              <button
                type="submit"
                className="absolute right-2 px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold transition-colors flex items-center gap-1.5 shadow-lg shadow-purple-600/30"
              >
                <span>Search</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </form>

            {/* Quick Suggestion Chips */}
            <div className="flex flex-wrap gap-2 mt-3 text-xs">
              <span className="text-slate-400 self-center text-[11px]">Quick Prompts:</span>
              {[
                'Laptop under 2000',
                'Noise-cancelling headphones',
                'Standing desk',
                'Fast charger'
              ].map((chip) => (
                <button
                  key={chip}
                  onClick={() => {
                    setSearchQuery(chip);
                    executeSearch(chip);
                  }}
                  className="px-2.5 py-1 rounded-lg bg-slate-800/80 hover:bg-purple-900/40 text-slate-300 hover:text-white border border-slate-700 text-[11px] transition-colors"
                >
                  "{chip}"
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Floating Cart Button */}
        <button
          onClick={() => setIsCartOpen(true)}
          className="absolute top-6 right-6 flex items-center space-x-2 px-4 py-2.5 rounded-2xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs shadow-xl shadow-purple-600/30 border border-purple-400/40 transition-all hover:scale-105"
        >
          <ShoppingBag className="w-4 h-4" />
          <span>Cart ({cartItems.reduce((acc, i) => acc + i.quantity, 0)})</span>
          {cartSubtotal > 0 && <span className="ml-1 text-purple-200">${cartSubtotal.toFixed(2)}</span>}
        </button>
      </div>

      {/* Product Grid */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <span>AI Ranked Catalog Results</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 border border-slate-700">
              {products.length} Items Available
            </span>
          </h2>

          {compareIds.length > 0 && (
            <button
              onClick={() => setIsCompareOpen(true)}
              className="text-xs font-semibold text-purple-400 hover:text-purple-300 flex items-center gap-1.5"
            >
              <Columns className="w-4 h-4" />
              <span>Compare Selected ({compareIds.length})</span>
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {products.map((prod) => {
            const isComparing = compareIds.includes(prod.id);

            return (
              <div
                key={prod.id}
                className="rounded-2xl border border-slate-800 bg-slate-900/70 p-4 hover:border-purple-500/40 transition-all duration-200 shadow-lg flex flex-col justify-between space-y-4 group"
              >
                <div>
                  {/* Product Image & AI Score Badge */}
                  <div className="relative rounded-xl overflow-hidden bg-slate-800 h-48 mb-3">
                    <img
                      src={prod.image_url || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&auto=format&fit=crop&q=80'}
                      alt={prod.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />

                    {/* Match Score Badge */}
                    {prod.matchScore && (
                      <div className="absolute top-2.5 left-2.5 px-2.5 py-1 rounded-full bg-slate-950/80 backdrop-blur-md border border-purple-500/30 text-purple-300 text-[11px] font-bold flex items-center gap-1 shadow-lg">
                        <Sparkles className="w-3 h-3 text-purple-400" />
                        <span>{prod.matchScore}% Match</span>
                      </div>
                    )}

                    {/* Compare Checkbox */}
                    <button
                      onClick={() => toggleCompare(prod)}
                      className={`absolute top-2.5 right-2.5 px-2 py-1 rounded-lg text-[10px] font-bold backdrop-blur-md border transition-all ${
                        isComparing
                          ? 'bg-purple-600 text-white border-purple-400'
                          : 'bg-slate-900/80 text-slate-300 border-slate-700 hover:text-white'
                      }`}
                    >
                      {isComparing ? '✓ Comparing' : '+ Compare'}
                    </button>
                  </div>

                  <div className="flex items-baseline justify-between mb-1">
                    <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                      {prod.category}
                    </span>
                    <span className="text-[10px] font-mono text-slate-500">
                      Stock: {prod.inventory}
                    </span>
                  </div>

                  <h3 className="text-sm font-bold text-white group-hover:text-purple-300 transition-colors line-clamp-1">
                    {prod.title}
                  </h3>

                  <p className="text-xs text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                    {prod.description}
                  </p>

                  {/* AI Match Explanation */}
                  {prod.matchReason && (
                    <div className="mt-2.5 p-2 rounded-lg bg-purple-950/20 border border-purple-500/20 text-[11px] text-purple-300 flex items-start gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-purple-400 shrink-0 mt-0.5" />
                      <span className="line-clamp-2">{prod.matchReason}</span>
                    </div>
                  )}
                </div>

                <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between">
                  <div>
                    <span className="text-base font-extrabold text-white">
                      ${prod.price.toFixed(2)}
                    </span>
                    {prod.compare_at_price && (
                      <span className="ml-1.5 text-xs line-through text-slate-500">
                        ${prod.compare_at_price.toFixed(2)}
                      </span>
                    )}
                  </div>

                  <button
                    onClick={() => handleAddToCart(prod)}
                    disabled={prod.inventory <= 0}
                    className="px-3.5 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold shadow-lg shadow-purple-600/25 transition-all disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1.5"
                  >
                    <ShoppingBag className="w-3.5 h-3.5" />
                    <span>{prod.inventory > 0 ? 'Add to Cart' : 'Out of Stock'}</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {products.length === 0 && !isSearching && (
          <div className="p-12 text-center text-slate-500 rounded-2xl border border-slate-800 bg-slate-900/40">
            <Search className="w-8 h-8 mx-auto mb-2 opacity-40 text-purple-400" />
            <p className="text-sm font-semibold text-slate-300">No matching products found.</p>
            <p className="text-xs text-slate-500 mt-1">
              Try a broader query or switch merchant workspace from the top menu.
            </p>
          </div>
        )}
      </div>

      {/* Cart Drawer */}
      {isCartOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden bg-black/60 backdrop-blur-sm">
          <div className="absolute inset-y-0 right-0 max-w-md w-full bg-slate-900 border-l border-slate-800 shadow-2xl p-6 flex flex-col justify-between animate-in slide-in-from-right duration-200">
            <div>
              <div className="flex items-center justify-between pb-4 border-b border-slate-800">
                <div className="flex items-center space-x-2">
                  <ShoppingBag className="w-5 h-5 text-purple-400" />
                  <h2 className="text-base font-bold text-white">Your Shopping Cart</h2>
                </div>
                <button
                  onClick={() => setIsCartOpen(false)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="mt-4 space-y-3 max-h-[calc(100vh-280px)] overflow-y-auto pr-1">
                {cartItems.map((item) => (
                  <div
                    key={item.productId}
                    className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60 flex items-center justify-between text-xs"
                  >
                    <div className="flex items-center space-x-3">
                      <img
                        src={item.image_url || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&auto=format&fit=crop&q=80'}
                        alt={item.title}
                        className="w-12 h-12 rounded-lg object-cover bg-slate-700"
                      />
                      <div>
                        <div className="font-semibold text-white line-clamp-1 max-w-[160px]">{item.title}</div>
                        <div className="text-slate-400 text-[11px]">${item.price.toFixed(2)} each</div>
                      </div>
                    </div>

                    <div className="flex items-center space-x-3">
                      <div className="flex items-center space-x-1 bg-slate-900 border border-slate-700 rounded-lg px-1 py-0.5">
                        <button
                          onClick={() => handleUpdateQuantity(item.productId, item.quantity - 1)}
                          className="p-1 text-slate-400 hover:text-white"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="font-bold text-white px-1.5">{item.quantity}</span>
                        <button
                          onClick={() => handleUpdateQuantity(item.productId, item.quantity + 1)}
                          className="p-1 text-slate-400 hover:text-white"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>

                      <button
                        onClick={() => handleRemoveItem(item.productId)}
                        className="p-1.5 rounded text-slate-500 hover:text-rose-400"
                        title="Remove"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}

                {cartItems.length === 0 && (
                  <div className="py-12 text-center text-slate-500">
                    <ShoppingBag className="w-10 h-10 mx-auto mb-2 opacity-30 text-purple-400" />
                    <p className="text-xs">Your persistent cart is currently empty.</p>
                  </div>
                )}
              </div>
            </div>

            {/* Cart Footer */}
            <div className="pt-4 border-t border-slate-800 space-y-3">
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400">Cart Storage:</span>
                <span className="font-mono text-emerald-400 text-[11px]">MongoDB Session Synchronized</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-slate-300 font-semibold">Subtotal:</span>
                <span className="font-extrabold text-white text-lg">${cartSubtotal.toFixed(2)}</span>
              </div>

              <button
                disabled={cartItems.length === 0}
                onClick={handleStartCheckout}
                className="w-full py-3 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs shadow-lg shadow-purple-600/30 transition-all disabled:opacity-40 flex items-center justify-center gap-2"
              >
                <span>Proceed to Checkout & Simulation</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Comparison Drawer */}
      {isCompareOpen && (
        <div className="fixed inset-x-0 bottom-0 z-40 bg-slate-900 border-t border-slate-700 p-4 shadow-2xl animate-in slide-in-from-bottom">
          <div className="max-w-6xl mx-auto">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Columns className="w-4 h-4 text-purple-400" />
                <span className="text-xs font-bold text-white uppercase tracking-wider">
                  Product Comparison Matrix ({compareProducts.length}/3)
                </span>
              </div>
              <button
                onClick={() => setIsCompareOpen(false)}
                className="text-xs text-slate-400 hover:text-white"
              >
                Close ×
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {compareProducts.map((p) => (
                <div key={p.id} className="p-3 rounded-xl bg-slate-800/80 border border-slate-700 text-xs space-y-2">
                  <div className="font-bold text-white truncate">{p.title}</div>
                  <div className="text-base font-extrabold text-purple-400">${p.price.toFixed(2)}</div>
                  <div className="text-slate-400 text-[11px]">Category: {p.category} • SKU: {p.sku}</div>
                  <p className="text-[11px] text-slate-300 line-clamp-2">{p.description}</p>
                  <button
                    onClick={() => handleAddToCart(p)}
                    className="w-full py-1 rounded-lg bg-purple-600 hover:bg-purple-500 text-white font-semibold text-[11px]"
                  >
                    Add to Cart
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Checkout & Payment Simulation Modal */}
      {isCheckoutOpen && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-xl w-full p-6 shadow-2xl animate-in zoom-in-95 my-8">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
              <div className="flex items-center space-x-2.5">
                <div className="p-2 rounded-xl bg-purple-600/20 text-purple-400 border border-purple-500/30">
                  <CreditCard className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-base font-bold text-white">Interactive Checkout & Simulation</h2>
                  <span className="text-[11px] text-slate-400">Validated against real backend inventory</span>
                </div>
              </div>
              <button
                onClick={() => setIsCheckoutOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* STEP 1: Before Order Creation */}
            {!createdOrder && (
              <form onSubmit={handleProceedToPayment} className="space-y-4">
                <div className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/60 space-y-2 text-xs">
                  <div className="font-semibold text-slate-300">Order Summary ({cartItems.length} items):</div>
                  {cartItems.map((i) => (
                    <div key={i.productId} className="flex justify-between text-slate-400">
                      <span>{i.title} × {i.quantity}</span>
                      <span className="font-mono text-white">${i.subtotal.toFixed(2)}</span>
                    </div>
                  ))}
                  <div className="pt-2 border-t border-slate-700/60 flex justify-between font-bold text-sm text-white">
                    <span>Total:</span>
                    <span className="text-emerald-400">${cartSubtotal.toFixed(2)}</span>
                  </div>
                </div>

                <div className="space-y-3 text-xs">
                  <div>
                    <label className="block text-slate-300 font-medium mb-1">Customer Full Name *</label>
                    <input
                      type="text"
                      required
                      value={customerName}
                      placeholder="e.g. Jordan Lee"
                      onChange={(e) => setCustomerName(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-purple-500"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-300 font-medium mb-1">Email Address *</label>
                    <input
                      type="email"
                      required
                      value={customerEmail}
                      placeholder="buyer@example.com"
                      onChange={(e) => setCustomerEmail(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-purple-500"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-300 font-medium mb-1">Phone Number</label>
                    <input
                      type="text"
                      value={customerPhone}
                      placeholder="Optional"
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-purple-500"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isProcessingCheckout}
                  className="w-full py-3 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs shadow-lg shadow-purple-600/30 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  <span>{isProcessingCheckout ? 'Validating with MongoDB...' : 'Validate & Initialize Order'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </form>
            )}

            {/* STEP 2: Order Initialized, Interactive Payment Simulation */}
            {createdOrder && (
              <div className="space-y-4 text-xs">
                <div className="p-3.5 rounded-xl bg-blue-500/10 border border-blue-500/30 text-blue-300 flex items-center justify-between">
                  <div>
                    <div className="font-bold text-white text-sm">Order #{shortId(createdOrder.id)} Initialized</div>
                    <div className="text-[11px] text-slate-300 mt-0.5">
                      Status: <span className="font-semibold text-amber-400">{createdOrder.status}</span> • Amount: <span className="font-bold text-white">${createdOrder.total_amount.toFixed(2)}</span>
                    </div>
                  </div>
                  <PackageCheck className="w-5 h-5 text-blue-400" />
                </div>

                {/* Outcome Simulation Banner */}
                {paymentSimulationResult && (
                  <div
                    className={`p-4 rounded-xl border text-xs space-y-1 animate-in fade-in ${
                      paymentSimulationResult.success
                        ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-300'
                        : 'bg-rose-500/15 border-rose-500/30 text-rose-300'
                    }`}
                  >
                    <div className="flex items-center gap-2 font-bold text-sm">
                      {paymentSimulationResult.success ? (
                        <>
                          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                          <span>PAYMENT SUCCESSFUL — ORDER PAID</span>
                        </>
                      ) : (
                        <>
                          <AlertTriangle className="w-4 h-4 text-rose-400" />
                          <span>PAYMENT DECLINED / GATEWAY ERROR</span>
                        </>
                      )}
                    </div>
                    <p className="text-[11px] opacity-90">{paymentSimulationResult.message}</p>
                    <p className="text-[10px] opacity-75 font-mono">
                      Database status updated • Audit log recorded • Revenue metrics recalculated
                    </p>
                  </div>
                )}

                <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700/60 space-y-2">
                  <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider block">
                    Choose Payment Outcome to Simulate:
                  </span>
                  <p className="text-slate-400 leading-relaxed text-[11px]">
                    Simulate either a gateway failure (to verify revenue leakage tracking and retry flow) or success (to verify order becomes PAID, inventory decrements, and dashboard metrics update).
                  </p>

                  <div className="grid grid-cols-2 gap-3 pt-2">
                    <button
                      disabled={isSimulatingPayment || createdOrder.status === 'PAID'}
                      onClick={() => handleSimulatePayment('FAILURE')}
                      className="py-3 px-3 rounded-xl bg-rose-600/20 hover:bg-rose-600 text-rose-300 hover:text-white border border-rose-500/30 font-bold text-xs flex items-center justify-center gap-1.5 transition-all disabled:opacity-50"
                    >
                      <AlertTriangle className="w-4 h-4" />
                      <span>Simulate Failure</span>
                    </button>

                    <button
                      disabled={isSimulatingPayment || createdOrder.status === 'PAID'}
                      onClick={() => handleSimulatePayment('SUCCESS')}
                      className="py-3 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg shadow-emerald-600/30 flex items-center justify-center gap-1.5 transition-all disabled:opacity-50"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Simulate Success</span>
                    </button>
                  </div>
                </div>

                {/* Actions after simulation */}
                <div className="flex items-center justify-between pt-2 border-t border-slate-800">
                  <button
                    onClick={() => {
                      setIsCheckoutOpen(false);
                      onNavigate('orders');
                    }}
                    className="text-xs text-blue-400 hover:text-blue-300 font-semibold"
                  >
                    View in Merchant Orders →
                  </button>

                  <button
                    onClick={() => {
                      setIsCheckoutOpen(false);
                      onNavigate('dashboard');
                    }}
                    className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-white transition-colors"
                  >
                    Go to Executive Dashboard
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
