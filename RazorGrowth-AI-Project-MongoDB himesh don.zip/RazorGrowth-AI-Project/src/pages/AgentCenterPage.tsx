import React, { useState } from 'react';
import { api } from '../api/client.ts';
import type { AgentTask } from '../types/index.ts';
import { useAsyncResource } from '../hooks/useAsyncResource.ts';
import { LoadError } from '../components/LoadError.tsx';
import { shortId } from '../lib/format.ts';
import {
  Bot,
  Plus,
  RefreshCw,
  CheckCircle2,
  AlertTriangle,
  Clock,
  ArrowRight,
  TrendingUp,
  Cpu
} from 'lucide-react';

const errorMessage = (err: unknown) => (err instanceof Error ? err.message : String(err));
const loadAgents = () => api.agents.list();

interface AgentCenterPageProps {
  onNavigate: (view: string) => void;
}

export const AgentCenterPage: React.FC<AgentCenterPageProps> = ({ onNavigate }) => {
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  // Form State
  const [agentTitle, setAgentTitle] = useState('');
  const [agentType, setAgentType] = useState('SMART_RETRY_OPTIMIZER');
  const [triggerReason, setTriggerReason] = useState('');
  const [proposedAction, setProposedAction] = useState('');
  const [impactMetric, setImpactMetric] = useState('');

  const { data, error: loadError, isLoading, reload: fetchAgents } = useAsyncResource(loadAgents);
  const tasks: AgentTask[] = data?.agentTasks ?? [];

  const handleSpawnAgent = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await api.agents.run({
        agentType,
        title: agentTitle,
        triggerReason,
        proposedAction,
        impactMetric
      });
      setFeedback(`Agent '${res.agentTask.title}' spawned and staged for human authorization.`);
      setIsModalOpen(false);
      fetchAgents();
    } catch (err) {
      alert(`Error: ${errorMessage(err)}`);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'COMPLETED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <CheckCircle2 className="w-3 h-3" /> COMPLETED
          </span>
        );
      case 'PENDING_APPROVAL':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20 animate-pulse">
            <Clock className="w-3 h-3" /> PENDING APPROVAL
          </span>
        );
      case 'EXECUTING':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-500/10 text-blue-400 border border-blue-500/20">
            <Cpu className="w-3 h-3 animate-spin" /> EXECUTING
          </span>
        );
      case 'REJECTED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/10 text-rose-400 border border-rose-500/20">
            <AlertTriangle className="w-3 h-3" /> REJECTED
          </span>
        );
      default:
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-slate-800 text-slate-400">
            {status}
          </span>
        );
    }
  };

  return (
    <div className="flex-1 p-6 space-y-6 overflow-y-auto">
      <LoadError error={loadError} onRetry={fetchAgents} what="agent tasks" />
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            Autonomous Agent Orchestration
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20">
              {tasks.length} Agents
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Real-time status monitoring across autonomous retry optimization, dynamic pricing, and cart recovery agents.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={fetchAgents}
            className="flex items-center space-x-1.5 px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-300 border border-slate-700 transition-colors"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>
          <button
            onClick={() => {
              setAgentTitle('Smart Retry & Route Optimizer Agent');
              setAgentType('SMART_RETRY_OPTIMIZER');
              setTriggerReason('Spike in declined authorization on international Mastercard BINs.');
              setProposedAction('Activate instant dynamic fallback to secondary backup merchant gateway.');
              setImpactMetric('Projected +5.8% payment approval rate ($2,400/mo)');
              setIsModalOpen(true);
            }}
            className="flex items-center space-x-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-xs font-semibold text-white shadow-lg shadow-blue-500/25 border border-blue-400/30 transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Spawn Autonomous Agent</span>
          </button>
        </div>
      </div>

      {feedback && (
        <div className="p-3 rounded-xl bg-blue-500/10 border border-blue-500/20 text-blue-300 text-xs flex items-center justify-between animate-in fade-in">
          <span>{feedback}</span>
          <button onClick={() => setFeedback(null)} className="text-blue-400 font-bold ml-4">
            ×
          </button>
        </div>
      )}

      {/* Agents Task Grid */}
      <div className="grid grid-cols-1 gap-4">
        {tasks.map((task) => (
          <div
            key={task.id}
            className="rounded-2xl border border-slate-800 bg-slate-900/60 p-5 hover:border-slate-700 transition-all shadow-lg space-y-4"
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
              <div className="flex items-center space-x-3">
                <div className="p-2.5 rounded-xl bg-blue-600/15 text-blue-400 border border-blue-500/20">
                  <Bot className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">{task.title}</h3>
                  <div className="text-[11px] text-slate-400 font-mono">
                    Type: <span className="text-slate-300">{task.agent_type}</span> • ID: {shortId(task.id)}
                  </div>
                </div>
              </div>

              <div className="flex items-center space-x-3">
                {getStatusBadge(task.status)}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div className="space-y-1">
                <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                  Trigger Telemetry & Rationale
                </span>
                <p className="text-slate-300 bg-slate-800/40 p-3 rounded-xl border border-slate-800 leading-relaxed">
                  {task.trigger_reason}
                </p>
              </div>

              <div className="space-y-1">
                <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                  Proposed Autonomous Action
                </span>
                <p className="text-slate-300 bg-slate-800/40 p-3 rounded-xl border border-slate-800 leading-relaxed">
                  {task.proposed_action}
                </p>
              </div>
            </div>

            {/* Impact Metric & Execution Results */}
            <div className="pt-2 border-t border-slate-800/60 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
              <div className="flex items-center space-x-2 text-emerald-400 font-semibold">
                <TrendingUp className="w-4 h-4" />
                <span>Impact Measurement: {task.impact_metric || 'Telemetry tracking active'}</span>
              </div>

              <div>
                {task.status === 'PENDING_APPROVAL' ? (
                  <button
                    onClick={() => onNavigate('approvals')}
                    className="px-3.5 py-1.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-semibold flex items-center gap-1.5 transition-colors"
                  >
                    <span>Authorize in Approvals</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                ) : (
                  <span className="text-[11px] text-slate-400 italic">
                    {task.execution_result || 'Action approved & executed in production'}
                  </span>
                )}
              </div>
            </div>
          </div>
        ))}

        {tasks.length === 0 && !isLoading && (
          <div className="p-8 text-center text-slate-500 rounded-xl border border-slate-800 bg-slate-900/40">
            <Bot className="w-8 h-8 mx-auto mb-2 opacity-40" />
            <p className="text-sm font-medium text-slate-300">No autonomous agents running.</p>
            <p className="text-xs text-slate-500 mt-1">
              Click "Spawn Autonomous Agent" or generate an opportunity from the AI Growth Center.
            </p>
          </div>
        )}
      </div>

      {/* Spawn Agent Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-lg w-full p-6 shadow-2xl animate-in zoom-in-95">
            <h2 className="text-lg font-bold text-white mb-1">Spawn Autonomous Agent Routine</h2>
            <p className="text-xs text-slate-400 mb-4">
              Configured agent task will be submitted with human-in-the-loop safety gating.
            </p>

            <form onSubmit={handleSpawnAgent} className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Agent Title *</label>
                <input
                  type="text"
                  required
                  value={agentTitle}
                  onChange={(e) => setAgentTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Agent Archetype</label>
                <select
                  value={agentType}
                  onChange={(e) => setAgentType(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none focus:border-blue-500"
                >
                  <option value="SMART_RETRY_OPTIMIZER">SMART_RETRY_OPTIMIZER (Payment Gateway Routing)</option>
                  <option value="CART_RECOVERY_AGENT">CART_RECOVERY_AGENT (Abandonment Interceptor)</option>
                  <option value="DYNAMIC_PRICING_AGENT">DYNAMIC_PRICING_AGENT (Price & Bundle Elasticity)</option>
                  <option value="CHECKOUT_FRICTION_KILLER">CHECKOUT_FRICTION_KILLER (Form & Auth Optimization)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Trigger Reason & Context</label>
                <textarea
                  rows={2}
                  value={triggerReason}
                  onChange={(e) => setTriggerReason(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Proposed Autonomous Action *</label>
                <textarea
                  rows={2}
                  required
                  value={proposedAction}
                  onChange={(e) => setProposedAction(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Projected Impact Measurement</label>
                <input
                  type="text"
                  value={impactMetric}
                  onChange={(e) => setImpactMetric(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none focus:border-blue-500"
                  placeholder="+4.5% payment success lift"
                />
              </div>

              <div className="flex items-center justify-end space-x-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-300 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-xs font-semibold text-white shadow-lg shadow-blue-500/25 transition-colors"
                >
                  Stage Agent
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
