import React from 'react';
import { useAuth } from '../context/useAuth.ts';
import {
  Sparkles,
  Store,
  LogOut,
  Building2,
  ShoppingBag
} from 'lucide-react';

interface NavbarProps {
  currentView: string;
  onNavigate: (view: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentView, onNavigate }) => {
  const { user, merchant, logout } = useAuth();

  return (
    <header className="h-16 border-b border-slate-800 bg-slate-900/90 backdrop-blur-md sticky top-0 z-40 px-4 md:px-6 flex items-center justify-between">
      {/* Left: Brand & Logo */}
      <div className="flex items-center space-x-3">
        <button
          onClick={() => onNavigate('dashboard')}
          className="flex items-center space-x-2.5 text-left group"
        >
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center shadow-lg shadow-blue-500/20 group-hover:scale-105 transition-transform">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <div>
            <span className="font-bold text-lg bg-gradient-to-r from-white via-slate-100 to-slate-400 bg-clip-text text-transparent">
              RazorGrowth <span className="text-blue-500 font-extrabold text-sm px-1.5 py-0.5 rounded bg-blue-500/10 border border-blue-500/20 ml-1">AI</span>
            </span>
            <span className="hidden sm:block text-[10px] text-slate-400 font-medium tracking-wider uppercase">
              Autonomous Merchant Operating System
            </span>
          </div>
        </button>
      </div>

      {/* Middle: Active Merchant Workspace (read-only — merchant is bound to the authenticated session) */}
      {merchant && (
        <div className="flex items-center space-x-2 px-3 py-1.5 rounded-lg bg-slate-800/80 border border-slate-700/80 text-xs text-slate-200 shadow-inner">
          <Building2 className="w-3.5 h-3.5 text-blue-400" />
          <div className="text-left">
            <span className="text-[10px] text-slate-400 block leading-none">Workspace</span>
            <span className="font-semibold text-white leading-tight flex items-center gap-1">
              {merchant.name}
              <span className="text-[9px] bg-slate-700 text-slate-300 px-1 rounded uppercase">
                {merchant.currency}
              </span>
            </span>
          </div>
        </div>
      )}

      {/* Right: Actions, AI Buyer Mode, User Info */}
      <div className="flex items-center space-x-3">
        {/* Toggle AI Buyer Experience */}
        <button
          onClick={() => onNavigate(currentView === 'buyer' ? 'dashboard' : 'buyer')}
          className={`flex items-center space-x-2 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
            currentView === 'buyer'
              ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white border-purple-400/30 shadow-lg shadow-purple-500/25 ring-2 ring-purple-500/30'
              : 'bg-slate-800/80 hover:bg-purple-900/30 text-purple-300 hover:text-white border-purple-500/30'
          }`}
        >
          {currentView === 'buyer' ? (
            <>
              <Store className="w-4 h-4 text-purple-200" />
              <span>Back to Merchant Admin</span>
            </>
          ) : (
            <>
              <ShoppingBag className="w-4 h-4 text-purple-400" />
              <span>Open AI Buyer Storefront</span>
            </>
          )}
        </button>

        {/* User Profile & Logout */}
        {user && (
          <div className="flex items-center space-x-2 pl-2 border-l border-slate-800">
            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-slate-700 to-slate-600 flex items-center justify-center text-xs font-bold text-white border border-slate-600">
              {user.name.charAt(0).toUpperCase()}
            </div>
            <div className="hidden md:block text-left">
              <div className="text-xs font-medium text-white truncate max-w-[100px]">{user.name}</div>
              <div className="text-[10px] text-slate-400 truncate max-w-[100px]">{user.email}</div>
            </div>
            <button
              onClick={logout}
              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
              title="Log out"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </header>
  );
};
