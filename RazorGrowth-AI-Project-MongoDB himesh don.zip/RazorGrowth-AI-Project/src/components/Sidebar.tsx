import React, { useEffect, useState } from 'react';
import { api } from '../api/client.ts';
import {
  LayoutDashboard,
  Package,
  Users,
  ShoppingBag,
  CreditCard,
  Sparkles,
  Bot,
  CheckCircle2,
  FileText,
  Compass
} from 'lucide-react';

interface SidebarProps {
  currentView: string;
  onNavigate: (view: string) => void;
  pendingApprovalsCount?: number;
  activeOpportunitiesCount?: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentView,
  onNavigate,
  pendingApprovalsCount = 0,
  activeOpportunitiesCount = 0
}) => {
  // Live database status from /api/health (null while the first check runs).
  const [dbOnline, setDbOnline] = useState<boolean | null>(null);
  useEffect(() => {
    let cancelled = false;
    const check = () =>
      api.system
        .health()
        .then((h) => !cancelled && setDbOnline(h.database === 'connected'))
        .catch(() => !cancelled && setDbOnline(false));
    void check();
    const timer = setInterval(check, 60_000);
    return () => {
      cancelled = true;
      clearInterval(timer);
    };
  }, []);

  const navItems = [
    { id: 'dashboard', label: 'Executive Dashboard', icon: LayoutDashboard },
    { id: 'products', label: 'Product Catalog', icon: Package },
    { id: 'customers', label: 'Customers CRM', icon: Users },
    { id: 'orders', label: 'Orders & Fulfillment', icon: ShoppingBag },
    { id: 'transactions', label: 'Transactions & Gateways', icon: CreditCard },
    {
      id: 'ai-growth',
      label: 'AI Growth Center',
      icon: Sparkles,
      badge: activeOpportunitiesCount > 0 ? `${activeOpportunitiesCount}` : undefined,
      badgeColor: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30'
    },
    { id: 'agents', label: 'Autonomous Agents', icon: Bot },
    {
      id: 'approvals',
      label: 'Human Approvals',
      icon: CheckCircle2,
      badge: pendingApprovalsCount > 0 ? `${pendingApprovalsCount}` : undefined,
      badgeColor: 'bg-amber-500/20 text-amber-300 border-amber-500/30 animate-pulse'
    },
    { id: 'audit-logs', label: 'Audit Trail & Compliance', icon: FileText },
    {
      id: 'buyer',
      label: 'AI Buyer Storefront',
      icon: Compass,
      special: true
    }
  ];

  return (
    <aside className="w-64 border-r border-slate-800 bg-slate-900/60 p-4 flex flex-col justify-between shrink-0">
      <div className="space-y-6">
        <div>
          <div className="px-3 mb-2 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
            Management & Operations
          </div>
          <nav className="space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentView === item.id;

              return (
                <button
                  key={item.id}
                  onClick={() => onNavigate(item.id)}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                    item.special
                      ? isActive
                        ? 'bg-purple-600 text-white shadow-lg shadow-purple-500/20'
                        : 'text-purple-300 hover:bg-purple-950/40 hover:text-white border border-purple-500/20'
                      : isActive
                      ? 'bg-blue-600/20 text-blue-400 border border-blue-500/30'
                      : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                  }`}
                >
                  <div className="flex items-center space-x-2.5">
                    <Icon className={`w-4 h-4 ${isActive ? 'text-blue-400' : 'text-slate-400'}`} />
                    <span>{item.label}</span>
                  </div>
                  {item.badge && (
                    <span className={`text-[10px] px-1.5 py-0.5 rounded-full border font-bold ${item.badgeColor}`}>
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>
      </div>

      {/* System Status Card */}
      <div className="rounded-xl border border-slate-800 bg-slate-800/40 p-3 text-left">
        <div className="flex items-center justify-between mb-1.5">
          <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">System State</span>
          <span className={`flex items-center gap-1.5 text-[10px] font-medium ${dbOnline === false ? 'text-rose-400' : 'text-emerald-400'}`}>
            <span className={`w-1.5 h-1.5 rounded-full ${dbOnline === false ? 'bg-rose-400' : 'bg-emerald-400 animate-ping'}`} />
            {dbOnline === false ? 'Degraded' : 'Active'}
          </span>
        </div>
        <div className="text-[11px] text-slate-300 font-mono">
          MongoDB: {dbOnline === null ? 'CHECKING…' : dbOnline ? 'CONNECTED' : 'UNAVAILABLE'}
        </div>
        <div className="text-[10px] text-slate-400">Multi-tenant isolation active</div>
      </div>
    </aside>
  );
};
