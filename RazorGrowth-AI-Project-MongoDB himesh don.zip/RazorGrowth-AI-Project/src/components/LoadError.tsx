import React from 'react';
import { AlertTriangle } from 'lucide-react';

interface LoadErrorProps {
  error: Error | null;
  onRetry: () => void;
  what?: string;
}

/** Inline banner shown when a page's data request fails. */
export const LoadError: React.FC<LoadErrorProps> = ({ error, onRetry, what = 'data' }) => {
  if (!error) return null;
  return (
    <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs flex items-center justify-between gap-3">
      <span className="flex items-center gap-2">
        <AlertTriangle className="w-4 h-4 shrink-0" />
        <span>
          Could not load {what}: {error.message}
        </span>
      </span>
      <button
        onClick={onRetry}
        className="px-2.5 py-1 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-200 font-semibold shrink-0"
      >
        Retry
      </button>
    </div>
  );
};
