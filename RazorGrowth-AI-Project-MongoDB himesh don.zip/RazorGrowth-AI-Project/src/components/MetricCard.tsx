import React from 'react';
import type { LucideIcon } from 'lucide-react';

interface MetricCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: LucideIcon;
  trend?: string;
  trendType?: 'positive' | 'negative' | 'neutral' | 'warning';
  badge?: string;
  highlight?: boolean;
}

export const MetricCard: React.FC<MetricCardProps> = ({
  title,
  value,
  subtitle,
  icon: Icon,
  trend,
  trendType = 'positive',
  badge,
  highlight = false
}) => {
  const getTrendColor = () => {
    switch (trendType) {
      case 'positive':
        return 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20';
      case 'negative':
        return 'text-rose-400 bg-rose-500/10 border-rose-500/20';
      case 'warning':
        return 'text-amber-400 bg-amber-500/10 border-amber-500/20';
      default:
        return 'text-slate-400 bg-slate-500/10 border-slate-500/20';
    }
  };

  return (
    <div
      className={`rounded-xl border p-4 transition-all duration-200 ${
        highlight
          ? 'bg-gradient-to-br from-blue-950/40 via-slate-900 to-indigo-950/30 border-blue-500/40 shadow-lg shadow-blue-500/10'
          : 'bg-slate-900/60 hover:bg-slate-900/80 border-slate-800/80'
      }`}
    >
      <div className="flex items-center justify-between">
        <span className="text-xs font-medium text-slate-400">{title}</span>
        <div className={`p-2 rounded-lg ${highlight ? 'bg-blue-500/20 text-blue-400' : 'bg-slate-800 text-slate-300'}`}>
          <Icon className="w-4 h-4" />
        </div>
      </div>

      <div className="mt-3 flex items-baseline justify-between">
        <div className="text-2xl font-bold text-white tracking-tight">{value}</div>
        {badge && (
          <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full border bg-slate-800 border-slate-700 text-slate-300">
            {badge}
          </span>
        )}
      </div>

      {(subtitle || trend) && (
        <div className="mt-2 flex items-center justify-between text-xs">
          {subtitle && <span className="text-slate-400 truncate">{subtitle}</span>}
          {trend && (
            <span className={`text-[10px] font-medium px-1.5 py-0.5 rounded border ${getTrendColor()}`}>
              {trend}
            </span>
          )}
        </div>
      )}
    </div>
  );
};
