// Shapes returned by the RazorGrowth AI API. IDs are MongoDB ObjectIds
// serialised as 24-character hex strings; money fields are decimal numbers.

export interface User {
  id: string;
  merchantId: string;
  name: string;
  email: string;
  role: string;
}

export interface Merchant {
  id: string;
  name: string;
  slug: string;
  email: string;
  currency: string;
  settings?: Record<string, unknown>;
  created_at?: string | null;
  updated_at?: string | null;
}

export interface Pagination {
  total: number;
  limit: number;
  offset: number;
}

export interface Product {
  id: string;
  merchant_id: string;
  title: string;
  description: string;
  price: number;
  compare_at_price?: number | null;
  category: string;
  inventory: number;
  sku: string;
  image_url: string;
  status: 'active' | 'archived';
  created_at?: string | null;
  updated_at?: string | null;
  matchScore?: number;
  matchReason?: string;
  isInStock?: boolean;
}

export interface Customer {
  id: string;
  merchant_id: string;
  name: string;
  email: string;
  phone?: string | null;
  total_spent: number;
  orders_count: number;
  status: 'active' | 'inactive';
  created_at?: string | null;
  updated_at?: string | null;
}

export interface OrderItem {
  productId?: string | null;
  title: string;
  price: number;
  quantity: number;
  subtotal: number;
  sku?: string | null;
  image_url?: string | null;
}

export interface Order {
  id: string;
  reference?: string;
  merchant_id: string;
  customer_id?: string | null;
  customer_name: string;
  customer_email: string;
  total_amount: number;
  currency: string;
  status: 'PENDING' | 'PAID' | 'FAILED' | 'CANCELLED';
  payment_status: 'UNPAID' | 'PAID' | 'FAILED' | 'REFUNDED';
  items_count: number;
  items?: OrderItem[];
  source?: 'MERCHANT' | 'BUYER';
  paid_at?: string | null;
  created_at: string;
  updated_at?: string | null;
}

export interface Transaction {
  id: string;
  merchant_id: string;
  order_id: string;
  payment_id?: string;
  amount: number;
  currency: string;
  status: 'SUCCESS' | 'FAILED' | 'PENDING';
  payment_method: string;
  gateway_reference?: string | null;
  failure_reason?: string | null;
  created_at: string;
  customer_name?: string;
  customer_email?: string;
}

export interface Payment {
  id: string;
  merchant_id: string;
  order_id: string;
  amount: number;
  currency: string;
  status: 'PENDING' | 'SUCCESS' | 'FAILED';
  attempt_count: number;
  method: string;
  error_code?: string | null;
  error_message?: string | null;
  created_at: string;
  /** Only present in the checkout response; authorises the buyer to pay this order. */
  client_secret?: string;
}

export interface AIInsight {
  id: string;
  merchant_id: string;
  title: string;
  category: string;
  impact_score: number;
  summary: string;
  recommendation: string;
  status: 'ACTIVE' | 'ACTIONED' | 'DISMISSED';
  potential_revenue_lift: number;
  metadata?: Record<string, unknown>;
  agent_task_id?: string | null;
  created_at: string;
}

export interface AgentTask {
  id: string;
  merchant_id: string;
  title: string;
  agent_type: string;
  status: 'PENDING_APPROVAL' | 'APPROVED' | 'REJECTED' | 'EXECUTING' | 'COMPLETED' | 'FAILED';
  trigger_reason: string;
  proposed_action: string;
  execution_result?: string | null;
  impact_metric?: string | null;
  insight_id?: string | null;
  approval_id?: string | null;
  approval_status?: string | null;
  approval_resolved_at?: string | null;
  created_at: string;
  updated_at: string;
}

export interface Approval {
  id: string;
  merchant_id: string;
  agent_task_id: string;
  title: string;
  description: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  requested_by: string;
  resolved_by?: string | null;
  resolved_at?: string | null;
  notes?: string | null;
  created_at: string;
  agent_type?: string | null;
  trigger_reason?: string | null;
  proposed_action?: string | null;
  impact_metric?: string | null;
  task_status?: string | null;
}

export interface AuditLog {
  id: string;
  merchant_id: string;
  actor_type: 'USER' | 'AGENT' | 'SYSTEM' | 'BUYER';
  actor_id?: string | null;
  actor_email?: string | null;
  action: string;
  entity_type: string;
  entity_id?: string | null;
  details: string;
  ip_address: string;
  created_at: string;
}

export interface CartItem {
  productId: string;
  title: string;
  price: number;
  image_url: string;
  quantity: number;
  subtotal: number;
  sku?: string;
}

export interface DashboardMetrics {
  gmv: number;
  revenue: number;
  orders: number;
  paidOrders: number;
  aov: number;
  conversionRate: number;
  paymentSuccess: number;
  paymentSuccessRate: number;
  paymentFailure: number;
  paymentFailureRate: number;
  revenueLeakage: number;
  aiOpportunities: number;
  aiPotentialLift: number;
}

export interface ChartPoint {
  day: string;
  date?: string;
  revenue: number;
  gmv: number;
}

export interface LiveAnalytics {
  activeInsightsCount: number;
  revenueLeakageDetected: number;
  failedTransactionsCount: number;
  lowStockProductsCount: number;
  lowStockItems: Product[];
}
