import type { IncomingMessage, ServerResponse } from 'node:http';
import { app } from '../server/app.js';

// Vercel serverless entry point for every /api/* request.
//
// - The Express app (server/app.ts) is a plain request handler: nothing here
//   calls app.listen() or starts a long-running server.
// - The MongoDB client is created lazily on first use and cached on
//   globalThis (server/db/mongo.ts), so warm invocations reuse the same
//   connection pool instead of reconnecting per request.
// - Errors (including a missing MONGODB_URI / JWT_SECRET) are turned into JSON
//   responses by the app's central error handler.
export default function handler(req: IncomingMessage, res: ServerResponse): void {
  app(req, res);
}
