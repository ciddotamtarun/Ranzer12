# RazorGrowth AI

An AI-powered merchant growth and agentic-commerce platform. Merchants sign
up, run a storefront, and get AI-generated growth opportunities that go
through a human-in-the-loop approval workflow before anything executes,
with a full audit trail behind every action.

- **Frontend:** React 19 + TypeScript, Vite, Tailwind CSS, Lucide icons
- **Backend:** Express 5 + TypeScript, deployed as one Vercel serverless function
- **Database:** MongoDB (Atlas recommended), official `mongodb` Node.js driver
- **Auth:** email/password, bcrypt-hashed passwords, signed JWT (HS256)

---

## Contents

1. [Features](#features)
2. [Architecture](#architecture)
3. [Data model](#data-model-mongodb-collections)
4. [Requirements](#requirements)
5. [Installation](#installation)
6. [Environment variables](#environment-variables)
7. [MongoDB Atlas setup](#mongodb-atlas-setup)
8. [Local development](#local-development)
9. [Testing](#testing)
10. [Production deployment (Vercel)](#production-deployment-vercel)
11. [API reference](#api-reference)
12. [Security model](#security-model)
13. [Troubleshooting](#troubleshooting)

---

## Features

- **Authentication.** Sign-up, login, logout, session restore after refresh,
  and automatic sign-out when a token expires. Brute-force protection per
  account and per IP.
- **Multi-tenant workspaces.** Every record (products, customers, orders,
  payments, transactions, insights, agent tasks, approvals, audit logs, carts)
  is scoped by `merchantId`. The API always takes it from the verified token,
  never from client input.
- **Dashboard.** GMV, revenue, AOV, checkout conversion, payment
  success/failure rate, revenue leakage and a 7-day revenue chart, all
  aggregated in MongoDB from the merchant's own data.
- **Products and customers.** Full CRUD with search, filters and pagination.
  SKUs are unique per catalog, and customer emails are unique per merchant.
- **Orders.** Merchant-created orders use catalog prices (never client
  prices). Duplicate lines are merged, inventory is checked, and unpaid orders
  can be cancelled.
- **Payments (simulator).** A clearly labelled simulator that records
  SUCCESS or FAILURE in the transaction ledger. It updates order state,
  decrements stock and updates customer lifetime value exactly once per order,
  even under concurrent retries.
- **AI Growth Engine.** A deterministic, rule-based engine that turns the
  merchant's real data (failed payments, idle carts, average order value)
  into opportunities. Estimates use documented recovery assumptions stored
  with each insight.
- **Agents and human approvals.** Every opportunity spawns an agent task and
  a pending approval. Nothing executes without an owner's decision, and each
  decision is final.
- **Audit trail.** Sign-ups, logins (including failed ones), logouts,
  catalog/customer/order changes, payments, AI discoveries, approvals and
  agent executions.
- **AI Buyer Storefront.** Natural-language product search with budget
  parsing and product comparison. A persistent, session-scoped cart and a
  checkout that validates against live price and inventory.

## Architecture

```
Browser (React SPA)
   │  fetch('/api/...')  — same origin, Bearer token
   ▼
Vercel ── static files from dist/ (SPA fallback → index.html)
   │
   └─ /api/*  →  api/[...path].ts  (one serverless function)
                    │
                    ▼
               server/app.ts  (Express 5: CORS, JSON, routes, error handler)
                    │
                    ▼
               server/db/mongo.ts  (cached MongoClient per warm instance)
                    │
                    ▼
               MongoDB Atlas
```

Local development runs the same Express app with `server/index.ts`
(`app.listen`), and Vite proxies `/api` to it. There is one codebase for both
environments.

```
├── api/[...path].ts          # Vercel serverless entry (wraps the Express app)
├── server/
│   ├── app.ts                # Express app, middleware, 404, central error handler
│   ├── index.ts              # Local dev server (dotenv + app.listen)
│   ├── config.ts             # Environment configuration (read lazily)
│   ├── db/
│   │   ├── mongo.ts          # Serverless-safe MongoClient cache, typed collections, health ping
│   │   ├── models.ts         # Document interfaces and enums
│   │   └── indexes.ts        # Index plan (created automatically, idempotent)
│   ├── lib/                  # errors, validation, serializers, money, rate limiting, secrets
│   ├── middleware/           # auth (JWT) and audit logging
│   ├── services/             # order building and payment settlement
│   └── routes/               # one router per resource
├── src/                      # React frontend
│   ├── api/client.ts         # Typed API client
│   ├── context/              # AuthProvider, useAuth
│   ├── hooks/                # useAsyncResource, useDebouncedValue
│   ├── components/ pages/ types/ lib/
├── scripts/
│   ├── test-e2e.ts           # End-to-end API suite runner
│   ├── test-failure-modes.ts # Misconfiguration / outage / CORS tests
│   ├── tests/                # Suite, harness, Vercel runtime emulator
│   ├── db-indexes.ts         # Create/verify indexes
│   └── seed-demo.ts          # Optional demo data
├── vercel.json
└── .env.example
```

## Data model (MongoDB collections)

IDs are `ObjectId`s, returned to the frontend as 24-character hex strings.
Money is stored as integer cents (`priceCents`, `totalAmountCents`, …) so
sums are exact; the API returns decimal amounts. Every document has
`createdAt` / `updatedAt`.

| Collection     | Purpose & key fields | Indexes |
|----------------|----------------------|---------|
| `merchants`    | Workspace: `name`, `slug`, `email`, `currency`, `settings` | `slug` unique |
| `users`        | `merchantId`, `name`, `email`, `passwordHash`, `role`, `lastLoginAt` | `email` unique |
| `customers`    | `merchantId`, `name`, `email`, `phone`, `totalSpentCents`, `ordersCount`, `status` | `(merchantId, email)` unique; `(merchantId, createdAt)` |
| `products`     | `merchantId`, `title`, `description`, `priceCents`, `compareAtPriceCents`, `category`, `inventory`, `sku`, `imageUrl`, `status` | `(merchantId, sku)` unique; `(merchantId, createdAt)`; `(merchantId, category)` |
| `orders`       | `merchantId`, `reference`, `customerId`, customer snapshot, `items[]` (embedded line items), `totalAmountCents`, `currency`, `status`, `paymentStatus`, `source`, `paidAt` | `(merchantId, createdAt)`; `(merchantId, status, createdAt)`; `(merchantId, reference)` |
| `payments`     | `merchantId`, `orderId`, `amountCents`, `status`, `attemptCount`, `method`, error fields, `clientSecretHash` | `(orderId, createdAt)` |
| `transactions` | Payment ledger: `merchantId`, `orderId`, `paymentId`, `amountCents`, `status`, `paymentMethod`, `gatewayReference`, `failureReason`, customer snapshot | `(merchantId, createdAt)`; `(merchantId, status, createdAt)`; `(orderId, createdAt)` |
| `aiInsights`   | `merchantId`, `category`, `summary`, `recommendation`, `status`, `potentialRevenueLiftCents`, `metadata` (basis & assumptions), `agentTaskId` | `(merchantId, createdAt)` |
| `agentTasks`   | `merchantId`, `agentType`, `status`, `triggerReason`, `proposedAction`, `executionResult`, `impactMetric`, `insightId` | `(merchantId, createdAt)` |
| `approvals`    | `merchantId`, `agentTaskId`, `status`, `requestedBy`, `resolvedBy`, `resolvedAt`, `notes` | `(merchantId, createdAt)`; `agentTaskId` unique |
| `auditLogs`    | `merchantId`, `actorType`, `actorId`, `actorEmail`, `action`, `entityType`, `entityId`, `details`, `ipAddress` | `(merchantId, createdAt)`; `(merchantId, action, createdAt)` |
| `carts`        | Storefront cart: `merchantId`, `sessionId`, `items[]` | `(merchantId, sessionId)` unique; TTL 30 days on `updatedAt` |
| `rateLimits`   | Fixed-window counters shared across serverless instances | TTL on `expiresAt` |

Indexes are created automatically (idempotently) the first time each warm
function instance touches the database. You can also run `npm run db:indexes`.

## Requirements

- **Node.js 22.x** (the MongoDB driver requires ≥ 20.19; Vercel uses the `engines` field)
- **npm** 10+
- **MongoDB Atlas** (free M0 tier is fine) or any MongoDB 6.0+ deployment

## Installation

```bash
git clone <your-repo-url> razorgrowth-ai
cd razorgrowth-ai
npm install
cp .env.example .env      # then fill in MONGODB_URI and JWT_SECRET
```

## Environment variables

Server variables are read only by the API. **Never** prefix a secret with
`VITE_`, because Vite embeds `VITE_*` values in the public browser bundle.

| Variable | Scope | Required | Description |
|----------|-------|----------|-------------|
| `MONGODB_URI` | server | **yes** | Atlas connection string, `mongodb+srv://…`. URL-encode special characters in the password. |
| `MONGODB_DB` | server | no | Database name. Defaults to the database in the URI path, then `razorgrowth`. |
| `JWT_SECRET` | server | **yes (production)** | ≥ 32 characters. Generate with `openssl rand -hex 48`. Changing it signs everyone out. Local dev falls back to a temporary per-process secret if unset. |
| `CORS_ORIGINS` | server | no | Comma-separated origins allowed to call the API cross-origin. Not needed for the default same-domain setup. |
| `RATE_LIMIT_ENABLED` | server | no | `false` disables login/sign-up/checkout rate limiting. Default: enabled. |
| `PORT` | server (local) | no | Port for the local API (default 5000). Ignored on Vercel. |
| `NODE_ENV` | server | no | Set automatically by Vercel (`production`). |
| `VITE_API_URL` | frontend | no | Leave empty (same origin). Set only if the frontend is hosted apart from the API. |

The app has no AI provider or payment gateway keys. The AI engine is
rule-based and the payment flow is a simulator.

## MongoDB Atlas setup

1. **Create a cluster.** Sign in at <https://cloud.mongodb.com>, create a
   project, then **Create** a cluster (the free **M0** tier works). Choose a
   region close to your Vercel functions' region (default `iad1`,
   Washington D.C. → AWS `us-east-1`).
2. **Create the database.** Nothing to do manually. The app creates the
   `razorgrowth` database, its collections and indexes on first use. (Set
   `MONGODB_DB` to use another name.)
3. **Create a database user.** Go to **Security → Database Access → Add New
   Database User**, choose password authentication, and give it the built-in
   role **Read and write to any database**. You can also scope it to
   `readWrite` on your database. Save the password.
4. **Configure network access.** Go to **Security → Network Access → Add IP
   Address**. Vercel functions use dynamic egress IPs, so allow
   `0.0.0.0/0` (access from anywhere), or use Vercel's Atlas integration or
   static IPs on paid plans. For local development you can add just your
   current IP.
5. **Copy the connection string.** Go to **Database → Connect → Drivers →
   Node.js** and copy the string, e.g.
   `mongodb+srv://<user>:<password>@<cluster>.xxxxx.mongodb.net/?retryWrites=true&w=majority&appName=<app>`.
   Replace `<password>`, URL-encoding special characters (`@` → `%40`,
   `:` → `%3A`, `/` → `%2F`).
6. **Add `MONGODB_URI`** to `.env` locally and to Vercel's environment
   variables.
7. **Add the database name** (optional): `MONGODB_DB=razorgrowth`.

Optional: `npm run db:indexes` creates and prints all indexes, and
`npm run seed:demo` loads two demo workspaces into a **non-production**
database (password `Password123!` for `alex@apexelectronics.com` and
`liam@novaapparel.com`).

## Local development

```bash
npm install
cp .env.example .env       # set MONGODB_URI (+ JWT_SECRET)
npm run dev                # API on http://localhost:5000 + Vite on http://localhost:5173
```

Open <http://localhost:5173> and create a workspace. The Vite dev server
proxies `/api` to the Express server, so the browser only ever talks to one
origin.

Other commands:

```bash
npm run server        # API only (tsx watch)
npm run client        # frontend only
npm run typecheck     # tsc for frontend, server/scripts and Vite config
npm run lint          # oxlint (warnings fail)
npm run build         # type-check + production build to dist/
npm run preview       # serve dist/ locally (proxies /api to PORT like dev)
```

## Testing

```bash
npm run test:e2e              # 68 end-to-end API tests
npm run test:failure-modes    # misconfiguration, DB outage and CORS tests
npm test                      # both
```

- `test:e2e` boots the **Vercel handler** (`api/[...path].ts`) in a child
  process, emulating how the Vercel Node runtime invokes it. It runs against
  a **temporary database** (`razorgrowth_e2e_<timestamp>`) on your
  `MONGODB_URI` and removes it at the end (by dropping its collections,
  which the standard read-write role allows), so your application data is
  not touched.
- To test a running deployment instead:
  `API_BASE_URL=https://your-app.vercel.app npm run test:e2e`. This creates
  test merchants in that deployment's database. Add
  `TEST_JWT_SECRET=<that JWT_SECRET>` to include forged/expired-token tests.

Coverage includes auth, validation, NoSQL-injection attempts, tenant
isolation, products, customers, orders, the cart, checkout, payments
(including concurrent double-settlement), AI engine, agents, approvals,
audit logs, dashboard arithmetic, pagination and rate limiting.

## Production deployment (Vercel)

1. Push the repository to GitHub, GitLab or Bitbucket.
2. In Vercel: **Add New… → Project → Import** the repository. The settings
   come from `vercel.json`:
   - Framework: **Vite**; Install: `npm install`; Build: `npm run build`; Output: `dist`
   - Serverless function: `api/[...path].ts` (Node.js 22, max 30s)
   - SPA fallback: every non-`/api/` path rewrites to `/index.html`
3. **Settings → Environment Variables**, for Production (and Preview if used):
   - `MONGODB_URI`: your Atlas connection string
   - `MONGODB_DB`: `razorgrowth` (optional)
   - `JWT_SECRET`: output of `openssl rand -hex 48`
4. **Deploy** (or redeploy after changing variables; they apply only to new
   deployments).
5. Verify: open `https://<your-app>.vercel.app/api/health`. It should
   return `{"status":"online","database":"connected",…}`. Then open the site
   and create a workspace.

With the Vercel CLI instead: `npm i -g vercel`, `vercel link`,
`vercel env add MONGODB_URI` (and `JWT_SECRET`, `MONGODB_DB`), then
`vercel --prod`.

## API reference

All responses are JSON. Errors look like `{ "error": "message", "code": "CODE" }`
with status 400 (validation), 401 (not signed in), 403 (role), 404 (not found
or not yours), 409 (conflict/duplicate/state), 413 (body > 100 KB), 429
(rate limited, with `Retry-After`), 500 (`CONFIG_ERROR` / internal) or 503
(`DATABASE_UNAVAILABLE`). List endpoints accept `limit` (max 500) and
`offset` and return `pagination: { total, limit, offset }`.

| Method & path | Auth | Description |
|---------------|------|-------------|
| `GET /api/health` | – | Liveness plus database ping (`503` when the DB is unreachable) |
| `POST /api/auth/signup` | – | Create merchant + owner, returns `{ token, user, merchant }` |
| `POST /api/auth/login` | – | Returns `{ token, user, merchant }` |
| `GET /api/auth/me` | ✔ | Restore session |
| `POST /api/auth/logout` | ✔ | Record sign-out (client discards the token) |
| `GET/PUT /api/merchants/me` | ✔ (PUT: owner) | Workspace settings |
| `GET /api/merchants/public/:slug` | – | Public storefront profile |
| `GET /api/dashboard/stats` (`/metrics`) | ✔ | Aggregated KPIs, recent activity, 7-day chart |
| `GET/POST /api/products`, `GET/PUT/DELETE /api/products/:id` | ✔ | Catalog (`search`, `category`, `status` filters) |
| `GET/POST /api/customers`, `GET/PUT/DELETE /api/customers/:id` | ✔ | CRM (`search`, `status` filters) |
| `GET/POST /api/orders`, `GET/PATCH /api/orders/:id` | ✔ | Orders (`status`, `search`); PATCH `{status:"CANCELLED"}` |
| `GET /api/transactions` | ✔ | Payment ledger (`status`, `orderId`) |
| `POST /api/payments/create` | ✔ | Open/reuse a payment for an order |
| `POST /api/payments/simulate` | ✔ or buyer `clientSecret` | Simulate SUCCESS/FAILURE |
| `GET /api/ai/insights`, `POST /api/ai/generate-opportunity` | ✔ | AI growth engine |
| `GET /api/agents`, `GET /api/agents/:id`, `POST /api/agents/run` | ✔ | Agent tasks |
| `GET /api/approvals`, `POST /api/approvals/:id/decide` | ✔ (decide: owner) | Human-in-the-loop approvals |
| `GET /api/audit-logs` | ✔ | Audit trail (`action`, `entityType`) |
| `POST /api/buyer/search`, `/compare`, `/checkout` | – | Public storefront (scoped by `merchantId`) |
| `GET/DELETE /api/cart`, `POST /api/cart/items`, `PUT/DELETE /api/cart/items/:productId` | – | Session cart (`merchantId` + `sessionId`) |

## Security model

- Passwords are hashed with bcrypt (cost 12). Bcrypt's 72-byte limit is
  enforced, and hashes are never returned by the API. Responses are built
  with explicit allow-list serializers.
- JWTs are HS256 with issuer and audience checks, expire after 7 days, and
  their payload is validated. `alg: none` and tampered tokens are rejected.
- Login returns the same error for unknown emails and wrong passwords, with
  equalized timing. After 10 failed passwords in 15 minutes an account is
  throttled from any IP, and each IP is limited to 50 attempts per 15 minutes.
- **Authorization:** every query filters by the token's `merchantId`.
  Records belonging to other merchants return 404. Settings changes and
  approval decisions require the `owner` role.
- **Payment simulation:** a merchant can settle only its own orders. A
  storefront buyer needs the one-time `client_secret` returned at checkout,
  which is stored only as a SHA-256 hash. Settlement is an atomic state
  transition, so an order can be paid only once.
- **Input validation / NoSQL injection:** every value that reaches a query
  is validated to a primitive or `ObjectId`, so operator objects such as
  `{"$ne": null}` are rejected with 400. Search input is regex-escaped, and
  the Express 5 query parser does not build nested objects.
- **Errors:** internal errors and stack traces are never sent in production.
  Configuration errors name the missing variable, never its value.
- **CORS:** same-origin by default. Cross-origin access only for
  `CORS_ORIGINS` (plus the Vite dev server outside production), and
  credentials are never allowed.
- **Limits:** JSON bodies are capped at 100 KB. Security headers are set on
  API and static responses.

## Troubleshooting

| Symptom | Cause / fix |
|---------|-------------|
| `/api/health` returns `"database":"not_configured"` | `MONGODB_URI` is missing in this environment. On Vercel, add it and **redeploy**. |
| `/api/health` returns `"database":"unavailable"` or API returns `503 DATABASE_UNAVAILABLE` | Atlas can't be reached. Check **Network Access** (allow `0.0.0.0/0` for Vercel), the cluster isn't paused, and the user/password (URL-encode special characters). |
| `500 CONFIG_ERROR … MONGODB_URI must start with mongodb://` | The variable contains something else (e.g. an old Postgres URL). Paste the Atlas **Drivers** string. |
| `500 CONFIG_ERROR … JWT_SECRET` | Set `JWT_SECRET` (≥ 32 chars) for the environment and redeploy. |
| `bad auth : authentication failed` in function logs | Wrong database user/password, or the password needs URL-encoding. |
| Everyone got signed out | `JWT_SECRET` changed, or differs between environments. Keep it stable. |
| `429 Too many requests` on login | 10 failed attempts for that account in 15 minutes. Wait for the window, or check for a script hammering the endpoint. |
| Frontend loads but every API call 404s locally | Start the API too (`npm run dev` runs both). The Vite proxy targets `PORT` from `.env`. |
| Page refresh on a deep link shows Vercel 404 | Make sure `vercel.json` (with its SPA rewrite) is committed. |
| Build fails on Vercel with type errors | Run `npm run typecheck` locally. The build runs `tsc -b` before `vite build`. |
| Slow first request after idle | Serverless cold start plus first Atlas connection (TLS). Later requests reuse the cached connection pool. |
