/**
 * Creates/verifies every MongoDB index the app relies on and prints them.
 * Safe to run repeatedly (createIndexes is idempotent).
 *
 *   npm run db:indexes
 *
 * The API also ensures indexes automatically on each cold start, so this is
 * optional; it is useful right after provisioning a new Atlas database.
 */
import 'dotenv/config';
import { closeMongoClient, getDb } from '../server/db/mongo.js';
import { INDEXES } from '../server/db/indexes.js';

async function main(): Promise<void> {
  const db = await getDb(); // connects and runs ensureIndexes()
  console.log(`Database: ${db.databaseName}`);
  for (const collection of Object.keys(INDEXES)) {
    const indexes = await db.collection(collection).listIndexes().toArray();
    const names = indexes.map((i) => `${i.name}${i.unique ? ' (unique)' : ''}${i.expireAfterSeconds !== undefined ? ` (ttl ${i.expireAfterSeconds}s)` : ''}`);
    console.log(`  ${collection.padEnd(13)} ${names.join(', ')}`);
  }
}

main()
  .then(() => closeMongoClient())
  .catch(async (err: unknown) => {
    console.error('Index setup failed:', err instanceof Error ? err.message : err);
    await closeMongoClient().catch(() => undefined);
    process.exit(1);
  });
