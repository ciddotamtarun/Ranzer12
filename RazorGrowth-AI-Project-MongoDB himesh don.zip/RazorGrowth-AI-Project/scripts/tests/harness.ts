// Minimal test harness shared by the API test scripts (no extra dependencies).

export interface ApiResponse<T = any> {
  status: number;
  ok: boolean;
  data: T;
  headers: Headers;
  text: string;
}

export interface RequestOptions {
  method?: string;
  body?: unknown;
  rawBody?: string;
  token?: string;
  headers?: Record<string, string>;
}

export function createClient(baseUrl: string) {
  return async function request<T = any>(path: string, options: RequestOptions = {}): Promise<ApiResponse<T>> {
    const headers: Record<string, string> = { ...(options.headers ?? {}) };
    let body: string | undefined;
    if (options.rawBody !== undefined) {
      body = options.rawBody;
      headers['Content-Type'] ??= 'application/json';
    } else if (options.body !== undefined) {
      body = JSON.stringify(options.body);
      headers['Content-Type'] = 'application/json';
    }
    if (options.token) headers.Authorization = `Bearer ${options.token}`;
    const res = await fetch(`${baseUrl}${path}`, { method: options.method ?? (body ? 'POST' : 'GET'), headers, body });
    const text = await res.text();
    let data: any = null;
    try {
      data = text ? JSON.parse(text) : null;
    } catch {
      data = null;
    }
    return { status: res.status, ok: res.ok, data: data as T, headers: res.headers, text };
  };
}

export class AssertionError extends Error {}

export function assert(condition: unknown, message: string): asserts condition {
  if (!condition) throw new AssertionError(message);
}

export function assertStatus(res: ApiResponse, expected: number, context: string): void {
  if (res.status !== expected) {
    throw new AssertionError(`${context}: expected HTTP ${expected}, got ${res.status} ${res.text.slice(0, 300)}`);
  }
}

export function assertEqual<T>(actual: T, expected: T, context: string): void {
  if (actual !== expected) {
    throw new AssertionError(`${context}: expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`);
  }
}

interface Result {
  group: string;
  name: string;
  ok: boolean;
  skipped?: boolean;
  error?: string;
  ms: number;
}

export class Runner {
  private results: Result[] = [];
  private group = 'General';

  section(name: string): void {
    this.group = name;
    console.log(`\n\x1b[1m── ${name}\x1b[0m`);
  }

  async test(name: string, fn: () => Promise<void>): Promise<boolean> {
    const started = Date.now();
    try {
      await fn();
      const ms = Date.now() - started;
      this.results.push({ group: this.group, name, ok: true, ms });
      console.log(`  \x1b[32m✔\x1b[0m ${name} \x1b[2m(${ms}ms)\x1b[0m`);
      return true;
    } catch (err) {
      const ms = Date.now() - started;
      const message = err instanceof Error ? err.message : String(err);
      this.results.push({ group: this.group, name, ok: false, error: message, ms });
      console.log(`  \x1b[31m✘ ${name}\x1b[0m\n      ${message}`);
      return false;
    }
  }

  skip(name: string, reason: string): void {
    this.results.push({ group: this.group, name, ok: true, skipped: true, error: reason, ms: 0 });
    console.log(`  \x1b[33m○ ${name} (skipped: ${reason})\x1b[0m`);
  }

  summary(): { passed: number; failed: number; skipped: number } {
    const failed = this.results.filter((r) => !r.ok);
    const skipped = this.results.filter((r) => r.skipped).length;
    const passed = this.results.length - failed.length - skipped;
    console.log('\n' + '='.repeat(72));
    console.log(`  ${passed} passed, ${failed.length} failed, ${skipped} skipped (${this.results.length} total)`);
    if (failed.length) {
      console.log('\n  Failures:');
      for (const f of failed) console.log(`   - [${f.group}] ${f.name}: ${f.error}`);
    }
    console.log('='.repeat(72));
    return { passed, failed: failed.length, skipped };
  }
}

export async function waitForHealthy(baseUrl: string, timeoutMs = 30_000): Promise<void> {
  const deadline = Date.now() + timeoutMs;
  let last = '';
  while (Date.now() < deadline) {
    try {
      const res = await fetch(`${baseUrl}/api/health`);
      if (res.ok) return;
      last = `HTTP ${res.status}: ${await res.text()}`;
    } catch (err) {
      last = err instanceof Error ? err.message : String(err);
    }
    await new Promise((r) => setTimeout(r, 500));
  }
  throw new Error(`API at ${baseUrl} did not become healthy: ${last}`);
}

let ipCounter = 0;
/** Distinct X-Forwarded-For per call so per-IP rate limits don't couple tests. */
export function freshIp(): string {
  ipCounter++;
  return `10.${(ipCounter >> 16) & 255}.${(ipCounter >> 8) & 255}.${ipCounter & 255}`;
}
