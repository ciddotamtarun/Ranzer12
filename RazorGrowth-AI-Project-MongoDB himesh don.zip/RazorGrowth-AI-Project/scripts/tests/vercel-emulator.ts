/**
 * Serves api/[...path].ts the way the Vercel Node.js runtime invokes it:
 * the request body is fully buffered first and exposed as a lazily-parsed
 * `req.body` (invalid JSON throws a 400 on access), then the default-exported
 * handler is called. Used by the test scripts to exercise the exact
 * serverless entry point rather than server/index.ts.
 *
 * Run directly: PORT=5100 MONGODB_URI=... tsx scripts/tests/vercel-emulator.ts
 */
import 'dotenv/config';
import http, { type IncomingMessage } from 'node:http';
import handler from '../../api/[...path].js';

class ApiError extends Error {
  readonly statusCode: number;
  constructor(statusCode: number, message: string) {
    super(message);
    this.statusCode = statusCode;
  }
}

function parseBody(req: IncomingMessage, raw: Buffer): unknown {
  const type = (req.headers['content-type'] ?? '').split(';')[0].trim().toLowerCase();
  if (!type || raw.length === 0) return undefined;
  if (type === 'application/json') {
    try {
      return JSON.parse(raw.toString('utf8'));
    } catch {
      throw new ApiError(400, 'Invalid JSON');
    }
  }
  if (type === 'text/plain') return raw.toString('utf8');
  return raw;
}

export function createVercelLikeServer(): http.Server {
  return http.createServer(async (req, res) => {
    const chunks: Buffer[] = [];
    for await (const chunk of req) chunks.push(chunk as Buffer);
    const raw = Buffer.concat(chunks);

    let cached: { value: unknown } | null = null;
    Object.defineProperty(req, 'body', {
      configurable: true,
      enumerable: true,
      get() {
        cached ??= { value: parseBody(req, raw) };
        return cached.value;
      },
      set(value: unknown) {
        Object.defineProperty(req, 'body', { value, writable: true, configurable: true, enumerable: true });
      },
    });

    handler(req, res);
  });
}

const isMain = process.argv[1] && /vercel-emulator\.(ts|js)$/.test(process.argv[1]);
if (isMain) {
  const port = Number(process.env.PORT) || 5100;
  createVercelLikeServer().listen(port, () => {
    console.log(`[vercel-emulator] api/[...path].ts listening on http://localhost:${port}`);
  });
}
