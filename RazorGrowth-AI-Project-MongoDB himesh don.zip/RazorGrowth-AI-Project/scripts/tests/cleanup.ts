import { MongoClient } from 'mongodb';

/**
 * Removes a temporary test database. Drops each collection (allowed by the
 * plain readWrite role; a database disappears once it has no collections),
 * which works for Atlas users that lack the dbAdmin dropDatabase privilege.
 */
export async function dropTestDatabase(uri: string, dbName: string): Promise<void> {
  if (!/_(e2e|failmodes)_\d+$/.test(dbName)) {
    throw new Error(`Refusing to drop "${dbName}": not a temporary test database.`);
  }
  const client = new MongoClient(uri, { serverSelectionTimeoutMS: 5_000 });
  try {
    await client.connect();
    const db = client.db(dbName);
    const collections = await db.listCollections({}, { nameOnly: true }).toArray();
    for (const { name } of collections) {
      if (!name.startsWith('system.')) await db.collection(name).drop().catch(() => undefined);
    }
    // Best effort: also remove the (now empty) database where the user has the privilege.
    await db.dropDatabase().catch(() => undefined);
  } finally {
    await client.close().catch(() => undefined);
  }
}
