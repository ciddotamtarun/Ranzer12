/**
 * RazorGrowth AI — end-to-end API suite (runs over HTTP against a live server).
 *
 * Covers auth, products, customers, orders, payments, transactions, the AI
 * buyer storefront & cart, AI growth engine / agents / approvals, audit logs,
 * dashboard aggregations, tenant isolation, input validation / NoSQL
 * injection, concurrency (exactly-once payment settlement) and rate limiting.
 */
import crypto from 'node:crypto';
import jwt from 'jsonwebtoken';
import { Runner, assert, assertEqual, assertStatus, createClient, freshIp, type ApiResponse } from './harness.js';

export interface SuiteOptions {
  baseUrl: string;
  /** When provided, forged/expired JWT scenarios are exercised too. */
  jwtSecret?: string;
}

interface Session {
  token: string;
  merchantId: string;
  userId: string;
  email: string;
  password: string;
}

export async function runE2ESuite(opts: SuiteOptions): Promise<{ passed: number; failed: number; skipped: number }> {
  const t = new Runner();
  const api = createClient(opts.baseUrl);
  const run = `${Date.now()}${crypto.randomBytes(2).toString('hex')}`;

  const signup = async (label: string, extra: Record<string, unknown> = {}): Promise<Session> => {
    const email = `${label}_${run}@example.test`;
    const password = 'Password123!';
    const res = await api('/api/auth/signup', {
      body: { name: `${label} Owner`, email, password, merchantName: `${label} Store ${run}`, ...extra },
      headers: { 'X-Forwarded-For': freshIp() },
    });
    assertStatus(res, 201, `signup ${label}`);
    return { token: res.data.token, merchantId: res.data.merchant.id, userId: res.data.user.id, email, password };
  };

  // Shared state populated as the suite progresses.
  let A!: Session;
  let B!: Session;
  let productId = '';
  let product2Id = '';
  let customerId = '';
  let orderId = '';
  let orderReference = '';

  // ===========================================================================
  t.section('Health & routing');
  // ===========================================================================
  await t.test('GET /api/health reports database connected', async () => {
    const res = await api('/api/health');
    assertStatus(res, 200, 'health');
    assertEqual(res.data.database, 'connected', 'database status');
  });
  await t.test('unknown API route returns JSON 404', async () => {
    const res = await api('/api/does-not-exist');
    assertStatus(res, 404, 'unknown route');
    assertEqual(res.data.code, 'NOT_FOUND', 'error code');
  });
  await t.test('security headers are set on API responses', async () => {
    const res = await api('/api/health');
    assertEqual(res.headers.get('x-content-type-options'), 'nosniff', 'nosniff');
    assert(!res.headers.get('x-powered-by'), 'x-powered-by must be removed');
  });

  // ===========================================================================
  t.section('Authentication');
  // ===========================================================================
  await t.test('signup creates merchant + owner and returns a token (201)', async () => {
    A = await signup('alpha', { currency: 'EUR' });
    assert(A.token.split('.').length === 3, 'JWT expected');
    assert(/^[a-f0-9]{24}$/.test(A.merchantId), 'merchant id should be an ObjectId string');
  });
  await t.test('signup response never contains password material', async () => {
    const res = await api('/api/auth/signup', {
      body: { name: 'Leak Check', email: `leak_${run}@example.test`, password: 'Password123!', merchantName: 'Leak Co' },
      headers: { 'X-Forwarded-For': freshIp() },
    });
    assertStatus(res, 201, 'signup');
    assert(!/password|hash/i.test(res.text), 'response must not include password/hash fields');
    assertEqual(res.data.merchant.currency, 'USD', 'default currency');
  });
  await t.test('duplicate email (any case) is rejected with 409', async () => {
    const res = await api('/api/auth/signup', {
      body: { name: 'Dup', email: A.email.toUpperCase(), password: 'Password123!', merchantName: 'Dup' },
      headers: { 'X-Forwarded-For': freshIp() },
    });
    assertStatus(res, 409, 'duplicate signup');
  });
  await t.test('signup validation: missing fields, bad email, short/long password, bad currency', async () => {
    const cases: Array<[Record<string, unknown>, string]> = [
      [{ email: `x_${run}@e.test`, password: 'Password123!', merchantName: 'M' }, 'missing name'],
      [{ name: 'N', email: 'not-an-email', password: 'Password123!', merchantName: 'M' }, 'bad email'],
      [{ name: 'N', email: `y_${run}@e.test`, password: 'short', merchantName: 'M' }, 'short password'],
      [{ name: 'N', email: `z_${run}@e.test`, password: 'x'.repeat(73), merchantName: 'M' }, '73-byte password'],
      [{ name: 'N', email: `w_${run}@e.test`, password: 'Password123!', merchantName: 'M', currency: 'XXX' }, 'bad currency'],
      [{ name: 'N', email: { $ne: null }, password: 'Password123!', merchantName: 'M' }, 'operator object as email'],
    ];
    for (const [body, label] of cases) {
      const res = await api('/api/auth/signup', { body, headers: { 'X-Forwarded-For': freshIp() } });
      assertStatus(res, 400, label);
    }
  });
  await t.test('login succeeds with correct credentials', async () => {
    const res = await api('/api/auth/login', { body: { email: A.email, password: A.password }, headers: { 'X-Forwarded-For': freshIp() } });
    assertStatus(res, 200, 'login');
    assertEqual(res.data.user.id, A.userId, 'user id');
    assertEqual(res.data.merchant.currency, 'EUR', 'merchant currency');
    A.token = res.data.token;
  });
  await t.test('login with wrong password or unknown email returns 401', async () => {
    const wrong = await api('/api/auth/login', { body: { email: A.email, password: 'WrongPass999' }, headers: { 'X-Forwarded-For': freshIp() } });
    assertStatus(wrong, 401, 'wrong password');
    const unknown = await api('/api/auth/login', { body: { email: `nobody_${run}@e.test`, password: 'Password123!' }, headers: { 'X-Forwarded-For': freshIp() } });
    assertStatus(unknown, 401, 'unknown email');
    assertEqual(wrong.data.error, unknown.data.error, 'same error message (no user enumeration)');
  });
  await t.test('login rejects missing fields (400) and operator injection (400)', async () => {
    assertStatus(await api('/api/auth/login', { body: { email: A.email }, headers: { 'X-Forwarded-For': freshIp() } }), 400, 'missing password');
    assertStatus(
      await api('/api/auth/login', { body: { email: { $gt: '' }, password: { $gt: '' } }, headers: { 'X-Forwarded-For': freshIp() } }),
      400,
      'operator injection'
    );
  });
  await t.test('GET /api/auth/me restores the session (page refresh)', async () => {
    const res = await api('/api/auth/me', { token: A.token });
    assertStatus(res, 200, 'me');
    assertEqual(res.data.user.email, A.email, 'email');
    assertEqual(res.data.merchant.id, A.merchantId, 'merchant');
  });
  await t.test('missing, malformed and tampered tokens are rejected with 401', async () => {
    assertStatus(await api('/api/auth/me'), 401, 'no token');
    assertStatus(await api('/api/auth/me', { token: 'not-a-jwt' }), 401, 'malformed');
    const [h, p] = A.token.split('.');
    assertStatus(await api('/api/auth/me', { token: `${h}.${p}.invalidsignature` }), 401, 'bad signature');
    const noneToken = `${Buffer.from(JSON.stringify({ alg: 'none', typ: 'JWT' })).toString('base64url')}.${p}.`;
    assertStatus(await api('/api/auth/me', { token: noneToken }), 401, 'alg=none');
  });
  if (opts.jwtSecret) {
    const secret = opts.jwtSecret;
    await t.test('expired token and token for a non-existent user are rejected (401)', async () => {
      const base = { issuer: 'razorgrowth-ai', audience: 'razorgrowth-ai-app', algorithm: 'HS256' as const };
      const expired = jwt.sign({ merchantId: A.merchantId, email: A.email, role: 'owner', exp: Math.floor(Date.now() / 1000) - 60 }, secret, { ...base, subject: A.userId });
      assertStatus(await api('/api/auth/me', { token: expired }), 401, 'expired');
      const ghost = jwt.sign({ merchantId: A.merchantId, email: A.email, role: 'owner' }, secret, { ...base, subject: '0123456789abcdef01234567', expiresIn: '1h' });
      assertStatus(await api('/api/auth/me', { token: ghost }), 401, 'ghost user');
      const badRole = jwt.sign({ merchantId: A.merchantId, email: A.email, role: 'superadmin' }, secret, { ...base, subject: A.userId, expiresIn: '1h' });
      assertStatus(await api('/api/products', { token: badRole }), 401, 'unknown role');
    });
  } else {
    t.skip('expired/forged token scenarios', 'TEST_JWT_SECRET not provided');
  }
  await t.test('protected endpoints return 401 without a token', async () => {
    const endpoints: Array<[string, string]> = [
      ['GET', '/api/dashboard/stats'], ['GET', '/api/products'], ['POST', '/api/products'], ['GET', '/api/customers'],
      ['GET', '/api/orders'], ['POST', '/api/orders'], ['GET', '/api/transactions'], ['GET', '/api/ai/insights'],
      ['POST', '/api/ai/generate-opportunity'], ['GET', '/api/agents'], ['POST', '/api/agents/run'], ['GET', '/api/approvals'],
      ['GET', '/api/audit-logs'], ['GET', '/api/merchants/me'], ['PUT', '/api/merchants/me'], ['POST', '/api/payments/create'],
      ['POST', '/api/auth/logout'],
    ];
    for (const [method, path] of endpoints) {
      const res = await api(path, { method, body: method === 'GET' ? undefined : {} });
      assertStatus(res, 401, `${method} ${path}`);
    }
  });
  await t.test('removed impersonation endpoints stay removed (404)', async () => {
    assertStatus(await api('/api/auth/merchants', { token: A.token }), 404, 'list merchants');
    assertStatus(await api('/api/auth/switch-merchant', { method: 'POST', body: {}, token: A.token }), 404, 'switch merchant');
  });

  // ===========================================================================
  t.section('Merchant workspace');
  // ===========================================================================
  await t.test('GET/PUT /api/merchants/me reads and updates settings', async () => {
    const res = await api('/api/merchants/me', { method: 'PUT', token: A.token, body: { name: `Alpha Renamed ${run}`, settings: { theme: 'dark', lowStock: 5 } } });
    assertStatus(res, 200, 'update');
    assertEqual(res.data.merchant.settings.theme, 'dark', 'settings persisted');
    const me = await api('/api/merchants/me', { token: A.token });
    assertEqual(me.data.merchant.name, `Alpha Renamed ${run}`, 'name persisted');
  });
  await t.test('merchant settings validation (currency, $-keys, empty update)', async () => {
    assertStatus(await api('/api/merchants/me', { method: 'PUT', token: A.token, body: { currency: 'DOGE' } }), 400, 'currency');
    assertStatus(await api('/api/merchants/me', { method: 'PUT', token: A.token, body: { settings: { $where: '1' } } }), 400, '$ key');
    assertStatus(await api('/api/merchants/me', { method: 'PUT', token: A.token, body: {} }), 400, 'empty');
  });
  await t.test('public storefront profile by slug hides private fields', async () => {
    const me = await api('/api/merchants/me', { token: A.token });
    const res = await api(`/api/merchants/public/${me.data.merchant.slug}`);
    assertStatus(res, 200, 'public');
    assert(res.data.merchant.email === undefined, 'email must not be public');
    assertStatus(await api('/api/merchants/public/no-such-store-xyz'), 404, 'missing slug');
  });

  // ===========================================================================
  t.section('Products');
  // ===========================================================================
  await t.test('create product (201) with decimal money and generated fields', async () => {
    const res = await api('/api/products', {
      token: A.token,
      body: {
        title: 'Apex SoundMax ANC Headphones', description: 'Studio-grade wireless noise cancelling headphones.',
        price: 199.99, compare_at_price: 249.99, category: 'Audio', inventory: 50, sku: `APEX-HPH-${run}`,
        image_url: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=500',
      },
    });
    assertStatus(res, 201, 'create');
    productId = res.data.product.id;
    assertEqual(res.data.product.price, 199.99, 'price');
    assertEqual(res.data.product.compare_at_price, 249.99, 'compare_at_price');
    assertEqual(res.data.product.status, 'active', 'default status');
  });
  await t.test('numeric strings are accepted and a SKU is generated when omitted', async () => {
    const res = await api('/api/products', { token: A.token, body: { title: 'TitanCharge 140W GaN Charger', price: '69.90', inventory: '3', category: 'Accessories' } });
    assertStatus(res, 201, 'create');
    product2Id = res.data.product.id;
    assertEqual(res.data.product.price, 69.9, 'price');
    assertEqual(res.data.product.inventory, 3, 'inventory');
    assert(/^SKU-[0-9A-F]{8}$/.test(res.data.product.sku), `generated sku, got ${res.data.product.sku}`);
    assert(res.data.product.image_url.startsWith('https://'), 'default image');
  });
  await t.test('product validation: missing title, negative price, bad inventory, unsafe URL', async () => {
    assertStatus(await api('/api/products', { token: A.token, body: { price: 10 } }), 400, 'missing title');
    assertStatus(await api('/api/products', { token: A.token, body: { title: 'X', price: -1 } }), 400, 'negative price');
    assertStatus(await api('/api/products', { token: A.token, body: { title: 'X', price: 1, inventory: 1.5 } }), 400, 'fractional inventory');
    assertStatus(await api('/api/products', { token: A.token, body: { title: 'X', price: 1, image_url: 'javascript:alert(1)' } }), 400, 'javascript url');
    assertStatus(await api('/api/products', { token: A.token, body: { title: { $ne: 1 }, price: 1 } }), 400, 'operator title');
  });
  await t.test('duplicate SKU in the same catalog is rejected (409)', async () => {
    const res = await api('/api/products', { token: A.token, body: { title: 'Clone', price: 1, sku: `APEX-HPH-${run}` } });
    assertStatus(res, 409, 'duplicate sku');
  });
  await t.test('get / partial update product', async () => {
    const res = await api(`/api/products/${productId}`, { method: 'PUT', token: A.token, body: { price: 189.99, inventory: 45, sku: '' } });
    assertStatus(res, 200, 'update');
    assertEqual(res.data.product.price, 189.99, 'price');
    assertEqual(res.data.product.inventory, 45, 'inventory');
    assertEqual(res.data.product.sku, `APEX-HPH-${run}`, 'empty sku keeps existing');
    assertEqual(res.data.product.title, 'Apex SoundMax ANC Headphones', 'title untouched');
    const got = await api(`/api/products/${productId}`, { token: A.token });
    assertEqual(got.data.product.price, 189.99, 'persisted');
  });
  await t.test('update to a SKU used by another product is rejected (409)', async () => {
    const res = await api(`/api/products/${product2Id}`, { method: 'PUT', token: A.token, body: { sku: `APEX-HPH-${run}` } });
    assertStatus(res, 409, 'duplicate sku on update');
  });
  await t.test('invalid ObjectId → 400, unknown id → 404', async () => {
    assertStatus(await api('/api/products/not-an-id', { token: A.token }), 400, 'invalid id');
    assertStatus(await api('/api/products/0123456789abcdef01234567', { token: A.token }), 404, 'unknown id');
    assertStatus(await api('/api/products/0123456789abcdef01234567', { method: 'DELETE', token: A.token }), 404, 'delete unknown');
  });
  await t.test('list products: search, category filter, pagination, regex-safe search', async () => {
    const all = await api('/api/products', { token: A.token });
    assertStatus(all, 200, 'list');
    assertEqual(all.data.products.length, 2, 'two products');
    assertEqual(all.data.pagination.total, 2, 'total');
    const search = await api('/api/products?search=soundmax', { token: A.token });
    assertEqual(search.data.products.length, 1, 'search hit');
    const cat = await api('/api/products?category=Accessories', { token: A.token });
    assertEqual(cat.data.products[0]?.id, product2Id, 'category filter');
    const page = await api('/api/products?limit=1&offset=1', { token: A.token });
    assertEqual(page.data.products.length, 1, 'page size');
    const regex = await api(`/api/products?search=${encodeURIComponent('.*')}`, { token: A.token });
    assertEqual(regex.data.products.length, 0, 'regex metacharacters are literal');
    assertStatus(await api('/api/products?limit=0', { token: A.token }), 400, 'limit=0');
    assertStatus(await api('/api/products?limit=100000', { token: A.token }), 400, 'limit too large');
    assertStatus(await api('/api/products?status=deleted', { token: A.token }), 400, 'bad status filter');
  });

  // ===========================================================================
  t.section('Customers');
  // ===========================================================================
  await t.test('create, read, update, search customer', async () => {
    const created = await api('/api/customers', { token: A.token, body: { name: 'John Consumer', email: `John_${run}@Consumer.test`, phone: '+1-555-0199' } });
    assertStatus(created, 201, 'create');
    customerId = created.data.customer.id;
    assertEqual(created.data.customer.email, `john_${run}@consumer.test`, 'email normalised');
    assertEqual(created.data.customer.total_spent, 0, 'total_spent');
    const updated = await api(`/api/customers/${customerId}`, { method: 'PUT', token: A.token, body: { phone: '', status: 'inactive' } });
    assertStatus(updated, 200, 'update');
    assertEqual(updated.data.customer.phone, null, 'phone cleared');
    assertEqual(updated.data.customer.status, 'inactive', 'status');
    await api(`/api/customers/${customerId}`, { method: 'PUT', token: A.token, body: { status: 'active' } });
    const found = await api('/api/customers?search=consumer', { token: A.token });
    assertEqual(found.data.customers.length, 1, 'search');
  });
  await t.test('duplicate customer email per merchant → 409; validation → 400', async () => {
    assertStatus(await api('/api/customers', { token: A.token, body: { name: 'Dup', email: `john_${run}@consumer.test` } }), 409, 'dup');
    assertStatus(await api('/api/customers', { token: A.token, body: { name: 'NoEmail' } }), 400, 'missing email');
    assertStatus(await api('/api/customers', { token: A.token, body: { name: 'X', email: 'x@y.z', status: 'vip' } }), 400, 'bad status');
  });
  await t.test('create and delete a throwaway customer; email change to a taken email → 409', async () => {
    const c = await api('/api/customers', { token: A.token, body: { name: 'Temp', email: `temp_${run}@e.test` } });
    assertStatus(c, 201, 'create');
    assertStatus(
      await api(`/api/customers/${c.data.customer.id}`, { method: 'PUT', token: A.token, body: { email: `john_${run}@consumer.test` } }),
      409,
      'email taken on update'
    );
    assertStatus(await api(`/api/customers/${c.data.customer.id}`, { method: 'DELETE', token: A.token }), 200, 'delete');
    assertStatus(await api(`/api/customers/${c.data.customer.id}`, { token: A.token }), 404, 'gone');
  });

  // ===========================================================================
  t.section('Orders');
  // ===========================================================================
  await t.test('create order: prices come from the catalog, duplicate lines merge', async () => {
    const res = await api('/api/orders', {
      token: A.token,
      body: {
        customerId, customerName: 'John Consumer', customerEmail: `john_${run}@consumer.test`,
        items: [{ productId, quantity: 1, price: 0.01 }, { productId, quantity: 1 }],
      },
    });
    assertStatus(res, 201, 'create');
    orderId = res.data.order.id;
    orderReference = res.data.order.reference;
    assertEqual(res.data.order.status, 'PENDING', 'status');
    assertEqual(res.data.order.payment_status, 'UNPAID', 'payment_status');
    assertEqual(res.data.order.total_amount, 379.98, 'total (2 × 189.99, client price ignored)');
    assertEqual(res.data.order.items.length, 1, 'merged lines');
    assertEqual(res.data.order.items[0].quantity, 2, 'merged quantity');
    assertEqual(res.data.order.currency, 'EUR', 'merchant currency');
    assertEqual(orderReference, orderId.slice(-10), 'reference = id tail');
  });
  await t.test('custom (non-catalog) line items are supported for merchant orders', async () => {
    const res = await api('/api/orders', { token: A.token, body: { customerName: 'Walk In', customerEmail: `walkin_${run}@e.test`, items: [{ title: 'Gift wrap', price: 4.5, quantity: 2 }] } });
    assertStatus(res, 201, 'custom item order');
    assertEqual(res.data.order.total_amount, 9, 'total');
  });
  await t.test('order validation: empty items, bad quantity, unknown product, over-inventory', async () => {
    const base = { customerName: 'V', customerEmail: `v_${run}@e.test` };
    assertStatus(await api('/api/orders', { token: A.token, body: { ...base, items: [] } }), 400, 'empty');
    assertStatus(await api('/api/orders', { token: A.token, body: { ...base, items: [{ productId, quantity: 0 }] } }), 400, 'qty 0');
    assertStatus(await api('/api/orders', { token: A.token, body: { ...base, items: [{ productId: '0123456789abcdef01234567' }] } }), 404, 'unknown product');
    assertStatus(await api('/api/orders', { token: A.token, body: { ...base, items: [{ productId: product2Id, quantity: 2 }, { productId: product2Id, quantity: 2 }] } }), 409, 'combined qty over inventory');
  });
  await t.test('list orders: status filter and search by reference/email', async () => {
    const pending = await api('/api/orders?status=PENDING', { token: A.token });
    assert(pending.data.orders.some((o: { id: string }) => o.id === orderId), 'pending filter');
    const byRef = await api(`/api/orders?search=${encodeURIComponent('#' + orderReference)}`, { token: A.token });
    assertEqual(byRef.data.orders.length, 1, 'search by reference');
    const byId = await api(`/api/orders?search=${orderId}`, { token: A.token });
    assertEqual(byId.data.orders[0]?.id, orderId, 'search by full id');
    const byEmail = await api(`/api/orders?search=john_${run}`, { token: A.token });
    assertEqual(byEmail.data.orders.length, 1, 'search by email');
    assertStatus(await api('/api/orders?status=SHIPPED', { token: A.token }), 400, 'bad status');
  });

  // ===========================================================================
  t.section('Payments & transactions');
  // ===========================================================================
  await t.test('payment failure: ledger FAILED, order FAILED, inventory untouched', async () => {
    const res = await api('/api/payments/simulate', { token: A.token, body: { orderId, outcome: 'FAILURE', failureReason: 'Insufficient funds on demo card' } });
    assertStatus(res, 200, 'simulate failure');
    assertEqual(res.data.success, false, 'success=false');
    assertEqual(res.data.payment.status, 'FAILED', 'payment');
    assertEqual(res.data.transaction.status, 'FAILED', 'transaction');
    assertEqual(res.data.order.payment_status, 'FAILED', 'order payment_status');
    assertEqual(res.data.order.status, 'FAILED', 'order status');
    const p = await api(`/api/products/${productId}`, { token: A.token });
    assertEqual(p.data.product.inventory, 45, 'inventory unchanged');
  });
  await t.test('payment retry success: order PAID, stock decremented, customer LTV updated', async () => {
    const res = await api('/api/payments/simulate', { token: A.token, body: { orderId, outcome: 'SUCCESS', paymentMethod: 'Mastercard ending in 8899' } });
    assertStatus(res, 200, 'simulate success');
    assertEqual(res.data.order.status, 'PAID', 'order status');
    assertEqual(res.data.order.payment_status, 'PAID', 'order payment_status');
    assertEqual(res.data.payment.status, 'SUCCESS', 'payment');
    assertEqual(res.data.payment.attempt_count, 2, 'attempts');
    assert(!('client_secret' in res.data.payment), 'no secret in payment response');
    const p = await api(`/api/products/${productId}`, { token: A.token });
    assertEqual(p.data.product.inventory, 43, 'inventory 45 → 43');
    const c = await api(`/api/customers/${customerId}`, { token: A.token });
    assertEqual(c.data.customer.total_spent, 379.98, 'total_spent');
    assertEqual(c.data.customer.orders_count, 1, 'orders_count');
  });
  await t.test('paying an already-paid order is rejected (409) and nothing double-counts', async () => {
    const res = await api('/api/payments/simulate', { token: A.token, body: { orderId, outcome: 'SUCCESS' } });
    assertStatus(res, 409, 'double pay');
    const p = await api(`/api/products/${productId}`, { token: A.token });
    assertEqual(p.data.product.inventory, 43, 'inventory still 43');
    const c = await api(`/api/customers/${customerId}`, { token: A.token });
    assertEqual(c.data.customer.orders_count, 1, 'orders_count still 1');
  });
  await t.test('concurrent settlement: exactly one of 6 parallel payments succeeds', async () => {
    const o = await api('/api/orders', { token: A.token, body: { customerName: 'Race', customerEmail: `race_${run}@e.test`, items: [{ productId, quantity: 1 }] } });
    assertStatus(o, 201, 'order');
    const results = await Promise.all(
      Array.from({ length: 6 }, () => api('/api/payments/simulate', { token: A.token, body: { orderId: o.data.order.id, outcome: 'SUCCESS' } }))
    );
    const ok = results.filter((r) => r.status === 200).length;
    const conflicts = results.filter((r) => r.status === 409).length;
    assertEqual(ok, 1, 'exactly one success');
    assertEqual(conflicts, 5, 'others conflict');
    const p = await api(`/api/products/${productId}`, { token: A.token });
    assertEqual(p.data.product.inventory, 42, 'inventory decremented once (43 → 42)');
    const tx = await api(`/api/transactions?orderId=${o.data.order.id}`, { token: A.token });
    assertEqual(tx.data.transactions.length, 1, 'one ledger entry');
  });
  await t.test('payment simulation without auth or client secret → 401', async () => {
    assertStatus(await api('/api/payments/simulate', { body: { orderId, outcome: 'SUCCESS' } }), 401, 'anonymous');
  });
  await t.test('payment validation: bad outcome, missing ids', async () => {
    assertStatus(await api('/api/payments/simulate', { token: A.token, body: { orderId, outcome: 'MAYBE' } }), 400, 'outcome');
    assertStatus(await api('/api/payments/simulate', { token: A.token, body: { outcome: 'SUCCESS' } }), 400, 'no ids');
  });
  await t.test('payments/create reuses an open payment and refuses paid orders', async () => {
    const o = await api('/api/orders', { token: A.token, body: { customerName: 'Pc', customerEmail: `pc_${run}@e.test`, items: [{ productId, quantity: 1 }] } });
    const first = await api('/api/payments/create', { token: A.token, body: { orderId: o.data.order.id } });
    assertStatus(first, 200, 'create');
    const second = await api('/api/payments/create', { token: A.token, body: { orderId: o.data.order.id } });
    assertEqual(second.data.payment.id, first.data.payment.id, 'reused');
    assertStatus(await api('/api/payments/create', { token: A.token, body: { orderId } }), 409, 'paid order');
  });
  await t.test('order detail includes its transaction history', async () => {
    const res = await api(`/api/orders/${orderId}`, { token: A.token });
    assertStatus(res, 200, 'get order');
    assertEqual(res.data.transactions.length, 2, 'failed + success');
    assertEqual(res.data.transactions[0].status, 'SUCCESS', 'newest first');
  });
  await t.test('transactions list and status filter', async () => {
    const all = await api('/api/transactions', { token: A.token });
    assertStatus(all, 200, 'list');
    assert(all.data.transactions.length >= 3, 'at least 3 transactions');
    assert(all.data.transactions.every((x: { customer_name: string }) => typeof x.customer_name === 'string'), 'customer names denormalised');
    const failed = await api('/api/transactions?status=FAILED', { token: A.token });
    assert(failed.data.transactions.every((x: { status: string }) => x.status === 'FAILED'), 'filter');
    assertStatus(await api('/api/transactions?status=WEIRD', { token: A.token }), 400, 'bad filter');
    assertStatus(await api('/api/transactions?orderId=xyz', { token: A.token }), 400, 'bad orderId');
  });
  await t.test('cancel an unpaid order; paid and cancelled orders are protected', async () => {
    const o = await api('/api/orders', { token: A.token, body: { customerName: 'Cx', customerEmail: `cx_${run}@e.test`, items: [{ productId, quantity: 1 }] } });
    const cancel = await api(`/api/orders/${o.data.order.id}`, { method: 'PATCH', token: A.token, body: { status: 'CANCELLED' } });
    assertStatus(cancel, 200, 'cancel');
    assertEqual(cancel.data.order.status, 'CANCELLED', 'status');
    assertStatus(await api('/api/payments/simulate', { token: A.token, body: { orderId: o.data.order.id, outcome: 'SUCCESS' } }), 409, 'pay cancelled');
    assertStatus(await api(`/api/orders/${orderId}`, { method: 'PATCH', token: A.token, body: { status: 'CANCELLED' } }), 409, 'cancel paid');
    assertStatus(await api(`/api/orders/${orderId}`, { method: 'PATCH', token: A.token, body: { status: 'PAID' } }), 400, 'only CANCELLED allowed');
  });

  // ===========================================================================
  t.section('AI Buyer storefront & cart');
  // ===========================================================================
  const sessionId = `sess_${run}`;
  let buyerOrderId = '';
  let clientSecret = '';
  await t.test('natural-language search ranks the best match first and parses budget', async () => {
    const res = await api('/api/buyer/search', { body: { merchantId: A.merchantId, query: 'wireless headphones under 200' } });
    assertStatus(res, 200, 'search');
    assertEqual(res.data.results[0].id, productId, 'top match');
    assert(res.data.results[0].matchScore > 50, 'score');
    assert(res.data.results[0].matchReason.length > 0, 'reason');
    assertEqual(res.data.extractedMaxPrice, 200, 'budget parsed');
  });
  await t.test('search/compare validate merchantId and only return active products', async () => {
    assertStatus(await api('/api/buyer/search', { body: { merchantId: { $ne: null } } }), 400, 'operator merchantId');
    const archived = await api('/api/products', { token: A.token, body: { title: 'Archived Thing', price: 5, inventory: 5, status: 'archived' } });
    const res = await api('/api/buyer/search', { body: { merchantId: A.merchantId, query: '' } });
    assert(!res.data.results.some((p: { id: string }) => p.id === archived.data.product.id), 'archived hidden');
    const cmp = await api('/api/buyer/compare', { body: { merchantId: A.merchantId, productIds: [productId, product2Id, archived.data.product.id] } });
    assertStatus(cmp, 200, 'compare');
    assertEqual(cmp.data.products.length, 2, 'active only');
    assertStatus(await api('/api/buyer/compare', { body: { merchantId: A.merchantId, productIds: [] } }), 400, 'empty ids');
    const checkoutArchived = await api('/api/buyer/checkout', {
      body: { merchantId: A.merchantId, customerName: 'A', customerEmail: `arch_${run}@e.test`, items: [{ productId: archived.data.product.id, quantity: 1 }] },
      headers: { 'X-Forwarded-For': freshIp() },
    });
    assertStatus(checkoutArchived, 409, 'archived not purchasable');
  });
  await t.test('cart: add, merge quantity, update, inventory guard, remove, clear', async () => {
    const add = await api('/api/cart/items', { body: { merchantId: A.merchantId, sessionId, productId, quantity: 1 } });
    assertStatus(add, 200, 'add');
    assertEqual(add.data.cart.items.length, 1, 'one line');
    const again = await api('/api/cart/items', { body: { merchantId: A.merchantId, sessionId, productId, quantity: 2 } });
    assertEqual(again.data.items[0].quantity, 3, 'merged quantity');
    assertEqual(again.data.items[0].subtotal, 569.97, 'subtotal 3 × 189.99');
    const upd = await api(`/api/cart/items/${productId}`, { method: 'PUT', body: { merchantId: A.merchantId, sessionId, quantity: 1 } });
    assertEqual(upd.data.items[0].quantity, 1, 'updated');
    assertStatus(await api('/api/cart/items', { body: { merchantId: A.merchantId, sessionId, productId: product2Id, quantity: 99 } }), 409, 'over inventory');
    await api('/api/cart/items', { body: { merchantId: A.merchantId, sessionId, productId: product2Id, quantity: 1 } });
    const rm = await api(`/api/cart/items/${product2Id}?merchantId=${A.merchantId}&sessionId=${sessionId}`, { method: 'DELETE' });
    assertEqual(rm.data.items.length, 1, 'removed');
    const got = await api(`/api/cart?merchantId=${A.merchantId}&sessionId=${sessionId}`);
    assertEqual(got.data.items.length, 1, 'persisted');
    const other = await api(`/api/cart?merchantId=${A.merchantId}&sessionId=other_${run}`);
    assertEqual(other.data.items.length, 0, 'sessions are isolated');
    const tmp = `tmp_${run}`;
    await api('/api/cart/items', { body: { merchantId: A.merchantId, sessionId: tmp, productId, quantity: 1 } });
    const clear = await api(`/api/cart?merchantId=${A.merchantId}&sessionId=${tmp}`, { method: 'DELETE' });
    assertEqual(clear.data.items.length, 0, 'cleared');
  });
  await t.test('cart validation: session id required, bad ids rejected', async () => {
    assertStatus(await api(`/api/cart?merchantId=${A.merchantId}`), 400, 'missing session');
    assertStatus(await api('/api/cart/items', { body: { merchantId: A.merchantId, productId } }), 400, 'missing session on add');
    assertStatus(await api('/api/cart/items', { body: { merchantId: A.merchantId, sessionId, productId: 'nope' } }), 400, 'bad product');
    assertStatus(await api(`/api/cart/items/${product2Id}`, { method: 'PUT', body: { merchantId: A.merchantId, sessionId, quantity: 1 } }), 404, 'not in cart');
  });
  await t.test('buyer checkout creates order + payment with one-time client secret and clears cart', async () => {
    const res = await api('/api/buyer/checkout', {
      body: {
        merchantId: A.merchantId, customerName: 'Maya Buyer', customerEmail: `maya_${run}@shopper.test`, customerPhone: '+1-555-0998',
        sessionId, items: [{ productId, quantity: 1 }],
      },
      headers: { 'X-Forwarded-For': freshIp() },
    });
    assertStatus(res, 201, 'checkout');
    buyerOrderId = res.data.order.id;
    clientSecret = res.data.payment.client_secret;
    assert(typeof clientSecret === 'string' && clientSecret.startsWith('pay_secret_'), 'client secret issued');
    assertEqual(res.data.order.total_amount, 189.99, 'total');
    assertEqual(res.data.order.source, 'BUYER', 'source');
    const cart = await api(`/api/cart?merchantId=${A.merchantId}&sessionId=${sessionId}`);
    assertEqual(cart.data.items.length, 0, 'cart cleared');
    const customers = await api(`/api/customers?search=maya_${run}`, { token: A.token });
    assertEqual(customers.data.customers.length, 1, 'customer auto-created');
  });
  await t.test('buyer settles payment with the client secret (no login); wrong secret → 404', async () => {
    assertStatus(await api('/api/payments/simulate', { body: { orderId: buyerOrderId, outcome: 'SUCCESS', clientSecret: 'pay_secret_wrong' } }), 404, 'wrong secret');
    const res = await api('/api/payments/simulate', { body: { orderId: buyerOrderId, outcome: 'SUCCESS', clientSecret, paymentMethod: 'Apple Pay' } });
    assertStatus(res, 200, 'buyer pay');
    assertEqual(res.data.order.status, 'PAID', 'paid');
    const p = await api(`/api/products/${productId}`, { token: A.token });
    assertEqual(p.data.product.inventory, 41, 'inventory 42 → 41');
    const logs = await api('/api/audit-logs?action=PAYMENT_SUCCEEDED', { token: A.token });
    assert(logs.data.auditLogs.some((l: { actor_type: string }) => l.actor_type === 'BUYER'), 'buyer actor audited');
  });
  await t.test('checkout validation: unknown merchant, empty items, over-inventory', async () => {
    const h = { 'X-Forwarded-For': freshIp() };
    assertStatus(await api('/api/buyer/checkout', { body: { merchantId: '0123456789abcdef01234567', customerName: 'x', customerEmail: `x_${run}@e.test`, items: [{ productId, quantity: 1 }] }, headers: h }), 404, 'unknown merchant');
    assertStatus(await api('/api/buyer/checkout', { body: { merchantId: A.merchantId, customerName: 'x', customerEmail: `x_${run}@e.test`, items: [] }, headers: h }), 400, 'empty items');
    assertStatus(await api('/api/buyer/checkout', { body: { merchantId: A.merchantId, customerName: 'x', customerEmail: `x_${run}@e.test`, items: [{ productId: product2Id, quantity: 50 }] }, headers: h }), 409, 'over inventory');
  });

  // ===========================================================================
  t.section('AI growth engine, agents & approvals');
  // ===========================================================================
  let approvalId = '';
  let insightId = '';
  await t.test('generate opportunity with focus area: data-driven lift from the ledger', async () => {
    const res = await api('/api/ai/generate-opportunity', { token: A.token, body: { focusArea: 'PAYMENT_OPTIMIZATION' } });
    assertStatus(res, 201, 'generate');
    approvalId = res.data.approval.id;
    insightId = res.data.insight.id;
    assertEqual(res.data.insight.category, 'PAYMENT_OPTIMIZATION', 'category');
    assertEqual(res.data.agentTask.status, 'PENDING_APPROVAL', 'task status');
    assertEqual(res.data.approval.status, 'PENDING', 'approval status');
    // One failed payment of 379.98 → 30% recovery assumption = 113.99
    assertEqual(res.data.insight.potential_revenue_lift, 113.99, 'lift = 30% of failed value');
    assert(res.data.insight.summary.includes('1 failed payment attempt'), 'summary uses real data');
    assertEqual(res.data.insight.agent_task_id, res.data.agentTask.id, 'insight linked to task');
  });
  await t.test('insights endpoint reports live analytics', async () => {
    const res = await api('/api/ai/insights', { token: A.token });
    assertStatus(res, 200, 'insights');
    assertEqual(res.data.liveAnalytics.failedTransactionsCount, 1, 'failed count');
    assertEqual(res.data.liveAnalytics.revenueLeakageDetected, 379.98, 'leakage');
    assert(res.data.liveAnalytics.lowStockItems.some((p: { id: string }) => p.id === product2Id), 'low stock item');
    assertEqual(res.data.liveAnalytics.activeInsightsCount, 1, 'active insights');
  });
  await t.test('invalid focus area → 400; rotation without focus area', async () => {
    assertStatus(await api('/api/ai/generate-opportunity', { token: A.token, body: { focusArea: 'WORLD_DOMINATION' } }), 400, 'bad focus');
    const r = await api('/api/ai/generate-opportunity', { token: A.token, body: {} });
    assertStatus(r, 201, 'rotate');
    assertEqual(r.data.insight.category, 'CONVERSION_LIFT', 'second opportunity rotates to CONVERSION_LIFT');
  });
  await t.test('approve: task COMPLETED, linked insight ACTIONED, audit trail written', async () => {
    const res = await api(`/api/approvals/${approvalId}/decide`, { token: A.token, body: { decision: 'APPROVE', notes: 'Ship it' } });
    assertStatus(res, 200, 'approve');
    assertEqual(res.data.approval.status, 'APPROVED', 'approval');
    assertEqual(res.data.agentTask.status, 'COMPLETED', 'task');
    assert(res.data.agentTask.execution_result, 'execution result');
    const insights = await api('/api/ai/insights', { token: A.token });
    const insight = insights.data.insights.find((i: { id: string }) => i.id === insightId);
    assertEqual(insight.status, 'ACTIONED', 'insight actioned');
    const logs = await api('/api/audit-logs', { token: A.token });
    const actions = logs.data.auditLogs.map((l: { action: string }) => l.action);
    assert(actions.includes('APPROVAL_GRANTED') && actions.includes('AGENT_ACTION_EXECUTED'), 'audit events');
  });
  await t.test('an approval can only be decided once (409); bad decision → 400', async () => {
    assertStatus(await api(`/api/approvals/${approvalId}/decide`, { token: A.token, body: { decision: 'REJECT' } }), 409, 'decided twice');
    assertStatus(await api(`/api/approvals/${approvalId}/decide`, { token: A.token, body: { decision: 'MAYBE' } }), 400, 'bad decision');
    assertStatus(await api('/api/approvals/0123456789abcdef01234567/decide', { token: A.token, body: { decision: 'APPROVE' } }), 404, 'unknown');
  });
  await t.test('manual agent run → approval → reject', async () => {
    const run1 = await api('/api/agents/run', { token: A.token, body: { agentType: 'CHECKOUT_FRICTION_KILLER', title: 'Shorter checkout', proposedAction: 'Remove optional phone field.' } });
    assertStatus(run1, 201, 'run');
    assertEqual(run1.data.agentTask.approval_status, 'PENDING', 'approval attached');
    const rej = await api(`/api/approvals/${run1.data.approval.id}/decide`, { token: A.token, body: { decision: 'REJECT', notes: 'Not now' } });
    assertStatus(rej, 200, 'reject');
    assertEqual(rej.data.agentTask.status, 'REJECTED', 'task rejected');
    const list = await api('/api/agents', { token: A.token });
    const task = list.data.agentTasks.find((x: { id: string }) => x.id === run1.data.agentTask.id);
    assertEqual(task.approval_status, 'REJECTED', 'list shows approval state');
    const one = await api(`/api/agents/${run1.data.agentTask.id}`, { token: A.token });
    assertStatus(one, 200, 'get task');
    assertStatus(await api('/api/agents/run', { token: A.token, body: { agentType: 'ROGUE_AGENT', title: 'x', proposedAction: 'y' } }), 400, 'bad agent type');
    const approvals = await api('/api/approvals?status=REJECTED', { token: A.token });
    assert(approvals.data.approvals.every((a: { status: string }) => a.status === 'REJECTED'), 'approval status filter');
    assert(approvals.data.approvals[0].agent_type, 'approval carries task fields');
  });

  // ===========================================================================
  t.section('Dashboard aggregations');
  // ===========================================================================
  await t.test('metrics are exact aggregates of the merchant data', async () => {
    const res = await api('/api/dashboard/metrics', { token: A.token });
    assertStatus(res, 200, 'metrics');
    const m = res.data.metrics;
    // Paid: 379.98 + 189.99 (race order) + 189.99 (buyer) = 759.96
    assertEqual(m.revenue, 759.96, 'revenue');
    assertEqual(m.paidOrders, 3, 'paid orders');
    assertEqual(m.aov, 253.32, 'aov');
    assertEqual(m.paymentFailureCount, 1, 'failures');
    assertEqual(m.paymentSuccessCount, 3, 'successes');
    assertEqual(m.paymentFailureRate, 25, 'failure rate');
    assertEqual(m.paymentSuccessRate, 75, 'success rate');
    assertEqual(m.revenueLeakage, 379.98, 'leakage');
    assert(m.gmv >= m.revenue, 'gmv >= revenue');
    assertEqual(m.aiOpportunities, 1, 'one ACTIVE opportunity remains');
    assertEqual(res.data.chartData.length, 7, '7-day chart');
    const today = new Date().toISOString().slice(0, 10);
    const todayBucket = res.data.chartData.find((d: { date: string }) => d.date === today);
    assertEqual(todayBucket.revenue, 760, "today's revenue (rounded)");
    assertEqual(res.data.recentOrders.length, 5, 'recent orders');
    assert(res.data.recentTransactions.length > 0, 'recent transactions');
  });

  // ===========================================================================
  t.section('Audit logs');
  // ===========================================================================
  await t.test('audit logs are recorded, filterable and validated', async () => {
    const res = await api('/api/audit-logs?limit=500', { token: A.token });
    assertStatus(res, 200, 'list');
    const actions = new Set(res.data.auditLogs.map((l: { action: string }) => l.action));
    for (const a of ['MERCHANT_SIGNUP', 'USER_LOGIN', 'USER_LOGIN_FAILED', 'PRODUCT_CREATED', 'PRODUCT_UPDATED', 'CUSTOMER_CREATED', 'CUSTOMER_DELETED', 'ORDER_CREATED', 'ORDER_CANCELLED', 'PAYMENT_FAILED', 'PAYMENT_SUCCEEDED', 'BUYER_CHECKOUT_COMPLETED', 'AI_OPPORTUNITY_DISCOVERED', 'MERCHANT_SETTINGS_UPDATED']) {
      assert(actions.has(a), `missing audit action ${a}`);
    }
    const filtered = await api('/api/audit-logs?action=PRODUCT_CREATED', { token: A.token });
    assert(filtered.data.auditLogs.every((l: { action: string }) => l.action === 'PRODUCT_CREATED'), 'action filter');
    const limited = await api('/api/audit-logs?limit=2', { token: A.token });
    assertEqual(limited.data.auditLogs.length, 2, 'limit');
    assertStatus(await api('/api/audit-logs?action=bad%20value', { token: A.token }), 400, 'bad filter');
  });

  // ===========================================================================
  t.section('Multi-tenant isolation');
  // ===========================================================================
  await t.test('second merchant starts empty', async () => {
    B = await signup('bravo');
    const m = await api('/api/dashboard/stats', { token: B.token });
    assertEqual(m.data.metrics.totalOrders, 0, 'orders');
    assertEqual(m.data.metrics.totalGmv, 0, 'gmv');
    assertEqual(m.data.metrics.conversionRate, 0, 'conversion');
    assertEqual(m.data.chartData.every((d: { revenue: number }) => d.revenue === 0), true, 'empty chart');
    const lists = await Promise.all(['/api/products', '/api/customers', '/api/orders', '/api/transactions', '/api/agents', '/api/approvals'].map((p) => api(p, { token: B.token })));
    for (const l of lists) assertStatus(l, 200, 'empty list');
    const insights = await api('/api/ai/insights', { token: B.token });
    assertEqual(insights.data.insights.length, 0, 'no insights');
  });
  await t.test("merchant B cannot read, change or delete merchant A's records (404)", async () => {
    assertStatus(await api(`/api/products/${productId}`, { token: B.token }), 404, 'get product');
    assertStatus(await api(`/api/products/${productId}`, { method: 'PUT', token: B.token, body: { price: 1 } }), 404, 'update product');
    assertStatus(await api(`/api/products/${productId}`, { method: 'DELETE', token: B.token }), 404, 'delete product');
    assertStatus(await api(`/api/customers/${customerId}`, { token: B.token }), 404, 'get customer');
    assertStatus(await api(`/api/customers/${customerId}`, { method: 'DELETE', token: B.token }), 404, 'delete customer');
    assertStatus(await api(`/api/orders/${orderId}`, { token: B.token }), 404, 'get order');
    assertStatus(await api(`/api/orders/${buyerOrderId}`, { method: 'PATCH', token: B.token, body: { status: 'CANCELLED' } }), 404, 'cancel order');
    assertStatus(await api('/api/payments/simulate', { token: B.token, body: { orderId: buyerOrderId, outcome: 'FAILURE' } }), 404, 'pay order');
    assertStatus(await api('/api/payments/create', { token: B.token, body: { orderId } }), 404, 'create payment');
    assertStatus(await api(`/api/approvals/${approvalId}/decide`, { token: B.token, body: { decision: 'REJECT' } }), 404, 'decide approval');
    const bList = await api('/api/products', { token: B.token });
    assertEqual(bList.data.products.length, 0, 'no leakage in lists');
  });
  await t.test('merchant B cannot attach A’s customer or products to its own orders', async () => {
    assertStatus(await api('/api/orders', { token: B.token, body: { customerId, customerName: 'x', customerEmail: `x_${run}@e.test`, items: [{ title: 'x', price: 1 }] } }), 404, 'foreign customer');
    assertStatus(await api('/api/orders', { token: B.token, body: { customerName: 'x', customerEmail: `x_${run}@e.test`, items: [{ productId }] } }), 404, 'foreign product');
    assertStatus(await api('/api/cart/items', { body: { merchantId: B.merchantId, sessionId: `b_${run}_sess`, productId } }), 404, 'foreign product in cart');
  });
  await t.test('same SKU / customer email may exist in different merchants', async () => {
    const p = await api('/api/products', { token: B.token, body: { title: 'Same SKU', price: 5, sku: `APEX-HPH-${run}` } });
    assertStatus(p, 201, 'sku per merchant');
    const c = await api('/api/customers', { token: B.token, body: { name: 'John', email: `john_${run}@consumer.test` } });
    assertStatus(c, 201, 'email per merchant');
  });

  // ===========================================================================
  t.section('Request hardening & edge cases');
  // ===========================================================================
  await t.test('invalid JSON → 400, non-object body → 400, oversized body → 413', async () => {
    assertStatus(await api('/api/products', { token: A.token, rawBody: '{"title": ' }), 400, 'invalid json');
    assertStatus(await api('/api/products', { token: A.token, rawBody: '["not","an","object"]' }), 400, 'array body');
    assertStatus(await api('/api/products', { token: A.token, body: { title: 'Big', price: 1, description: 'x'.repeat(150_000) } }), 413, 'oversized');
  });
  await t.test('query-string operator injection is inert', async () => {
    const res = await api('/api/orders?status[$ne]=PAID&search[$gt]=', { token: A.token });
    assertStatus(res, 200, 'ignored bracket params');
    const repeated = await api('/api/orders?status=PAID&status=PENDING', { token: A.token });
    assertStatus(repeated, 400, 'repeated param');
  });
  await t.test('deleting a product removes it from open carts; orders keep their snapshot', async () => {
    const p = await api('/api/products', { token: A.token, body: { title: 'Ephemeral', price: 3, inventory: 5 } });
    const sess = `eph_${run}_sess`;
    await api('/api/cart/items', { body: { merchantId: A.merchantId, sessionId: sess, productId: p.data.product.id } });
    const o = await api('/api/orders', { token: A.token, body: { customerName: 'E', customerEmail: `e_${run}@e.test`, items: [{ productId: p.data.product.id }] } });
    assertStatus(await api(`/api/products/${p.data.product.id}`, { method: 'DELETE', token: A.token }), 200, 'delete');
    const cart = await api(`/api/cart?merchantId=${A.merchantId}&sessionId=${sess}`);
    assertEqual(cart.data.items.length, 0, 'cart line removed');
    const order = await api(`/api/orders/${o.data.order.id}`, { token: A.token });
    assertEqual(order.data.order.items[0].title, 'Ephemeral', 'order snapshot kept');
  });
  await t.test('deleting a customer unlinks (but keeps) their orders', async () => {
    const c = await api('/api/customers', { token: A.token, body: { name: 'Gone', email: `gone_${run}@e.test` } });
    const o = await api('/api/orders', { token: A.token, body: { customerId: c.data.customer.id, customerName: 'Gone', customerEmail: `gone_${run}@e.test`, items: [{ title: 'x', price: 1 }] } });
    await api(`/api/customers/${c.data.customer.id}`, { method: 'DELETE', token: A.token });
    const order = await api(`/api/orders/${o.data.order.id}`, { token: A.token });
    assertStatus(order, 200, 'order kept');
    assertEqual(order.data.order.customer_id, null, 'customer unlinked');
  });
  await t.test('logout is recorded; the client discards its token', async () => {
    const res = await api('/api/auth/logout', { method: 'POST', token: B.token });
    assertStatus(res, 200, 'logout');
    const logs = await api('/api/audit-logs?action=USER_LOGOUT', { token: B.token });
    assertEqual(logs.data.auditLogs.length, 1, 'logout audited');
  });

  // ===========================================================================
  t.section('Rate limiting');
  // ===========================================================================
  await t.test('repeated failed logins for one account are throttled (429 + Retry-After)', async () => {
    const ip = freshIp();
    let last: ApiResponse | null = null;
    for (let i = 0; i < 11; i++) {
      last = await api('/api/auth/login', { body: { email: B.email, password: `wrong-${i}` }, headers: { 'X-Forwarded-For': ip } });
    }
    assert(last, 'responses');
    assertStatus(last, 429, '11th attempt');
    assert(Number(last.headers.get('retry-after')) > 0, 'Retry-After header');
    const correct = await api('/api/auth/login', { body: { email: B.email, password: B.password }, headers: { 'X-Forwarded-For': ip } });
    assertStatus(correct, 429, 'still throttled for the window');
  });

  return t.summary();
}
