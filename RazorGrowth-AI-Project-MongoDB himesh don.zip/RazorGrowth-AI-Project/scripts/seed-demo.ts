/**
 * Optional demo data: two merchant workspaces (Apex Electronics and Nova
 * Apparel) with products, customers, orders, payments, an AI insight and a
 * pending approval, so the dashboard and tenant isolation can be explored.
 *
 *   npm run seed:demo
 *
 * Demo logins (password "Password123!"):
 *   alex@apexelectronics.com   liam@novaapparel.com
 *
 * Refuses to run when NODE_ENV=production unless --force is passed, and is a
 * no-op if the demo workspaces already exist. Never run this against a real
 * production database.
 */
import 'dotenv/config';
import bcrypt from 'bcryptjs';
import { ObjectId } from 'mongodb';
import { closeMongoClient, getCollections, type Collections } from '../server/db/mongo.js';
import type { Currency, OrderItemDoc, ProductDoc } from '../server/db/models.js';
import { toCents } from '../server/lib/money.js';
import { orderReference } from '../server/services/orders.js';

const DEMO_PASSWORD = 'Password123!';
const now = () => new Date();

interface ProductSeed {
  title: string;
  description: string;
  price: number;
  compareAt: number;
  category: string;
  inventory: number;
  sku: string;
  image: string;
}

async function createMerchant(
  cols: Collections,
  m: { name: string; slug: string; email: string; owner: string; ownerEmail: string; currency: Currency },
  passwordHash: string
) {
  const merchantId = new ObjectId();
  const userId = new ObjectId();
  await cols.merchants.insertOne({
    _id: merchantId, name: m.name, slug: m.slug, email: m.email, currency: m.currency, settings: {}, createdAt: now(), updatedAt: now(),
  });
  await cols.users.insertOne({
    _id: userId, merchantId, name: m.owner, email: m.ownerEmail, passwordHash, role: 'owner', lastLoginAt: null, createdAt: now(), updatedAt: now(),
  });
  await cols.auditLogs.insertOne({
    _id: new ObjectId(), merchantId, actorType: 'USER', actorId: userId.toHexString(), actorEmail: m.ownerEmail,
    action: 'MERCHANT_WORKSPACE_INITIALIZED', entityType: 'MERCHANT', entityId: merchantId.toHexString(),
    details: `Merchant workspace ${m.name} established with default ${m.currency} currency.`, ipAddress: 'seed', createdAt: now(),
  });
  return merchantId;
}

async function createProducts(cols: Collections, merchantId: ObjectId, seeds: ProductSeed[]): Promise<ProductDoc[]> {
  const docs: ProductDoc[] = seeds.map((p) => ({
    _id: new ObjectId(), merchantId, title: p.title, description: p.description, priceCents: toCents(p.price),
    compareAtPriceCents: toCents(p.compareAt), category: p.category, inventory: p.inventory, sku: p.sku, imageUrl: p.image,
    status: 'active', createdAt: now(), updatedAt: now(),
  }));
  await cols.products.insertMany(docs);
  return docs;
}

async function createPaidOrFailedOrder(
  cols: Collections,
  merchantId: ObjectId,
  customer: { id: ObjectId; name: string; email: string },
  products: Array<{ product: ProductDoc; qty: number }>,
  outcome: { status: 'PAID' | 'FAILED'; method: string; failureReason?: string }
) {
  const items: OrderItemDoc[] = products.map(({ product, qty }) => ({
    productId: product._id, title: product.title, priceCents: product.priceCents, quantity: qty,
    subtotalCents: product.priceCents * qty, sku: product.sku, imageUrl: product.imageUrl,
  }));
  const total = items.reduce((s, i) => s + i.subtotalCents, 0);
  const orderId = new ObjectId();
  const paymentId = new ObjectId();
  const paid = outcome.status === 'PAID';
  await cols.orders.insertOne({
    _id: orderId, merchantId, reference: orderReference(orderId), customerId: customer.id, customerName: customer.name,
    customerEmail: customer.email, totalAmountCents: total, currency: 'USD', status: outcome.status,
    paymentStatus: paid ? 'PAID' : 'FAILED', itemsCount: items.length, items, source: 'MERCHANT', paidAt: paid ? now() : null,
    createdAt: now(), updatedAt: now(),
  });
  await cols.payments.insertOne({
    _id: paymentId, merchantId, orderId, amountCents: total, currency: 'USD', status: paid ? 'SUCCESS' : 'FAILED', attemptCount: 1,
    method: outcome.method, errorCode: paid ? null : '3DS_TIMEOUT', errorMessage: outcome.failureReason ?? null, clientSecretHash: null,
    createdAt: now(), updatedAt: now(),
  });
  await cols.transactions.insertOne({
    _id: new ObjectId(), merchantId, orderId, paymentId, amountCents: total, currency: 'USD', status: paid ? 'SUCCESS' : 'FAILED',
    paymentMethod: outcome.method, gatewayReference: `gw_seed_${orderId.toHexString().slice(-8)}`, failureReason: outcome.failureReason ?? null,
    customerName: customer.name, customerEmail: customer.email, createdAt: now(), updatedAt: now(),
  });
  if (paid) {
    await cols.customers.updateOne({ _id: customer.id }, { $inc: { totalSpentCents: total, ordersCount: 1 } });
  }
}

async function main(): Promise<void> {
  if (process.env.NODE_ENV === 'production' && !process.argv.includes('--force')) {
    throw new Error('Refusing to seed demo data with NODE_ENV=production (pass --force to override).');
  }
  const cols = await getCollections();
  if (await cols.merchants.findOne({ slug: { $in: ['apex-electronics', 'nova-apparel'] } })) {
    console.log('Demo workspaces already exist — nothing to do.');
    return;
  }

  const passwordHash = await bcrypt.hash(DEMO_PASSWORD, 12);

  // --- Apex Electronics -------------------------------------------------------
  const apex = await createMerchant(cols, {
    name: 'Apex Electronics', slug: 'apex-electronics', email: 'admin@apexelectronics.com',
    owner: 'Alex Chen', ownerEmail: 'alex@apexelectronics.com', currency: 'USD',
  }, passwordHash);
  const img = (id: string) => `https://images.unsplash.com/${id}?w=800&auto=format&fit=crop&q=80`;
  const [headphones, laptop, desk, , charger] = await createProducts(cols, apex, [
    { title: 'Quantum Pro Noise-Cancelling Headphones', description: 'Studio-grade acoustic transparency with active adaptive ANC and 40h battery life.', price: 299.99, compareAt: 349.99, category: 'Audio', inventory: 42, sku: 'APX-QPRO-BLK', image: img('photo-1505740420928-5e560c06d30e') },
    { title: 'AeroBook Ultra 16" Gaming & AI Laptop', description: 'Intel Core Ultra 9, RTX 4080, 32GB DDR5, 1TB NVMe with 240Hz OLED Display.', price: 1899.0, compareAt: 2199.0, category: 'Computers', inventory: 15, sku: 'APX-AERO-16', image: img('photo-1603302576837-37561b2e2302') },
    { title: 'ErgoLift Dual-Motor Standing Desk', description: 'Solid walnut desktop, anti-collision sensor, programmable 4-height memory keypad.', price: 499.0, compareAt: 599.0, category: 'Workstation', inventory: 28, sku: 'APX-DESK-WNT', image: img('photo-1587829741301-dc798b83add3') },
    { title: 'HyperPulse 4K AI Conference Webcam', description: 'Auto-framing Sony STARVIS sensor with dual beamforming microphones.', price: 139.5, compareAt: 169.0, category: 'Accessories', inventory: 64, sku: 'APX-CAM-4K', image: img('photo-1587829741301-dc798b83add3') },
    { title: 'TitanCharge 140W GaN Fast Charger', description: 'Multi-port USB-C fast charging brick supporting PD 3.1 and laptop fast charging.', price: 69.99, compareAt: 89.99, category: 'Accessories', inventory: 110, sku: 'APX-CHG-140', image: img('photo-1583863788434-e58a36330cf0') },
  ]);
  const apexCustomers = [
    { name: 'Sarah Jenkins', email: 'sarah.j@techcorp.io', phone: '+1 555-0192' },
    { name: 'David Kumar', email: 'david.k@startup.co', phone: '+1 555-0144' },
    { name: 'Elena Rostova', email: 'elena.rostova@design.net', phone: '+1 555-0177' },
    { name: 'Marcus Brody', email: 'marcus@brodyventures.com', phone: '+1 555-0129' },
  ].map((c) => ({ ...c, _id: new ObjectId() }));
  await cols.customers.insertMany(apexCustomers.map((c) => ({
    _id: c._id, merchantId: apex, name: c.name, email: c.email, phone: c.phone, totalSpentCents: 0, ordersCount: 0, status: 'active' as const, createdAt: now(), updatedAt: now(),
  })));
  const [sarah, david, elena] = apexCustomers;
  await createPaidOrFailedOrder(cols, apex, { id: sarah._id, name: sarah.name, email: sarah.email }, [{ product: laptop, qty: 1 }, { product: headphones, qty: 1 }], { status: 'PAID', method: 'Visa ending in 4242' });
  await createPaidOrFailedOrder(cols, apex, { id: david._id, name: david.name, email: david.email }, [{ product: charger, qty: 2 }], { status: 'PAID', method: 'Apple Pay' });
  await createPaidOrFailedOrder(cols, apex, { id: elena._id, name: elena.name, email: elena.email }, [{ product: desk, qty: 1 }], { status: 'FAILED', method: 'Mastercard ending in 8812', failureReason: '3D Secure Authentication Timeout' });

  const insightId = new ObjectId();
  const taskId = new ObjectId();
  await cols.aiInsights.insertOne({
    _id: insightId, merchantId: apex, title: 'Autonomous Payment Cascading & Smart Retry Engine', category: 'PAYMENT_OPTIMIZATION', impactScore: 96,
    summary: '1 failed payment attempt totalling $499.00 (33.3% of 3 attempts) is unrecovered in your transaction ledger.',
    recommendation: 'Deploy the Autonomous Payment Cascading Agent to dynamically route transactions through fallback gateways and trigger SMS verification when primary card rails fail.',
    status: 'ACTIVE', potentialRevenueLiftCents: toCents(149.7), metadata: { seeded: true }, agentTaskId: taskId, createdAt: now(), updatedAt: now(),
  });
  await cols.agentTasks.insertOne({
    _id: taskId, merchantId: apex, title: 'Autonomous Payment Routing & Retry Agent', agentType: 'SMART_RETRY_OPTIMIZER', status: 'PENDING_APPROVAL',
    triggerReason: 'Payment failure rate is 33.3% (1/3 attempts).', proposedAction: 'Configure dynamic gateway cascade with instant OTP retry fallback on failed transactions.',
    executionResult: null, impactMetric: 'Projected recovery of $149.70 (30% of failed payment value)', insightId, createdAt: now(), updatedAt: now(),
  });
  await cols.approvals.insertOne({
    _id: new ObjectId(), merchantId: apex, agentTaskId: taskId, title: 'Authorize Deployment: Autonomous Payment Routing & Retry Agent',
    description: 'Approval needed to execute: Configure dynamic gateway cascade with instant OTP retry fallback on failed transactions.',
    status: 'PENDING', requestedBy: 'RazorGrowth AI Engine', resolvedBy: null, resolvedAt: null, notes: null, createdAt: now(), updatedAt: now(),
  });

  // --- Nova Apparel (second tenant, for isolation checks) ---------------------
  const nova = await createMerchant(cols, {
    name: 'Nova Apparel', slug: 'nova-apparel', email: 'contact@novaapparel.com',
    owner: 'Liam Walker', ownerEmail: 'liam@novaapparel.com', currency: 'USD',
  }, passwordHash);
  const [tee, hoodie] = await createProducts(cols, nova, [
    { title: 'Organic Pima Cotton Heavyweight Tee', description: 'Ultra-soft 280 GSM organic Peruvian pima cotton with reinforced collar.', price: 48.0, compareAt: 58.0, category: 'Tops', inventory: 90, sku: 'NVA-TEE-BLK', image: img('photo-1521572267360-ee0c2909d518') },
    { title: 'Merino Wool Technical Thermal Hoodie', description: 'Naturally odor-resistant Australian Merino wool blend with thumbholes and zippered pocket.', price: 138.0, compareAt: 165.0, category: 'Outerwear', inventory: 35, sku: 'NVA-MRN-HDY', image: img('photo-1556905055-8f358a7a47b2') },
    { title: 'All-Weather Commuter Trench Jacket', description: 'Waterproof breathable 3-layer shell with magnetic closures and taped seams.', price: 220.0, compareAt: 260.0, category: 'Outerwear', inventory: 22, sku: 'NVA-TRN-JKT', image: img('photo-1544441893-675973e31985') },
  ]);
  const oliverId = new ObjectId();
  await cols.customers.insertOne({
    _id: oliverId, merchantId: nova, name: 'Oliver Smith', email: 'oliver.smith@example.com', phone: '+1 555-0811', totalSpentCents: 0, ordersCount: 0, status: 'active', createdAt: now(), updatedAt: now(),
  });
  await createPaidOrFailedOrder(cols, nova, { id: oliverId, name: 'Oliver Smith', email: 'oliver.smith@example.com' }, [{ product: tee, qty: 1 }, { product: hoodie, qty: 1 }], { status: 'PAID', method: 'Apple Pay' });

  console.log('Seeded demo workspaces: Apex Electronics and Nova Apparel.');
  console.log(`Log in as alex@apexelectronics.com or liam@novaapparel.com with password "${DEMO_PASSWORD}".`);
}

main()
  .then(() => closeMongoClient())
  .catch(async (err: unknown) => {
    console.error('Demo seed failed:', err instanceof Error ? err.message : err);
    await closeMongoClient().catch(() => undefined);
    process.exit(1);
  });
