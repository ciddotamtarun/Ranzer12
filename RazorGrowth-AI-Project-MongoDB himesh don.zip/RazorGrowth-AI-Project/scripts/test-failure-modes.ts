/**
 * Verifies graceful failure when the deployment is misconfigured or MongoDB
 * is unreachable, plus environment-aware CORS. Each scenario boots the Vercel
 * handler in its own process with a different environment.
 *
 *   MONGODB_URI=... npm run test:failure-modes
 *
 * MONGODB_URI (a reachable server) is needed only for the production-mode
 * scenarios; the others deliberately point at missing/unreachable databases.
 */
import 'dotenv/config';
import { spawn } from 'node:child_process';
import crypto from 'node:crypto';
import { Runner, assert, assertEqual, assertStatus, createClient, freshIp } from './tests/harness.js';
import { dropTestDatabase } from './tests/cleanup.js';

const reachableUri = process.env.MONGODB_URI;

async function withServer(env: Record<string, string | undefined>, fn: (baseUrl: string) => Promise<void>): Promise<void> {
  const port = 5800 + Math.floor(Math.random() * 1000);
  const childEnv: NodeJS.ProcessEnv = { ...process.env, PORT: String(port) };
  // Scenario env replaces (or removes) variables, and .env must not re-add them.
  for (const [key, value] of Object.entries(env)) {
    if (value === undefined) delete childEnv[key];
    else childEnv[key] = value;
  }
  childEnv.DOTENV_CONFIG_PATH = '/nonexistent/.env';
  const child = spawn(process.execPath, ['--import', 'tsx', 'scripts/tests/vercel-emulator.ts'], { env: childEnv, stdio: 'ignore' });
  const baseUrl = `http://127.0.0.1:${port}`;
  try {
    const deadline = Date.now() + 30_000;
    for (;;) {
      try {
        await fetch(`${baseUrl}/api/does-not-exist`);
        break;
      } catch {
        if (Date.now() > deadline) throw new Error('server did not start');
        await new Promise((r) => setTimeout(r, 300));
      }
    }
    await fn(baseUrl);
  } finally {
    child.kill('SIGTERM');
  }
}

const signupBody = () => ({
  name: 'Failure Mode',
  email: `fm_${crypto.randomBytes(4).toString('hex')}@example.test`,
  password: 'Password123!',
  merchantName: 'Failure Mode Co',
});

async function main(): Promise<number> {
  const t = new Runner();

  t.section('MONGODB_URI missing');
  await withServer({ MONGODB_URI: undefined, JWT_SECRET: 'x'.repeat(48) }, async (base) => {
    const api = createClient(base);
    await t.test('health reports not_configured (503)', async () => {
      const res = await api('/api/health');
      assertStatus(res, 503, 'health');
      assertEqual(res.data.database, 'not_configured', 'database');
    });
    await t.test('data endpoints return a clear configuration error (500 CONFIG_ERROR)', async () => {
      const res = await api('/api/auth/signup', { body: signupBody(), headers: { 'X-Forwarded-For': freshIp() } });
      assertStatus(res, 500, 'signup');
      assertEqual(res.data.code, 'CONFIG_ERROR', 'code');
      assert(String(res.data.error).includes('MONGODB_URI'), 'message names the variable');
    });
    await t.test('auth guard still answers 401 before touching the database', async () => {
      assertStatus(await api('/api/products'), 401, 'products');
    });
  });

  t.section('MongoDB unreachable');
  await withServer({ MONGODB_URI: 'mongodb://127.0.0.1:1/razorgrowth', JWT_SECRET: 'x'.repeat(48) }, async (base) => {
    const api = createClient(base);
    await t.test('health reports unavailable (503) quickly', async () => {
      const started = Date.now();
      const res = await api('/api/health');
      assertStatus(res, 503, 'health');
      assertEqual(res.data.database, 'unavailable', 'database');
      assert(Date.now() - started < 6_000, 'health check must not hang');
    });
    await t.test('requests fail with 503 DATABASE_UNAVAILABLE + Retry-After (no crash, no hang)', async () => {
      const res = await api('/api/auth/signup', { body: signupBody(), headers: { 'X-Forwarded-For': freshIp() } });
      assertStatus(res, 503, 'signup');
      assertEqual(res.data.code, 'DATABASE_UNAVAILABLE', 'code');
      assert(res.headers.get('retry-after'), 'Retry-After header');
    });
    await t.test('a later request retries the connection instead of reusing a failed one', async () => {
      const res = await api('/api/auth/login', { body: { email: 'a@b.co', password: 'Password123!' }, headers: { 'X-Forwarded-For': freshIp() } });
      assertStatus(res, 503, 'second request');
    });
  });

  t.section('Invalid MONGODB_URI');
  await withServer({ MONGODB_URI: 'postgres://user:pw@db.example.com/app', JWT_SECRET: 'x'.repeat(48) }, async (base) => {
    const api = createClient(base);
    await t.test('non-MongoDB connection string → 500 CONFIG_ERROR', async () => {
      const res = await api('/api/auth/signup', { body: signupBody(), headers: { 'X-Forwarded-For': freshIp() } });
      assertStatus(res, 500, 'signup');
      assertEqual(res.data.code, 'CONFIG_ERROR', 'code');
    });
  });

  if (reachableUri) {
    const dbName = `razorgrowth_failmodes_${Date.now()}`;

    t.section('Production mode without a proper JWT_SECRET');
    for (const [label, secret] of [['missing', undefined], ['too short', 'short-secret-123']] as const) {
      await withServer({ MONGODB_URI: reachableUri, MONGODB_DB: dbName, NODE_ENV: 'production', JWT_SECRET: secret }, async (base) => {
        const api = createClient(base);
        await t.test(`JWT_SECRET ${label}: signup refuses to issue tokens (500 CONFIG_ERROR) and writes nothing`, async () => {
          const body = signupBody();
          const res = await api('/api/auth/signup', { body, headers: { 'X-Forwarded-For': freshIp() } });
          assertStatus(res, 500, 'signup');
          const { MongoClient } = await import('mongodb');
          const client = new MongoClient(reachableUri);
          try {
            await client.connect();
            const users = await client.db(dbName).collection('users').countDocuments({ email: body.email });
            const merchants = await client.db(dbName).collection('merchants').countDocuments({ email: body.email });
            assertEqual(users + merchants, 0, 'no partial account created');
          } finally {
            await client.close();
          }
          assertEqual(res.data.code, 'CONFIG_ERROR', 'code');
          assert(String(res.data.error).includes('JWT_SECRET'), 'names JWT_SECRET');
          assert(!('detail' in res.data), 'no internal detail in production');
        });
        await t.test(`JWT_SECRET ${label}: protected routes return CONFIG_ERROR, not 401/200`, async () => {
          const res = await api('/api/products', { token: 'a.b.c' });
          assertStatus(res, 500, 'products');
          assertEqual(res.data.code, 'CONFIG_ERROR', 'code');
        });
      });
    }

    t.section('CORS');
    await withServer(
      { MONGODB_URI: reachableUri, MONGODB_DB: dbName, NODE_ENV: 'production', JWT_SECRET: 'p'.repeat(48), CORS_ORIGINS: 'https://app.example.com' },
      async (base) => {
        const preflight = (origin: string) =>
          fetch(`${base}/api/products`, { method: 'OPTIONS', headers: { Origin: origin, 'Access-Control-Request-Method': 'GET' } });
        await t.test('production: allow-listed origin is accepted', async () => {
          const res = await preflight('https://app.example.com');
          assertEqual(res.headers.get('access-control-allow-origin'), 'https://app.example.com', 'allowed origin');
          assert(!res.headers.get('access-control-allow-credentials'), 'credentials never allowed');
        });
        await t.test('production: unknown origins and localhost get no CORS grant', async () => {
          assertEqual((await preflight('https://evil.example.net')).headers.get('access-control-allow-origin'), null, 'evil origin');
          assertEqual((await preflight('http://localhost:5173')).headers.get('access-control-allow-origin'), null, 'localhost in prod');
        });
      }
    );
    await withServer({ MONGODB_URI: reachableUri, MONGODB_DB: dbName, NODE_ENV: 'development', JWT_SECRET: undefined }, async (base) => {
      await t.test('development: Vite dev origin is accepted', async () => {
        const res = await fetch(`${base}/api/products`, { method: 'OPTIONS', headers: { Origin: 'http://localhost:5173', 'Access-Control-Request-Method': 'GET' } });
        assertEqual(res.headers.get('access-control-allow-origin'), 'http://localhost:5173', 'dev origin');
      });
      await t.test('development without JWT_SECRET falls back to a per-process secret', async () => {
        const res = await createClient(base)('/api/auth/signup', { body: signupBody(), headers: { 'X-Forwarded-For': freshIp() } });
        assertStatus(res, 201, 'signup works in development');
      });
    });

    await dropTestDatabase(reachableUri, dbName).catch((err: unknown) => {
      console.warn(`Could not remove temporary database "${dbName}": ${err instanceof Error ? err.message : err}`);
    });
  } else {
    t.skip('production-mode JWT_SECRET and CORS scenarios', 'MONGODB_URI not set');
  }

  const { failed } = t.summary();
  return failed === 0 ? 0 : 1;
}

main().then(
  (code) => process.exit(code),
  (err) => {
    console.error(err);
    process.exit(1);
  }
);
