/**
 * RazorGrowth AI — end-to-end API test runner.
 *
 *   npm run test:e2e
 *     Boots the Vercel serverless handler (api/[...path].ts) in a child process
 *     against a throwaway database on MONGODB_URI, runs the suite, then drops
 *     the throwaway database. Your application database is never touched.
 *
 *   API_BASE_URL=http://localhost:5000 npm run test:e2e
 *     Runs the suite against an already-running server (e.g. `npm run server`
 *     or a Vercel preview URL). Test data is created in that server's database.
 *     Set TEST_JWT_SECRET to that server's JWT_SECRET to include forged-token tests.
 */
import 'dotenv/config';
import { spawn, type ChildProcess } from 'node:child_process';
import crypto from 'node:crypto';
import { runE2ESuite } from './tests/e2e-suite.js';
import { waitForHealthy } from './tests/harness.js';
import { dropTestDatabase } from './tests/cleanup.js';

async function main(): Promise<number> {
  const external = process.env.API_BASE_URL?.replace(/\/+$/, '');
  if (external) {
    console.log(`Running E2E suite against ${external}`);
    await waitForHealthy(external);
    const result = await runE2ESuite({ baseUrl: external, jwtSecret: process.env.TEST_JWT_SECRET });
    return result.failed === 0 ? 0 : 1;
  }

  const mongoUri = process.env.MONGODB_URI;
  if (!mongoUri) {
    console.error('MONGODB_URI is required (the suite creates and drops a temporary database on it).');
    console.error('Or set API_BASE_URL to test an already-running server.');
    return 1;
  }

  const dbName = `razorgrowth_e2e_${Date.now()}`;
  const jwtSecret = crypto.randomBytes(48).toString('hex');
  const port = 5200 + Math.floor(Math.random() * 500);
  const baseUrl = `http://127.0.0.1:${port}`;

  console.log(`Booting api/[...path].ts (Vercel runtime emulation) on ${baseUrl}, database "${dbName}"`);
  const child: ChildProcess = spawn(process.execPath, ['--import', 'tsx', 'scripts/tests/vercel-emulator.ts'], {
    env: { ...process.env, PORT: String(port), MONGODB_DB: dbName, JWT_SECRET: jwtSecret, NODE_ENV: 'test' },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  const logs: string[] = [];
  child.stdout?.on('data', (d: Buffer) => logs.push(d.toString()));
  child.stderr?.on('data', (d: Buffer) => logs.push(d.toString()));

  let exitCode = 1;
  try {
    await waitForHealthy(baseUrl, 45_000);
    const result = await runE2ESuite({ baseUrl, jwtSecret });
    exitCode = result.failed === 0 ? 0 : 1;
    const serverErrors = logs.join('').split('\n').filter((l) => l.includes('[API Error]'));
    if (serverErrors.length) {
      console.log(`\nServer logged ${serverErrors.length} unexpected 5xx error(s):`);
      serverErrors.slice(0, 10).forEach((l) => console.log('  ' + l));
      exitCode = 1;
    }
  } catch (err) {
    console.error(err instanceof Error ? err.message : err);
    console.error(logs.join('').slice(-4000));
  } finally {
    child.kill('SIGTERM');
    try {
      await dropTestDatabase(mongoUri, dbName);
      console.log(`Removed temporary database "${dbName}".`);
    } catch (err) {
      console.warn(`Could not remove temporary database "${dbName}": ${err instanceof Error ? err.message : err}`);
    }
  }
  return exitCode;
}

main().then(
  (code) => process.exit(code),
  (err) => {
    console.error(err);
    process.exit(1);
  }
);
