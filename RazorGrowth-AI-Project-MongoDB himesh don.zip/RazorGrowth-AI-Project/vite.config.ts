import { defineConfig, loadEnv } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

// https://vite.dev/config/
export default defineConfig(({ mode }) => {
  // Dev-only: proxy /api to the local Express server (same PORT as server/index.ts).
  // Production builds call /api on the same origin (Vercel), so no URL is baked in.
  const env = loadEnv(mode, process.cwd(), '')
  const apiPort = env.PORT || '5000'

  return {
    plugins: [react(), tailwindcss()],
    server: {
      port: 5173,
      proxy: {
        '/api': {
          target: `http://127.0.0.1:${apiPort}`,
          changeOrigin: true,
        },
      },
    },
  }
})
