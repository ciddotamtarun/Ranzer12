import express, { type NextFunction, type Request, type Response } from 'express';
import cors from 'cors';
import { MongoParseError } from 'mongodb';

import { ConfigError, IS_VERCEL, getCorsOrigins, isProduction } from './config.js';
import { HttpError, isDuplicateKeyError } from './lib/errors.js';
import { isDatabaseUnavailableError, pingDatabase } from './db/mongo.js';

import authRouter from './routes/auth.js';
import merchantsRouter from './routes/merchants.js';
import dashboardRouter from './routes/dashboard.js';
import productsRouter from './routes/products.js';
import customersRouter from './routes/customers.js';
import ordersRouter from './routes/orders.js';
import transactionsRouter from './routes/transactions.js';
import paymentsRouter from './routes/payments.js';
import aiRouter from './routes/ai.js';
import agentsRouter from './routes/agents.js';
import approvalsRouter from './routes/approvals.js';
import auditLogsRouter from './routes/auditLogs.js';
import buyerRouter from './routes/buyer.js';
import cartRouter from './routes/cart.js';

export const app = express();

app.disable('x-powered-by');
// On Vercel the platform proxy sets X-Forwarded-For (overwriting any client
// value), so it is trusted. Elsewhere only a loopback proxy (the Vite dev
// server) is trusted, so clients cannot spoof their IP for rate limiting.
app.set('trust proxy', IS_VERCEL ? true : 'loopback');

// --- Security headers (API responses are JSON and never cached) -------------
app.use((_req: Request, res: Response, next: NextFunction) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Cache-Control', 'no-store');
  next();
});

// --- CORS ---------------------------------------------------------------------
// The frontend calls the API on the same origin (relative /api/* URLs), which
// needs no CORS. Cross-origin browser access is limited to CORS_ORIGINS (plus
// the Vite dev server outside production). Auth uses Bearer tokens, not
// cookies, so credentials are never allowed cross-origin.
app.use(
  cors({
    origin(origin, callback) {
      callback(null, origin ? getCorsOrigins().includes(origin) : false);
    },
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization'],
    maxAge: 600,
  })
);

// --- Body parsing -------------------------------------------------------------
// The Vercel Node runtime installs its own lazily-parsed `req.body` (and may
// already have consumed the request stream). In that case the platform body is
// used as-is; everywhere else Express parses JSON itself.
const MAX_BODY_BYTES = 100 * 1024;
const jsonParser = express.json({ limit: MAX_BODY_BYTES });
app.use((req: Request, res: Response, next: NextFunction) => {
  // Enforced here too because the platform-parsed body bypasses express.json's limit.
  const declaredLength = Number(req.headers['content-length'] ?? 0);
  if (declaredLength > MAX_BODY_BYTES) {
    next(new HttpError(413, 'Request body is too large.'));
    return;
  }
  if (Object.prototype.hasOwnProperty.call(req, 'body')) {
    next();
    return;
  }
  jsonParser(req, res, next);
});

// --- Request logging (path only: query strings can contain emails) -----------
app.use((req: Request, res: Response, next: NextFunction) => {
  if (req.path.startsWith('/api/health')) {
    next();
    return;
  }
  const started = Date.now();
  res.on('finish', () => {
    console.log(`[API] ${req.method} ${req.path} ${res.statusCode} ${Date.now() - started}ms`);
  });
  next();
});

// --- Health check ---------------------------------------------------------------
app.get('/api/health', async (_req: Request, res: Response) => {
  const configured = Boolean(process.env.MONGODB_URI?.trim());
  const connected = configured ? await pingDatabase() : false;
  res.status(connected ? 200 : 503).json({
    status: connected ? 'online' : 'degraded',
    app: 'RazorGrowth AI Full-Stack Platform',
    database: connected ? 'connected' : configured ? 'unavailable' : 'not_configured',
    timestamp: new Date().toISOString(),
  });
});

// --- Routes ---------------------------------------------------------------------
app.use('/api/auth', authRouter);
app.use('/api/merchants', merchantsRouter);
app.use('/api/dashboard', dashboardRouter);
app.use('/api/products', productsRouter);
app.use('/api/customers', customersRouter);
app.use('/api/orders', ordersRouter);
app.use('/api/transactions', transactionsRouter);
app.use('/api/payments', paymentsRouter);
app.use('/api/ai', aiRouter);
app.use('/api/agents', agentsRouter);
app.use('/api/approvals', approvalsRouter);
app.use('/api/audit-logs', auditLogsRouter);
app.use('/api/buyer', buyerRouter);
app.use('/api/cart', cartRouter);

// --- 404 for unknown routes --------------------------------------------------------
app.use((req: Request, res: Response) => {
  res.status(404).json({ error: `Route not found: ${req.method} ${req.path}`, code: 'NOT_FOUND' });
});

// --- Central error handler -----------------------------------------------------
interface ErrorResponse {
  status: number;
  body: { error: string; code: string; detail?: string };
  headers?: Record<string, string>;
}

function statusFromUnknown(err: unknown): number | null {
  if (err && typeof err === 'object') {
    const candidate = (err as { status?: unknown; statusCode?: unknown }).status ?? (err as { statusCode?: unknown }).statusCode;
    if (typeof candidate === 'number' && candidate >= 400 && candidate < 500) return candidate;
  }
  return null;
}

function toErrorResponse(err: unknown): ErrorResponse {
  if (err instanceof HttpError) {
    return { status: err.status, body: { error: err.message, code: err.code }, headers: err.headers };
  }
  if (err instanceof ConfigError) {
    return { status: 500, body: { error: `Server configuration error: ${err.message}`, code: 'CONFIG_ERROR' } };
  }
  if (err instanceof MongoParseError) {
    return { status: 500, body: { error: 'Server configuration error: MONGODB_URI is not a valid MongoDB connection string.', code: 'CONFIG_ERROR' } };
  }
  if (isDuplicateKeyError(err)) {
    return { status: 409, body: { error: 'A record with the same unique value already exists.', code: 'CONFLICT' } };
  }
  if (isDatabaseUnavailableError(err)) {
    return {
      status: 503,
      body: { error: 'The database is temporarily unavailable. Please try again shortly.', code: 'DATABASE_UNAVAILABLE' },
      headers: { 'Retry-After': '5' },
    };
  }
  // Errors raised by body parsing (Express or the Vercel runtime).
  const clientStatus = statusFromUnknown(err);
  if (clientStatus !== null) {
    const type = (err as { type?: unknown }).type;
    const message =
      type === 'entity.too.large'
        ? 'Request body is too large.'
        : type === 'entity.parse.failed' || /json/i.test(String((err as { message?: unknown }).message))
          ? 'Request body is not valid JSON.'
          : 'Invalid request.';
    return { status: clientStatus, body: { error: message, code: clientStatus === 413 ? 'PAYLOAD_TOO_LARGE' : 'BAD_REQUEST' } };
  }
  const body: ErrorResponse['body'] = { error: 'Internal server error.', code: 'INTERNAL_ERROR' };
  if (!isProduction() && err instanceof Error) body.detail = err.message;
  return { status: 500, body };
}

app.use((err: unknown, req: Request, res: Response, _next: NextFunction) => {
  const { status, body, headers } = toErrorResponse(err);
  if (status >= 500) {
    console.error(`[API Error] ${req.method} ${req.path}:`, err);
  }
  if (res.headersSent) return;
  if (headers) {
    for (const [name, value] of Object.entries(headers)) res.setHeader(name, value);
  }
  res.status(status).json(body);
});
