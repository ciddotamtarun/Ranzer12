import type { NextFunction, Request, Response } from 'express';
import crypto from 'node:crypto';
import { MongoParseError } from 'mongodb';
import { ConfigError, isRateLimitEnabled } from '../config.js';
import { getCollections, isDatabaseUnavailableError } from '../db/mongo.js';
import { HttpError, isDuplicateKeyError } from './errors.js';
import { clientIp } from '../middleware/audit.js';

// Fixed-window rate limiter backed by MongoDB, so limits are shared by every
// serverless instance (an in-memory counter would reset per instance).
// Counter documents expire automatically through the TTL index on expiresAt.

export interface RateLimitResult {
  allowed: boolean;
  retryAfterSeconds: number;
}

function hashKey(key: string): string {
  return crypto.createHash('sha256').update(key).digest('hex').slice(0, 32);
}

export async function consumeRateLimit(key: string, limit: number, windowSeconds: number): Promise<RateLimitResult> {
  const windowMs = windowSeconds * 1000;
  const now = Date.now();
  const windowStart = Math.floor(now / windowMs) * windowMs;
  const docId = `${hashKey(key)}:${windowStart}`;
  const { rateLimits } = await getCollections();

  const increment = () =>
    rateLimits.findOneAndUpdate(
      { _id: docId },
      { $inc: { count: 1 }, $setOnInsert: { expiresAt: new Date(windowStart + windowMs * 2) } },
      { upsert: true, returnDocument: 'after' }
    );

  let doc;
  try {
    doc = await increment();
  } catch (err) {
    // Two concurrent first hits can race on the upsert; the retry updates.
    if (!isDuplicateKeyError(err)) throw err;
    doc = await increment();
  }

  const count = doc?.count ?? 1;
  return {
    allowed: count <= limit,
    retryAfterSeconds: Math.max(1, Math.ceil((windowStart + windowMs - now) / 1000)),
  };
}

/** Reads the current window without consuming it. */
export async function peekRateLimit(key: string, limit: number, windowSeconds: number): Promise<RateLimitResult> {
  const windowMs = windowSeconds * 1000;
  const now = Date.now();
  const windowStart = Math.floor(now / windowMs) * windowMs;
  const { rateLimits } = await getCollections();
  const doc = await rateLimits.findOne({ _id: `${hashKey(key)}:${windowStart}` });
  return {
    allowed: (doc?.count ?? 0) < limit,
    retryAfterSeconds: Math.max(1, Math.ceil((windowStart + windowMs - now) / 1000)),
  };
}

export function tooManyRequests(retryAfterSeconds: number, message?: string): HttpError {
  return new HttpError(429, message ?? 'Too many requests. Please wait a moment and try again.', 'TOO_MANY_REQUESTS', {
    'Retry-After': String(retryAfterSeconds),
  });
}

interface RateLimitOptions {
  name: string;
  limit: number;
  windowSeconds: number;
  /** Extra key material (e.g. the email being logged into); IP is always included. */
  key?: (req: Request) => string | undefined;
  message?: string;
}

/**
 * Express middleware. Fails open (logs and allows) if the limiter itself
 * errors, so a limiter problem never locks every user out.
 */
export function rateLimit(options: RateLimitOptions) {
  return async (req: Request, _res: Response, next: NextFunction): Promise<void> => {
    if (!isRateLimitEnabled()) {
      next();
      return;
    }
    const extra = options.key?.(req);
    const key = `${options.name}|${clientIp(req)}${extra ? `|${extra}` : ''}`;
    let result: RateLimitResult;
    try {
      result = await consumeRateLimit(key, options.limit, options.windowSeconds);
    } catch (err) {
      // If the database itself is down or misconfigured the request cannot
      // succeed anyway, so surface that error immediately (503/500).
      if (isDatabaseUnavailableError(err) || err instanceof ConfigError || err instanceof MongoParseError) {
        next(err);
        return;
      }
      console.error(`[RateLimit] ${options.name} check failed, allowing request:`, err instanceof Error ? err.message : err);
      next();
      return;
    }
    if (!result.allowed) {
      next(tooManyRequests(result.retryAfterSeconds, options.message));
      return;
    }
    next();
  };
}
