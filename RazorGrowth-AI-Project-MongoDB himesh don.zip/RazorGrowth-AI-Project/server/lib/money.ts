// Monetary values are stored as integer minor units (cents) so that sums and
// increments in MongoDB are exact. The API continues to expose decimal amounts
// (e.g. 189.99) to the frontend.

export function toCents(amount: number): number {
  return Math.round((amount + Number.EPSILON) * 100);
}

export function fromCents(cents: number): number {
  return Math.round(cents) / 100;
}

export function formatMoney(cents: number, currency = 'USD'): string {
  const symbol = currency === 'EUR' ? '€' : currency === 'GBP' ? '£' : '$';
  return `${symbol}${fromCents(cents).toFixed(2)}`;
}
