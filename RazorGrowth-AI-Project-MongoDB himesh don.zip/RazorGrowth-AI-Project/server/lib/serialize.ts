import type { ObjectId } from 'mongodb';
import { fromCents } from './money.js';
import type {
  AIInsightDoc,
  AgentTaskDoc,
  ApprovalDoc,
  AuditLogDoc,
  CartItemDoc,
  CustomerDoc,
  MerchantDoc,
  OrderDoc,
  OrderItemDoc,
  PaymentDoc,
  ProductDoc,
  TransactionDoc,
  UserDoc,
} from '../db/models.js';

// Explicit allow-list serializers: MongoDB documents are never sent to the
// client as-is. This converts ObjectIds to strings, cents to decimal amounts,
// Dates to ISO strings, keeps the snake_case response contract the frontend
// uses, and guarantees fields like passwordHash / clientSecretHash never leak.

const id = (value: ObjectId): string => value.toHexString();
const idOrNull = (value: ObjectId | null | undefined): string | null => (value ? value.toHexString() : null);
const iso = (value: Date | null | undefined): string | null => (value ? value.toISOString() : null);

export function serializeUser(doc: UserDoc) {
  return {
    id: id(doc._id),
    merchantId: id(doc.merchantId),
    name: doc.name,
    email: doc.email,
    role: doc.role,
  };
}

export function serializeMerchant(doc: MerchantDoc) {
  return {
    id: id(doc._id),
    name: doc.name,
    slug: doc.slug,
    email: doc.email,
    currency: doc.currency,
    settings: doc.settings ?? {},
    created_at: iso(doc.createdAt),
    updated_at: iso(doc.updatedAt),
  };
}

/** Public storefront view of a merchant (no contact email or settings). */
export function serializePublicMerchant(doc: MerchantDoc) {
  return {
    id: id(doc._id),
    name: doc.name,
    slug: doc.slug,
    currency: doc.currency,
    created_at: iso(doc.createdAt),
  };
}

export function serializeProduct(doc: ProductDoc) {
  return {
    id: id(doc._id),
    merchant_id: id(doc.merchantId),
    title: doc.title,
    description: doc.description,
    price: fromCents(doc.priceCents),
    compare_at_price: doc.compareAtPriceCents === null ? null : fromCents(doc.compareAtPriceCents),
    category: doc.category,
    inventory: doc.inventory,
    sku: doc.sku,
    image_url: doc.imageUrl,
    status: doc.status,
    created_at: iso(doc.createdAt),
    updated_at: iso(doc.updatedAt),
  };
}

export function serializeCustomer(doc: CustomerDoc) {
  return {
    id: id(doc._id),
    merchant_id: id(doc.merchantId),
    name: doc.name,
    email: doc.email,
    phone: doc.phone,
    total_spent: fromCents(doc.totalSpentCents),
    orders_count: doc.ordersCount,
    status: doc.status,
    created_at: iso(doc.createdAt),
    updated_at: iso(doc.updatedAt),
  };
}

export function serializeOrderItem(item: OrderItemDoc) {
  return {
    productId: idOrNull(item.productId),
    title: item.title,
    price: fromCents(item.priceCents),
    quantity: item.quantity,
    subtotal: fromCents(item.subtotalCents),
    sku: item.sku,
    image_url: item.imageUrl,
  };
}

export function serializeOrder(doc: OrderDoc) {
  return {
    id: id(doc._id),
    reference: doc.reference,
    merchant_id: id(doc.merchantId),
    customer_id: idOrNull(doc.customerId),
    customer_name: doc.customerName,
    customer_email: doc.customerEmail,
    total_amount: fromCents(doc.totalAmountCents),
    currency: doc.currency,
    status: doc.status,
    payment_status: doc.paymentStatus,
    items_count: doc.itemsCount,
    items: doc.items.map(serializeOrderItem),
    source: doc.source,
    paid_at: iso(doc.paidAt),
    created_at: iso(doc.createdAt),
    updated_at: iso(doc.updatedAt),
  };
}

export function serializePayment(doc: PaymentDoc) {
  return {
    id: id(doc._id),
    merchant_id: id(doc.merchantId),
    order_id: id(doc.orderId),
    amount: fromCents(doc.amountCents),
    currency: doc.currency,
    status: doc.status,
    attempt_count: doc.attemptCount,
    method: doc.method,
    error_code: doc.errorCode,
    error_message: doc.errorMessage,
    created_at: iso(doc.createdAt),
    updated_at: iso(doc.updatedAt),
  };
}

export function serializeTransaction(doc: TransactionDoc) {
  return {
    id: id(doc._id),
    merchant_id: id(doc.merchantId),
    order_id: id(doc.orderId),
    payment_id: id(doc.paymentId),
    amount: fromCents(doc.amountCents),
    currency: doc.currency,
    status: doc.status,
    payment_method: doc.paymentMethod,
    gateway_reference: doc.gatewayReference,
    failure_reason: doc.failureReason,
    customer_name: doc.customerName,
    customer_email: doc.customerEmail,
    created_at: iso(doc.createdAt),
    updated_at: iso(doc.updatedAt),
  };
}

export function serializeInsight(doc: AIInsightDoc) {
  return {
    id: id(doc._id),
    merchant_id: id(doc.merchantId),
    title: doc.title,
    category: doc.category,
    impact_score: doc.impactScore,
    summary: doc.summary,
    recommendation: doc.recommendation,
    status: doc.status,
    potential_revenue_lift: fromCents(doc.potentialRevenueLiftCents),
    metadata: doc.metadata ?? {},
    agent_task_id: idOrNull(doc.agentTaskId),
    created_at: iso(doc.createdAt),
    updated_at: iso(doc.updatedAt),
  };
}

export function serializeAgentTask(doc: AgentTaskDoc, approval?: ApprovalDoc | null) {
  return {
    id: id(doc._id),
    merchant_id: id(doc.merchantId),
    title: doc.title,
    agent_type: doc.agentType,
    status: doc.status,
    trigger_reason: doc.triggerReason,
    proposed_action: doc.proposedAction,
    execution_result: doc.executionResult,
    impact_metric: doc.impactMetric,
    insight_id: idOrNull(doc.insightId),
    approval_id: approval ? id(approval._id) : null,
    approval_status: approval ? approval.status : null,
    approval_resolved_at: approval ? iso(approval.resolvedAt) : null,
    created_at: iso(doc.createdAt),
    updated_at: iso(doc.updatedAt),
  };
}

export function serializeApproval(doc: ApprovalDoc, task?: AgentTaskDoc | null) {
  return {
    id: id(doc._id),
    merchant_id: id(doc.merchantId),
    agent_task_id: id(doc.agentTaskId),
    title: doc.title,
    description: doc.description,
    status: doc.status,
    requested_by: doc.requestedBy,
    resolved_by: doc.resolvedBy,
    resolved_at: iso(doc.resolvedAt),
    notes: doc.notes,
    created_at: iso(doc.createdAt),
    updated_at: iso(doc.updatedAt),
    agent_type: task ? task.agentType : null,
    trigger_reason: task ? task.triggerReason : null,
    proposed_action: task ? task.proposedAction : null,
    impact_metric: task ? task.impactMetric : null,
    task_status: task ? task.status : null,
  };
}

export function serializeAuditLog(doc: AuditLogDoc) {
  return {
    id: id(doc._id),
    merchant_id: id(doc.merchantId),
    actor_type: doc.actorType,
    actor_id: doc.actorId,
    actor_email: doc.actorEmail,
    action: doc.action,
    entity_type: doc.entityType,
    entity_id: doc.entityId,
    details: doc.details,
    ip_address: doc.ipAddress,
    created_at: iso(doc.createdAt),
  };
}

export function serializeCartItem(item: CartItemDoc) {
  return {
    productId: id(item.productId),
    title: item.title,
    price: fromCents(item.priceCents),
    image_url: item.imageUrl,
    quantity: item.quantity,
    subtotal: fromCents(item.priceCents * item.quantity),
    sku: item.sku,
  };
}
