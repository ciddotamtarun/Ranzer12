import type { Request } from 'express';
import { ObjectId } from 'mongodb';
import { badRequest } from './errors.js';
import { toCents } from './money.js';

// Small, dependency-free input validation helpers.
//
// Every value that reaches a MongoDB filter or update goes through one of these
// functions, which only ever return primitives (string/number/boolean), Dates
// or ObjectIds. That guarantees request data can never smuggle query operators
// such as {"$ne": null} or {"$where": ...} into a query (NoSQL injection).

export type Body = Record<string, unknown>;

const OBJECT_ID_RE = /^[a-f0-9]{24}$/i;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function isPlainObject(value: unknown): value is Record<string, unknown> {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) return false;
  const proto = Object.getPrototypeOf(value) as unknown;
  return proto === Object.prototype || proto === null;
}

/** Returns the JSON request body as a plain object ({} when absent). */
export function readBody(req: Request): Body {
  const body: unknown = req.body;
  if (body === undefined || body === null || body === '') return {};
  if (!isPlainObject(body)) {
    throw badRequest('Request body must be a JSON object.');
  }
  return body;
}

// ---------------------------------------------------------------------------
// Strings
// ---------------------------------------------------------------------------

interface StringOptions {
  min?: number;
  max: number;
  pattern?: RegExp;
  patternMessage?: string;
}

function checkString(raw: unknown, field: string, opts: StringOptions): string {
  if (typeof raw !== 'string') throw badRequest(`${field} must be a string.`);
  const value = raw.trim();
  const min = opts.min ?? 1;
  if (value.length < min) {
    throw badRequest(min <= 1 ? `${field} is required.` : `${field} must be at least ${min} characters.`);
  }
  if (value.length > opts.max) throw badRequest(`${field} must be at most ${opts.max} characters.`);
  if (opts.pattern && !opts.pattern.test(value)) {
    throw badRequest(opts.patternMessage ?? `${field} has an invalid format.`);
  }
  return value;
}

export function requiredString(raw: unknown, field: string, opts: StringOptions): string {
  if (raw === undefined || raw === null || (typeof raw === 'string' && raw.trim() === '')) {
    throw badRequest(`${field} is required.`);
  }
  return checkString(raw, field, opts);
}

/** undefined when absent; otherwise a validated string. */
export function optionalString(raw: unknown, field: string, opts: StringOptions): string | undefined {
  if (raw === undefined) return undefined;
  return checkString(raw, field, opts);
}

/** undefined when absent, null when explicitly null/empty, otherwise validated. */
export function nullableString(raw: unknown, field: string, opts: StringOptions): string | null | undefined {
  if (raw === undefined) return undefined;
  if (raw === null || (typeof raw === 'string' && raw.trim() === '')) return null;
  return checkString(raw, field, { ...opts, min: 1 });
}

export function requiredEmail(raw: unknown, field = 'Email'): string {
  const value = requiredString(raw, field, { max: 254 });
  if (!EMAIL_RE.test(value)) throw badRequest('Please enter a valid email address.');
  return value.toLowerCase();
}

export function optionalEmail(raw: unknown, field = 'Email'): string | undefined {
  if (raw === undefined) return undefined;
  return requiredEmail(raw, field);
}

export function enumValue<T extends string>(raw: unknown, field: string, allowed: readonly T[]): T {
  if (typeof raw !== 'string' || !(allowed as readonly string[]).includes(raw)) {
    throw badRequest(`${field} must be one of: ${allowed.join(', ')}.`);
  }
  return raw as T;
}

export function optionalEnum<T extends string>(raw: unknown, field: string, allowed: readonly T[]): T | undefined {
  if (raw === undefined) return undefined;
  return enumValue(raw, field, allowed);
}

/** Absolute http(s) URL, or null when empty. */
export function nullableUrl(raw: unknown, field: string): string | null | undefined {
  const value = nullableString(raw, field, { max: 2048 });
  if (value === undefined || value === null) return value;
  let parsed: URL;
  try {
    parsed = new URL(value);
  } catch {
    throw badRequest(`${field} must be a valid URL.`);
  }
  if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
    throw badRequest(`${field} must be an http(s) URL.`);
  }
  return value;
}

// ---------------------------------------------------------------------------
// Numbers
// ---------------------------------------------------------------------------

function toNumber(raw: unknown, field: string): number {
  let value: number;
  if (typeof raw === 'number') {
    value = raw;
  } else if (typeof raw === 'string' && raw.trim() !== '' && /^-?\d+(\.\d+)?$/.test(raw.trim())) {
    value = Number(raw.trim());
  } else {
    throw badRequest(`${field} must be a number.`);
  }
  if (!Number.isFinite(value)) throw badRequest(`${field} must be a finite number.`);
  return value;
}

interface IntOptions {
  min: number;
  max: number;
}

export function requiredInt(raw: unknown, field: string, opts: IntOptions): number {
  if (raw === undefined || raw === null || raw === '') throw badRequest(`${field} is required.`);
  const value = toNumber(raw, field);
  if (!Number.isInteger(value)) throw badRequest(`${field} must be a whole number.`);
  if (value < opts.min || value > opts.max) {
    throw badRequest(`${field} must be between ${opts.min} and ${opts.max}.`);
  }
  return value;
}

export function optionalInt(raw: unknown, field: string, opts: IntOptions): number | undefined {
  if (raw === undefined) return undefined;
  return requiredInt(raw, field, opts);
}

const MAX_MONEY = 100_000_000; // 100 million in major units

/** Decimal money amount → integer cents. */
export function requiredMoney(raw: unknown, field: string): number {
  if (raw === undefined || raw === null || raw === '') throw badRequest(`${field} is required.`);
  const value = toNumber(raw, field);
  if (value < 0) throw badRequest(`${field} cannot be negative.`);
  if (value > MAX_MONEY) throw badRequest(`${field} is too large.`);
  return toCents(value);
}

export function optionalMoney(raw: unknown, field: string): number | undefined {
  if (raw === undefined) return undefined;
  return requiredMoney(raw, field);
}

/** undefined when absent, null when null/empty/0, otherwise cents. */
export function nullableMoney(raw: unknown, field: string): number | null | undefined {
  if (raw === undefined) return undefined;
  if (raw === null || raw === '' || raw === 0) return null;
  return requiredMoney(raw, field);
}

// ---------------------------------------------------------------------------
// Identifiers
// ---------------------------------------------------------------------------

export function isObjectIdString(value: unknown): value is string {
  return typeof value === 'string' && OBJECT_ID_RE.test(value);
}

export function objectId(raw: unknown, field = 'id'): ObjectId {
  if (raw === undefined || raw === null || raw === '') throw badRequest(`${field} is required.`);
  if (!isObjectIdString(raw)) throw badRequest(`Invalid ${field}.`);
  return new ObjectId(raw);
}

export function optionalObjectId(raw: unknown, field: string): ObjectId | undefined {
  if (raw === undefined || raw === null || raw === '') return undefined;
  return objectId(raw, field);
}

export function objectIdArray(raw: unknown, field: string, opts: { min: number; max: number }): ObjectId[] {
  if (!Array.isArray(raw)) throw badRequest(`${field} must be an array.`);
  if (raw.length < opts.min) throw badRequest(`${field} must contain at least ${opts.min} item(s).`);
  if (raw.length > opts.max) throw badRequest(`${field} can contain at most ${opts.max} items.`);
  const seen = new Set<string>();
  const ids: ObjectId[] = [];
  for (const item of raw) {
    const id = objectId(item, field);
    const key = id.toHexString();
    if (!seen.has(key)) {
      seen.add(key);
      ids.push(id);
    }
  }
  return ids;
}

/** Buyer storefront session id (client-generated, opaque). */
export function sessionId(raw: unknown): string {
  return requiredString(raw, 'sessionId', {
    min: 8,
    max: 128,
    pattern: /^[A-Za-z0-9_-]+$/,
    patternMessage: 'sessionId may only contain letters, numbers, "_" and "-".',
  });
}

// ---------------------------------------------------------------------------
// Objects
// ---------------------------------------------------------------------------

function hasUnsafeKeys(value: unknown, depth = 0): boolean {
  if (depth > 10) return true;
  if (Array.isArray(value)) return value.some((v) => hasUnsafeKeys(v, depth + 1));
  if (value !== null && typeof value === 'object') {
    return Object.entries(value as Record<string, unknown>).some(
      ([key, v]) => key.startsWith('$') || key.includes('.') || hasUnsafeKeys(v, depth + 1)
    );
  }
  return false;
}

/** A small JSON object (e.g. merchant settings). Keys may not start with "$" or contain ".". */
export function plainJsonObject(raw: unknown, field: string, maxBytes = 8_192): Record<string, unknown> {
  if (!isPlainObject(raw)) throw badRequest(`${field} must be a JSON object.`);
  const json = JSON.stringify(raw);
  if (Buffer.byteLength(json, 'utf8') > maxBytes) throw badRequest(`${field} is too large.`);
  if (hasUnsafeKeys(raw)) {
    throw badRequest(`${field} keys may not start with "$" or contain ".", and nesting is limited to 10 levels.`);
  }
  return JSON.parse(json) as Record<string, unknown>;
}

// ---------------------------------------------------------------------------
// Query string helpers (Express 5 "simple" query parser → string | string[])
// ---------------------------------------------------------------------------

export function queryString(req: Request, key: string, max = 200): string | undefined {
  const raw: unknown = (req.query as Record<string, unknown>)[key];
  if (raw === undefined) return undefined;
  if (typeof raw !== 'string') throw badRequest(`Query parameter "${key}" must be a single value.`);
  const value = raw.trim();
  if (value === '') return undefined;
  if (value.length > max) throw badRequest(`Query parameter "${key}" is too long.`);
  return value;
}

export interface Pagination {
  limit: number;
  offset: number;
}

export function pagination(req: Request, defaults: { limit: number; max: number }): Pagination {
  const limitRaw = queryString(req, 'limit', 10);
  const offsetRaw = queryString(req, 'offset', 12);
  const limit = limitRaw === undefined ? defaults.limit : requiredInt(limitRaw, 'limit', { min: 1, max: defaults.max });
  const offset = offsetRaw === undefined ? 0 : requiredInt(offsetRaw, 'offset', { min: 0, max: 1_000_000 });
  return { limit, offset };
}

/** Escapes user input for safe use inside a MongoDB $regex. */
export function escapeRegex(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}
