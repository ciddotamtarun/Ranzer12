import { MongoServerError } from 'mongodb';

/**
 * An error whose message is safe to show to API clients. Anything that is not
 * an HttpError is treated as an internal error and its message is hidden in
 * production.
 */
export class HttpError extends Error {
  readonly status: number;
  readonly code: string;
  readonly headers?: Record<string, string>;

  constructor(status: number, message: string, code?: string, headers?: Record<string, string>) {
    super(message);
    this.name = 'HttpError';
    this.status = status;
    this.code = code ?? defaultCode(status);
    this.headers = headers;
  }
}

function defaultCode(status: number): string {
  switch (status) {
    case 400: return 'BAD_REQUEST';
    case 401: return 'UNAUTHORIZED';
    case 403: return 'FORBIDDEN';
    case 404: return 'NOT_FOUND';
    case 409: return 'CONFLICT';
    case 413: return 'PAYLOAD_TOO_LARGE';
    case 422: return 'UNPROCESSABLE_ENTITY';
    case 429: return 'TOO_MANY_REQUESTS';
    case 503: return 'SERVICE_UNAVAILABLE';
    default: return status >= 500 ? 'INTERNAL_ERROR' : 'ERROR';
  }
}

export const badRequest = (message: string) => new HttpError(400, message);
export const unauthorized = (message = 'Authentication required.') => new HttpError(401, message);
export const forbidden = (message = 'You do not have permission to perform this action.') => new HttpError(403, message);
export const notFound = (message = 'Resource not found.') => new HttpError(404, message);
export const conflict = (message: string) => new HttpError(409, message);
export const unprocessable = (message: string) => new HttpError(422, message);

/** True for a MongoDB duplicate-key (unique index) violation. */
export function isDuplicateKeyError(err: unknown): err is MongoServerError {
  return err instanceof MongoServerError && err.code === 11000;
}

/** Name of the unique index that was violated, when the server reports it. */
export function duplicateKeyIndex(err: MongoServerError): string {
  const match = /index:\s+(\S+)/.exec(err.message);
  return match?.[1] ?? '';
}
