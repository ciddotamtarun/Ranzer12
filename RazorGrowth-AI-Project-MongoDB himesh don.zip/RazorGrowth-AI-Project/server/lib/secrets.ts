import crypto from 'node:crypto';

// One-time payment client secrets (the same idea as Stripe's PaymentIntent
// client_secret). The buyer who completed checkout receives the plaintext
// secret once; only its SHA-256 hash is stored. Presenting it later proves the
// caller is that buyer, without requiring a merchant login.

export function generateClientSecret(): { secret: string; hash: string } {
  const secret = `pay_secret_${crypto.randomBytes(24).toString('base64url')}`;
  return { secret, hash: hashSecret(secret) };
}

export function hashSecret(secret: string): string {
  return crypto.createHash('sha256').update(secret).digest('hex');
}

export function verifyClientSecret(secret: string, expectedHash: string | null): boolean {
  if (!expectedHash) return false;
  const actual = Buffer.from(hashSecret(secret), 'hex');
  const expected = Buffer.from(expectedHash, 'hex');
  return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
}

/** Pseudo gateway reference for the payment simulator. */
export function gatewayReference(prefix: 'gw_succ' | 'gw_err'): string {
  return `${prefix}_${crypto.randomBytes(5).toString('hex')}`;
}
