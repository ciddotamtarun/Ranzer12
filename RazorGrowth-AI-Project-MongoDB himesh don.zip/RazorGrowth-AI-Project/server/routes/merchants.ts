import { Router, type Request, type Response } from 'express';
import { getCollections } from '../db/mongo.js';
import { CURRENCIES, type MerchantDoc } from '../db/models.js';
import { authOf, requireAuth, requireRole } from '../middleware/auth.js';
import { clientIp, logAuditEvent } from '../middleware/audit.js';
import { badRequest, notFound } from '../lib/errors.js';
import { serializeMerchant, serializePublicMerchant } from '../lib/serialize.js';
import { optionalEnum, optionalString, plainJsonObject, readBody } from '../lib/validate.js';

const router = Router();

// GET /api/merchants/me
router.get('/me', requireAuth, async (req: Request, res: Response) => {
  const { merchantId } = authOf(req);
  const { merchants } = await getCollections();
  const merchant = await merchants.findOne({ _id: merchantId });
  if (!merchant) throw notFound('Merchant not found.');
  res.json({ merchant: serializeMerchant(merchant) });
});

// PUT /api/merchants/me — workspace settings (owner only)
router.put('/me', requireAuth, requireRole('owner'), async (req: Request, res: Response) => {
  const auth = authOf(req);
  const body = readBody(req);
  const update: Partial<Pick<MerchantDoc, 'name' | 'currency' | 'settings'>> = {};

  const name = optionalString(body.name, 'Name', { max: 120 });
  if (name !== undefined) update.name = name;
  const currency = optionalEnum(
    typeof body.currency === 'string' ? body.currency.trim().toUpperCase() : body.currency,
    'Currency',
    CURRENCIES
  );
  if (currency !== undefined) update.currency = currency;
  if (body.settings !== undefined) update.settings = plainJsonObject(body.settings, 'settings');

  if (Object.keys(update).length === 0) throw badRequest('Provide at least one of: name, currency, settings.');

  const { merchants } = await getCollections();
  const merchant = await merchants.findOneAndUpdate(
    { _id: auth.merchantId },
    { $set: { ...update, updatedAt: new Date() } },
    { returnDocument: 'after' }
  );
  if (!merchant) throw notFound('Merchant not found.');

  await logAuditEvent({
    merchantId: auth.merchantId,
    actorType: 'USER',
    actorId: auth.userId.toHexString(),
    actorEmail: auth.email,
    action: 'MERCHANT_SETTINGS_UPDATED',
    entityType: 'MERCHANT',
    entityId: auth.merchantId.toHexString(),
    details: `Merchant settings updated. Name: ${merchant.name}, Currency: ${merchant.currency}.`,
    ipAddress: clientIp(req),
  });

  res.json({ merchant: serializeMerchant(merchant) });
});

// GET /api/merchants/public/:slug — public storefront profile
router.get('/public/:slug', async (req: Request, res: Response) => {
  const slug = String(req.params.slug ?? '').toLowerCase();
  if (!/^[a-z0-9-]{1,80}$/.test(slug)) throw notFound('Merchant not found.');
  const { merchants } = await getCollections();
  const merchant = await merchants.findOne({ slug });
  if (!merchant) throw notFound('Merchant not found.');
  res.json({ merchant: serializePublicMerchant(merchant) });
});

export default router;
