import { Router, type Request, type Response } from 'express';
import crypto from 'node:crypto';
import { ObjectId, type Filter } from 'mongodb';
import { getCollections } from '../db/mongo.js';
import { PRODUCT_STATUSES, type ProductDoc } from '../db/models.js';
import { authOf, requireAuth } from '../middleware/auth.js';
import { clientIp, logAuditEvent } from '../middleware/audit.js';
import { badRequest, conflict, isDuplicateKeyError, notFound } from '../lib/errors.js';
import { formatMoney } from '../lib/money.js';
import { serializeProduct } from '../lib/serialize.js';
import {
  escapeRegex,
  nullableMoney,
  nullableString,
  nullableUrl,
  objectId,
  optionalEnum,
  optionalInt,
  optionalMoney,
  optionalString,
  pagination,
  queryString,
  readBody,
  requiredMoney,
  requiredString,
} from '../lib/validate.js';

const router = Router();
router.use(requireAuth);

export const DEFAULT_PRODUCT_IMAGE =
  'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&auto=format&fit=crop&q=80';

const MAX_INVENTORY = 1_000_000;

function generateSku(): string {
  return `SKU-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
}

function skuConflict(sku: string) {
  return conflict(`A product with SKU '${sku}' already exists in your catalog.`);
}

// GET /api/products?search=&category=&status=&limit=&offset=
router.get('/', async (req: Request, res: Response) => {
  const { merchantId } = authOf(req);
  const category = queryString(req, 'category', 100);
  const search = queryString(req, 'search', 100);
  const status = optionalEnum(queryString(req, 'status', 20), 'status', PRODUCT_STATUSES);
  const { limit, offset } = pagination(req, { limit: 200, max: 500 });

  const filter: Filter<ProductDoc> = { merchantId };
  if (category) filter.category = category;
  if (status) filter.status = status;
  if (search) {
    const regex = { $regex: escapeRegex(search), $options: 'i' };
    filter.$or = [{ title: regex }, { description: regex }, { sku: regex }];
  }

  const { products } = await getCollections();
  const [docs, total] = await Promise.all([
    products.find(filter).sort({ createdAt: -1, _id: -1 }).skip(offset).limit(limit).toArray(),
    products.countDocuments(filter),
  ]);

  res.json({ products: docs.map(serializeProduct), pagination: { total, limit, offset } });
});

// GET /api/products/:id
router.get('/:id', async (req: Request, res: Response) => {
  const { merchantId } = authOf(req);
  const id = objectId(req.params.id, 'product id');
  const { products } = await getCollections();
  const product = await products.findOne({ _id: id, merchantId });
  if (!product) throw notFound('Product not found.');
  res.json({ product: serializeProduct(product) });
});

// POST /api/products
router.post('/', async (req: Request, res: Response) => {
  const auth = authOf(req);
  const body = readBody(req);

  const now = new Date();
  const product: ProductDoc = {
    _id: new ObjectId(),
    merchantId: auth.merchantId,
    title: requiredString(body.title, 'Title', { max: 200 }),
    description: nullableString(body.description, 'Description', { max: 5_000 }) ?? '',
    priceCents: requiredMoney(body.price, 'Price'),
    compareAtPriceCents: nullableMoney(body.compare_at_price, 'Compare-at price') ?? null,
    category: optionalString(body.category, 'Category', { max: 100 }) ?? 'General',
    inventory: optionalInt(body.inventory, 'Inventory', { min: 0, max: MAX_INVENTORY }) ?? 0,
    sku: nullableString(body.sku, 'SKU', { max: 64 }) ?? generateSku(),
    imageUrl: nullableUrl(body.image_url, 'Image URL') ?? DEFAULT_PRODUCT_IMAGE,
    status: optionalEnum(body.status, 'Status', PRODUCT_STATUSES) ?? 'active',
    createdAt: now,
    updatedAt: now,
  };

  const { products } = await getCollections();
  try {
    await products.insertOne(product);
  } catch (err) {
    if (isDuplicateKeyError(err)) throw skuConflict(product.sku);
    throw err;
  }

  await logAuditEvent({
    merchantId: auth.merchantId,
    actorType: 'USER',
    actorId: auth.userId.toHexString(),
    actorEmail: auth.email,
    action: 'PRODUCT_CREATED',
    entityType: 'PRODUCT',
    entityId: product._id.toHexString(),
    details: `Product '${product.title}' created with price ${formatMoney(product.priceCents)} and stock ${product.inventory}.`,
    ipAddress: clientIp(req),
  });

  res.status(201).json({ product: serializeProduct(product) });
});

// PUT /api/products/:id — partial update (only provided fields change)
router.put('/:id', async (req: Request, res: Response) => {
  const auth = authOf(req);
  const id = objectId(req.params.id, 'product id');
  const body = readBody(req);

  const update: Partial<ProductDoc> = {};
  const title = optionalString(body.title, 'Title', { max: 200 });
  if (title !== undefined) update.title = title;
  const description = nullableString(body.description, 'Description', { max: 5_000 });
  if (description !== undefined) update.description = description ?? '';
  const price = optionalMoney(body.price, 'Price');
  if (price !== undefined) update.priceCents = price;
  const compareAt = nullableMoney(body.compare_at_price, 'Compare-at price');
  if (compareAt !== undefined) update.compareAtPriceCents = compareAt;
  const category = optionalString(body.category, 'Category', { max: 100 });
  if (category !== undefined) update.category = category;
  const inventory = optionalInt(body.inventory, 'Inventory', { min: 0, max: MAX_INVENTORY });
  if (inventory !== undefined) update.inventory = inventory;
  // An empty SKU in the edit form means "keep the current SKU".
  const sku = nullableString(body.sku, 'SKU', { max: 64 });
  if (sku) update.sku = sku;
  const imageUrl = nullableUrl(body.image_url, 'Image URL');
  if (imageUrl !== undefined) update.imageUrl = imageUrl ?? DEFAULT_PRODUCT_IMAGE;
  const status = optionalEnum(body.status, 'Status', PRODUCT_STATUSES);
  if (status !== undefined) update.status = status;

  if (Object.keys(update).length === 0) throw badRequest('No product fields to update were provided.');

  const { products } = await getCollections();
  // Friendly 409 up front; the unique index still guards against races.
  if (update.sku && (await products.findOne({ merchantId: auth.merchantId, sku: update.sku, _id: { $ne: id } }, { projection: { _id: 1 } }))) {
    throw skuConflict(update.sku);
  }
  let product: ProductDoc | null;
  try {
    product = await products.findOneAndUpdate(
      { _id: id, merchantId: auth.merchantId },
      { $set: { ...update, updatedAt: new Date() } },
      { returnDocument: 'after' }
    );
  } catch (err) {
    if (isDuplicateKeyError(err) && update.sku) throw skuConflict(update.sku);
    throw err;
  }
  if (!product) throw notFound('Product not found.');

  await logAuditEvent({
    merchantId: auth.merchantId,
    actorType: 'USER',
    actorId: auth.userId.toHexString(),
    actorEmail: auth.email,
    action: 'PRODUCT_UPDATED',
    entityType: 'PRODUCT',
    entityId: id.toHexString(),
    details: `Product '${product.title}' updated. Price: ${formatMoney(product.priceCents)}, Inventory: ${product.inventory}.`,
    ipAddress: clientIp(req),
  });

  res.json({ product: serializeProduct(product) });
});

// DELETE /api/products/:id
router.delete('/:id', async (req: Request, res: Response) => {
  const auth = authOf(req);
  const id = objectId(req.params.id, 'product id');
  const { products, carts } = await getCollections();

  const deleted = await products.findOneAndDelete({ _id: id, merchantId: auth.merchantId });
  if (!deleted) throw notFound('Product not found.');

  // Past orders keep their item snapshot; open storefront carts drop the item.
  await carts.updateMany(
    { merchantId: auth.merchantId, 'items.productId': id },
    { $pull: { items: { productId: id } }, $set: { updatedAt: new Date() } }
  );

  await logAuditEvent({
    merchantId: auth.merchantId,
    actorType: 'USER',
    actorId: auth.userId.toHexString(),
    actorEmail: auth.email,
    action: 'PRODUCT_DELETED',
    entityType: 'PRODUCT',
    entityId: id.toHexString(),
    details: `Product '${deleted.title}' (SKU ${deleted.sku}) deleted from catalog.`,
    ipAddress: clientIp(req),
  });

  res.json({ message: 'Product deleted successfully.' });
});

export default router;
