import { Router, type Request, type Response } from 'express';
import { getCollections } from '../db/mongo.js';
import { APPROVAL_STATUSES } from '../db/models.js';
import { authOf, requireAuth, requireRole } from '../middleware/auth.js';
import { clientIp, logAuditEvent } from '../middleware/audit.js';
import { conflict, notFound } from '../lib/errors.js';
import { serializeAgentTask, serializeApproval } from '../lib/serialize.js';
import { enumValue, objectId, optionalEnum, optionalString, pagination, queryString, readBody } from '../lib/validate.js';

const router = Router();
router.use(requireAuth);

// GET /api/approvals?status=
router.get('/', async (req: Request, res: Response) => {
  const { merchantId } = authOf(req);
  const status = optionalEnum(queryString(req, 'status', 20), 'status', APPROVAL_STATUSES);
  const { limit, offset } = pagination(req, { limit: 200, max: 500 });
  const { approvals, agentTasks } = await getCollections();

  const docs = await approvals
    .find(status ? { merchantId, status } : { merchantId })
    .sort({ createdAt: -1, _id: -1 })
    .skip(offset)
    .limit(limit)
    .toArray();
  const tasks = docs.length
    ? await agentTasks.find({ merchantId, _id: { $in: docs.map((a) => a.agentTaskId) } }).toArray()
    : [];
  const taskById = new Map(tasks.map((t) => [t._id.toHexString(), t]));

  res.json({ approvals: docs.map((a) => serializeApproval(a, taskById.get(a.agentTaskId.toHexString()))) });
});

// POST /api/approvals/:id/decide  { decision: 'APPROVE' | 'REJECT', notes? }
// Human-in-the-loop gate: only the workspace owner can decide, and a decision
// is final (the PENDING → APPROVED/REJECTED transition is atomic).
router.post('/:id/decide', requireRole('owner'), async (req: Request, res: Response) => {
  const auth = authOf(req);
  const id = objectId(req.params.id, 'approval id');
  const body = readBody(req);
  const decision = enumValue(body.decision, 'decision', ['APPROVE', 'REJECT'] as const);
  const notes = optionalString(body.notes, 'notes', { min: 0, max: 1_000 }) || null;

  const { approvals, agentTasks, aiInsights } = await getCollections();
  const now = new Date();
  const approved = decision === 'APPROVE';

  const approval = await approvals.findOneAndUpdate(
    { _id: id, merchantId: auth.merchantId, status: 'PENDING' },
    { $set: { status: approved ? 'APPROVED' : 'REJECTED', resolvedBy: auth.email, resolvedAt: now, notes, updatedAt: now } },
    { returnDocument: 'after' }
  );
  if (!approval) {
    const existing = await approvals.findOne({ _id: id, merchantId: auth.merchantId }, { projection: { status: 1 } });
    if (!existing) throw notFound('Approval request not found.');
    throw conflict(`This approval has already been ${existing.status.toLowerCase()} and cannot be decided again.`);
  }

  const task = await agentTasks.findOne({ _id: approval.agentTaskId, merchantId: auth.merchantId });
  if (!task) throw notFound('The agent task for this approval no longer exists.');

  const executionResult = approved
    ? `Execution successful: Applied ${task.proposedAction} Monitored baseline improvements active. Measurement: ${task.impactMetric || 'Active'}.`
    : `Action rejected by merchant administrator (${auth.email}).${notes ? ` Reason: ${notes}` : ''}`;

  const updatedTask =
    (await agentTasks.findOneAndUpdate(
      { _id: task._id, merchantId: auth.merchantId },
      { $set: { status: approved ? 'COMPLETED' : 'REJECTED', executionResult, updatedAt: now } },
      { returnDocument: 'after' }
    )) ?? task;

  // The insight that spawned this task (if any) is actioned or dismissed.
  if (task.insightId) {
    await aiInsights.updateOne(
      { _id: task.insightId, merchantId: auth.merchantId, status: 'ACTIVE' },
      { $set: { status: approved ? 'ACTIONED' : 'DISMISSED', updatedAt: now } }
    );
  }

  await logAuditEvent({
    merchantId: auth.merchantId,
    actorType: 'USER',
    actorId: auth.userId.toHexString(),
    actorEmail: auth.email,
    action: approved ? 'APPROVAL_GRANTED' : 'APPROVAL_REJECTED',
    entityType: 'APPROVAL',
    entityId: id.toHexString(),
    details: approved
      ? `Merchant approved agent action '${approval.title}'. Notes: ${notes || 'None provided'}.`
      : `Merchant rejected agent action '${approval.title}'. Reason: ${notes || 'Declined by admin'}.`,
    ipAddress: clientIp(req),
  });

  if (approved) {
    await logAuditEvent({
      merchantId: auth.merchantId,
      actorType: 'AGENT',
      actorId: task._id.toHexString(),
      actorEmail: 'agent@razorgrowth.ai',
      action: 'AGENT_ACTION_EXECUTED',
      entityType: 'AGENT_TASK',
      entityId: task._id.toHexString(),
      details: `Autonomous Agent executed action for '${task.title}'. Status: COMPLETED. Result: ${executionResult}`,
      ipAddress: clientIp(req),
    });
  }

  res.json({
    success: true,
    decision: approved ? 'APPROVED' : 'REJECTED',
    message: approved ? 'Agent action authorized and executed successfully.' : 'Agent action was rejected and halted.',
    approval: serializeApproval(approval, updatedTask),
    agentTask: serializeAgentTask(updatedTask, approval),
  });
});

export default router;
