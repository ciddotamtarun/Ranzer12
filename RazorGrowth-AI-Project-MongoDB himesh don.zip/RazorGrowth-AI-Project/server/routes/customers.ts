import { Router, type Request, type Response } from 'express';
import { ObjectId, type Filter } from 'mongodb';
import { getCollections } from '../db/mongo.js';
import { CUSTOMER_STATUSES, type CustomerDoc } from '../db/models.js';
import { authOf, requireAuth } from '../middleware/auth.js';
import { clientIp, logAuditEvent } from '../middleware/audit.js';
import { badRequest, conflict, isDuplicateKeyError, notFound } from '../lib/errors.js';
import { serializeCustomer } from '../lib/serialize.js';
import {
  escapeRegex,
  nullableString,
  objectId,
  optionalEmail,
  optionalEnum,
  optionalString,
  pagination,
  queryString,
  readBody,
  requiredEmail,
  requiredString,
} from '../lib/validate.js';

const router = Router();
router.use(requireAuth);

const emailConflict = () => conflict('A customer with this email already exists.');

// GET /api/customers?search=&status=&limit=&offset=
router.get('/', async (req: Request, res: Response) => {
  const { merchantId } = authOf(req);
  const search = queryString(req, 'search', 100);
  const status = optionalEnum(queryString(req, 'status', 20), 'status', CUSTOMER_STATUSES);
  const { limit, offset } = pagination(req, { limit: 200, max: 500 });

  const filter: Filter<CustomerDoc> = { merchantId };
  if (status) filter.status = status;
  if (search) {
    const regex = { $regex: escapeRegex(search), $options: 'i' };
    filter.$or = [{ name: regex }, { email: regex }, { phone: regex }];
  }

  const { customers } = await getCollections();
  const [docs, total] = await Promise.all([
    customers.find(filter).sort({ createdAt: -1, _id: -1 }).skip(offset).limit(limit).toArray(),
    customers.countDocuments(filter),
  ]);
  res.json({ customers: docs.map(serializeCustomer), pagination: { total, limit, offset } });
});

// GET /api/customers/:id
router.get('/:id', async (req: Request, res: Response) => {
  const { merchantId } = authOf(req);
  const id = objectId(req.params.id, 'customer id');
  const { customers } = await getCollections();
  const customer = await customers.findOne({ _id: id, merchantId });
  if (!customer) throw notFound('Customer not found.');
  res.json({ customer: serializeCustomer(customer) });
});

// POST /api/customers
router.post('/', async (req: Request, res: Response) => {
  const auth = authOf(req);
  const body = readBody(req);
  const now = new Date();
  const customer: CustomerDoc = {
    _id: new ObjectId(),
    merchantId: auth.merchantId,
    name: requiredString(body.name, 'Customer name', { max: 120 }),
    email: requiredEmail(body.email, 'Customer email'),
    phone: nullableString(body.phone, 'Phone', { max: 40 }) ?? null,
    totalSpentCents: 0,
    ordersCount: 0,
    status: optionalEnum(body.status, 'Status', CUSTOMER_STATUSES) ?? 'active',
    createdAt: now,
    updatedAt: now,
  };

  const { customers } = await getCollections();
  try {
    await customers.insertOne(customer);
  } catch (err) {
    if (isDuplicateKeyError(err)) throw emailConflict();
    throw err;
  }

  await logAuditEvent({
    merchantId: auth.merchantId,
    actorType: 'USER',
    actorId: auth.userId.toHexString(),
    actorEmail: auth.email,
    action: 'CUSTOMER_CREATED',
    entityType: 'CUSTOMER',
    entityId: customer._id.toHexString(),
    details: `Customer '${customer.name}' (${customer.email}) created.`,
    ipAddress: clientIp(req),
  });

  res.status(201).json({ customer: serializeCustomer(customer) });
});

// PUT /api/customers/:id — partial update
router.put('/:id', async (req: Request, res: Response) => {
  const auth = authOf(req);
  const id = objectId(req.params.id, 'customer id');
  const body = readBody(req);

  const update: Partial<CustomerDoc> = {};
  const name = optionalString(body.name, 'Customer name', { max: 120 });
  if (name !== undefined) update.name = name;
  const email = optionalEmail(body.email, 'Customer email');
  if (email !== undefined) update.email = email;
  const phone = nullableString(body.phone, 'Phone', { max: 40 });
  if (phone !== undefined) update.phone = phone;
  const status = optionalEnum(body.status, 'Status', CUSTOMER_STATUSES);
  if (status !== undefined) update.status = status;

  if (Object.keys(update).length === 0) throw badRequest('No customer fields to update were provided.');

  const { customers } = await getCollections();
  // Friendly 409 up front; the unique index still guards against races.
  if (update.email && (await customers.findOne({ merchantId: auth.merchantId, email: update.email, _id: { $ne: id } }, { projection: { _id: 1 } }))) {
    throw emailConflict();
  }
  let customer: CustomerDoc | null;
  try {
    customer = await customers.findOneAndUpdate(
      { _id: id, merchantId: auth.merchantId },
      { $set: { ...update, updatedAt: new Date() } },
      { returnDocument: 'after' }
    );
  } catch (err) {
    if (isDuplicateKeyError(err)) throw emailConflict();
    throw err;
  }
  if (!customer) throw notFound('Customer not found.');

  await logAuditEvent({
    merchantId: auth.merchantId,
    actorType: 'USER',
    actorId: auth.userId.toHexString(),
    actorEmail: auth.email,
    action: 'CUSTOMER_UPDATED',
    entityType: 'CUSTOMER',
    entityId: id.toHexString(),
    details: `Customer '${customer.name}' (${customer.email}) updated.`,
    ipAddress: clientIp(req),
  });

  res.json({ customer: serializeCustomer(customer) });
});

// DELETE /api/customers/:id
router.delete('/:id', async (req: Request, res: Response) => {
  const auth = authOf(req);
  const id = objectId(req.params.id, 'customer id');
  const { customers, orders } = await getCollections();

  const deleted = await customers.findOneAndDelete({ _id: id, merchantId: auth.merchantId });
  if (!deleted) throw notFound('Customer not found.');

  // Orders keep the customer's name/email snapshot but lose the link.
  await orders.updateMany({ merchantId: auth.merchantId, customerId: id }, { $set: { customerId: null } });

  await logAuditEvent({
    merchantId: auth.merchantId,
    actorType: 'USER',
    actorId: auth.userId.toHexString(),
    actorEmail: auth.email,
    action: 'CUSTOMER_DELETED',
    entityType: 'CUSTOMER',
    entityId: id.toHexString(),
    details: `Customer '${deleted.name}' (${deleted.email}) deleted.`,
    ipAddress: clientIp(req),
  });

  res.json({ message: 'Customer deleted successfully.' });
});

export default router;
