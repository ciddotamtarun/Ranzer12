import { Router, type Request, type Response } from 'express';
import { getCollections } from '../db/mongo.js';
import type { PaymentDoc } from '../db/models.js';
import { authOf, optionalAuth, requireAuth } from '../middleware/auth.js';
import { clientIp } from '../middleware/audit.js';
import { badRequest, conflict, notFound, unauthorized } from '../lib/errors.js';
import { rateLimit } from '../lib/rateLimit.js';
import { verifyClientSecret } from '../lib/secrets.js';
import { serializeOrder, serializePayment, serializeTransaction } from '../lib/serialize.js';
import { enumValue, objectId, optionalObjectId, optionalString, readBody } from '../lib/validate.js';
import { newPaymentDoc, recordPaymentFailure, recordPaymentSuccess, type PaymentActor } from '../services/payments.js';

const router = Router();

// POST /api/payments/create — merchant initialises (or reuses) a payment for one of its orders.
router.post('/create', requireAuth, async (req: Request, res: Response) => {
  const auth = authOf(req);
  const body = readBody(req);
  const orderId = objectId(body.orderId, 'orderId');
  const method = optionalString(body.method, 'method', { max: 50 }) ?? 'card';

  const { orders, payments } = await getCollections();
  const order = await orders.findOne({ _id: orderId, merchantId: auth.merchantId });
  if (!order) throw notFound('Order not found.');
  if (order.status === 'PAID') throw conflict('This order has already been paid.');
  if (order.status === 'CANCELLED') throw conflict('This order has been cancelled.');

  let payment = await payments.find({ orderId }).sort({ createdAt: -1 }).limit(1).next();
  if (!payment || payment.status === 'SUCCESS') {
    payment = newPaymentDoc(order, method, null);
    await payments.insertOne(payment);
  }

  res.json({ payment: serializePayment(payment), order: serializeOrder(order) });
});

// POST /api/payments/simulate — clearly-labelled payment simulator.
//
// Authorisation (previously missing — anyone could mark any order as PAID):
//  - a signed-in merchant may settle its own orders, or
//  - the storefront buyer may settle the order they just placed by presenting
//    the one-time `clientSecret` returned from /api/buyer/checkout.
router.post(
  '/simulate',
  optionalAuth,
  rateLimit({ name: 'payment-simulate', limit: 120, windowSeconds: 600 }),
  async (req: Request, res: Response) => {
    const body = readBody(req);
    const outcome = enumValue(body.outcome, 'outcome', ['SUCCESS', 'FAILURE'] as const);
    const paymentIdParam = optionalObjectId(body.paymentId, 'paymentId');
    const orderIdParam = optionalObjectId(body.orderId, 'orderId');
    if (!paymentIdParam && !orderIdParam) throw badRequest('Either paymentId or orderId is required.');
    const clientSecret = optionalString(body.clientSecret, 'clientSecret', { max: 200 });
    const failureReason =
      optionalString(body.failureReason, 'failureReason', { max: 300 }) ?? 'Card issuer declined: 3D Secure verification timeout';
    const paymentMethod = optionalString(body.paymentMethod, 'paymentMethod', { max: 100 }) ?? 'Visa ending in 4242';

    if (!req.auth && !clientSecret) {
      throw unauthorized('Sign in as the merchant, or provide the payment clientSecret returned at checkout.');
    }

    const cols = await getCollections();
    let payment: PaymentDoc | null = paymentIdParam
      ? await cols.payments.findOne({ _id: paymentIdParam })
      : await cols.payments.find({ orderId: orderIdParam }).sort({ createdAt: -1 }).limit(1).next();
    if (paymentIdParam && !payment) throw notFound('Payment not found.');
    if (payment && orderIdParam && !payment.orderId.equals(orderIdParam)) {
      throw badRequest('paymentId does not belong to the given orderId.');
    }

    const orderId = payment ? payment.orderId : orderIdParam!;
    const order = await cols.orders.findOne({ _id: orderId });

    const merchantAuthorized = Boolean(order && req.auth && req.auth.merchantId.equals(order.merchantId));
    const buyerAuthorized = Boolean(order && payment && clientSecret && verifyClientSecret(clientSecret, payment.clientSecretHash));
    // Same response for "missing" and "not yours" so order IDs can't be probed.
    if (!order || (!merchantAuthorized && !buyerAuthorized)) throw notFound('Order not found.');

    if (order.status === 'PAID') throw conflict('This order has already been paid.');
    if (order.status === 'CANCELLED') throw conflict('This order has been cancelled and cannot be paid.');

    if (!payment || payment.status === 'SUCCESS') {
      payment = newPaymentDoc(order, paymentMethod, null);
      await cols.payments.insertOne(payment);
    }

    const actor: PaymentActor =
      merchantAuthorized && req.auth
        ? { type: 'USER', id: req.auth.userId.toHexString(), email: req.auth.email, ip: clientIp(req) }
        : { type: 'BUYER', id: null, email: order.customerEmail, ip: clientIp(req) };

    const result =
      outcome === 'FAILURE'
        ? await recordPaymentFailure(cols, order, payment, { failureReason, paymentMethod, actor })
        : await recordPaymentSuccess(cols, order, payment, { paymentMethod, actor });

    res.json({
      success: result.success,
      status: result.status,
      message: result.message,
      order: serializeOrder(result.order),
      payment: serializePayment(result.payment),
      transaction: serializeTransaction(result.transaction),
    });
  }
);

export default router;
