import { Router, type Request, type Response } from 'express';
import { ObjectId } from 'mongodb';
import { getCollections } from '../db/mongo.js';
import type { CartDoc, CartItemDoc } from '../db/models.js';
import { badRequest, conflict, notFound } from '../lib/errors.js';
import { rateLimit } from '../lib/rateLimit.js';
import { serializeCartItem } from '../lib/serialize.js';
import { objectId, optionalInt, queryString, readBody, requiredInt, sessionId as parseSessionId } from '../lib/validate.js';

// Public, session-scoped storefront cart. A cart is identified by
// (merchantId, sessionId); the sessionId is an opaque random value generated
// by the buyer's browser. Idle carts expire via a TTL index after 30 days.
const router = Router();

const MAX_CART_LINES = 100;
const MAX_QUANTITY = 1_000;

const cartWriteLimit = rateLimit({ name: 'cart-write', limit: 300, windowSeconds: 600 });

function cartResponse(items: CartItemDoc[], message?: string) {
  const serialized = items.map(serializeCartItem);
  return { items: serialized, cart: { items: serialized }, ...(message ? { message } : {}) };
}

function scopeFromQuery(req: Request) {
  return {
    merchantId: objectId(queryString(req, 'merchantId', 24), 'merchantId'),
    sessionId: parseSessionId(queryString(req, 'sessionId', 128)),
  };
}

async function saveCart(merchantId: ObjectId, sessionId: string, items: CartItemDoc[]): Promise<void> {
  const { carts } = await getCollections();
  const now = new Date();
  await carts.updateOne(
    { merchantId, sessionId },
    { $set: { items, updatedAt: now }, $setOnInsert: { _id: new ObjectId(), createdAt: now } },
    { upsert: true }
  );
}

async function loadCart(merchantId: ObjectId, sessionId: string): Promise<CartDoc | null> {
  const { carts } = await getCollections();
  return carts.findOne({ merchantId, sessionId });
}

// GET /api/cart?merchantId=&sessionId=
router.get('/', async (req: Request, res: Response) => {
  const { merchantId, sessionId } = scopeFromQuery(req);
  const cart = await loadCart(merchantId, sessionId);
  res.json(cartResponse(cart?.items ?? []));
});

// POST /api/cart/items  { merchantId, sessionId, productId, quantity? }
router.post('/items', cartWriteLimit, async (req: Request, res: Response) => {
  const body = readBody(req);
  const merchantId = objectId(body.merchantId, 'merchantId');
  const sessionId = parseSessionId(body.sessionId);
  const productId = objectId(body.productId, 'productId');
  const quantity = optionalInt(body.quantity, 'quantity', { min: 1, max: MAX_QUANTITY }) ?? 1;

  const { products } = await getCollections();
  const product = await products.findOne({ _id: productId, merchantId, status: 'active' });
  if (!product) throw notFound('Product not found in merchant catalog.');

  const cart = await loadCart(merchantId, sessionId);
  const items = cart?.items ?? [];
  const existing = items.find((i) => i.productId.equals(productId));
  const newQuantity = (existing?.quantity ?? 0) + quantity;

  if (newQuantity > product.inventory) {
    throw conflict(`Insufficient inventory. Only ${product.inventory} available in stock.`);
  }
  if (newQuantity > MAX_QUANTITY) throw badRequest(`Quantity cannot exceed ${MAX_QUANTITY}.`);

  if (existing) {
    existing.quantity = newQuantity;
    // Refresh the snapshot so the cart always reflects current catalog data.
    existing.priceCents = product.priceCents;
    existing.title = product.title;
    existing.imageUrl = product.imageUrl;
    existing.sku = product.sku;
  } else {
    if (items.length >= MAX_CART_LINES) throw badRequest(`A cart can hold at most ${MAX_CART_LINES} different products.`);
    items.push({
      productId: product._id,
      title: product.title,
      priceCents: product.priceCents,
      imageUrl: product.imageUrl,
      quantity,
      sku: product.sku,
    });
  }

  await saveCart(merchantId, sessionId, items);
  res.json(cartResponse(items, 'Item added to cart.'));
});

// PUT /api/cart/items/:productId  { merchantId, sessionId, quantity } — quantity 0 removes the line
router.put('/items/:productId', cartWriteLimit, async (req: Request, res: Response) => {
  const productId = objectId(req.params.productId, 'productId');
  const body = readBody(req);
  const merchantId = objectId(body.merchantId, 'merchantId');
  const sessionId = parseSessionId(body.sessionId);
  const quantity = requiredInt(body.quantity, 'quantity', { min: 0, max: MAX_QUANTITY });

  const cart = await loadCart(merchantId, sessionId);
  if (!cart) throw notFound('Cart not found.');
  const existing = cart.items.find((i) => i.productId.equals(productId));
  if (!existing) throw notFound('Item is not in the cart.');

  let items = cart.items;
  if (quantity === 0) {
    items = items.filter((i) => !i.productId.equals(productId));
  } else {
    const { products } = await getCollections();
    const product = await products.findOne({ _id: productId, merchantId, status: 'active' });
    if (!product) throw notFound('Product is no longer available.');
    if (quantity > product.inventory) {
      throw conflict(`Insufficient inventory. Only ${product.inventory} available in stock.`);
    }
    existing.quantity = quantity;
    existing.priceCents = product.priceCents;
  }

  await saveCart(merchantId, sessionId, items);
  res.json(cartResponse(items));
});

// DELETE /api/cart/items/:productId?merchantId=&sessionId=
router.delete('/items/:productId', cartWriteLimit, async (req: Request, res: Response) => {
  const productId = objectId(req.params.productId, 'productId');
  const { merchantId, sessionId } = scopeFromQuery(req);
  const cart = await loadCart(merchantId, sessionId);
  if (!cart) {
    res.json(cartResponse([], 'Item removed from cart.'));
    return;
  }
  const items = cart.items.filter((i) => !i.productId.equals(productId));
  await saveCart(merchantId, sessionId, items);
  res.json(cartResponse(items, 'Item removed from cart.'));
});

// DELETE /api/cart?merchantId=&sessionId=
router.delete('/', cartWriteLimit, async (req: Request, res: Response) => {
  const { merchantId, sessionId } = scopeFromQuery(req);
  const { carts } = await getCollections();
  await carts.deleteOne({ merchantId, sessionId });
  res.json(cartResponse([], 'Cart cleared.'));
});

export default router;
