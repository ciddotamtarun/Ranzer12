import { Router, type Request, type Response } from 'express';
import bcrypt from 'bcryptjs';
import { ObjectId } from 'mongodb';
import { getCollections } from '../db/mongo.js';
import { CURRENCIES, type MerchantDoc, type UserDoc } from '../db/models.js';
import { authOf, getJwtSecret, requireAuth, signAuthToken } from '../middleware/auth.js';
import { clientIp, logAuditEvent } from '../middleware/audit.js';
import { badRequest, conflict, duplicateKeyIndex, isDuplicateKeyError, unauthorized } from '../lib/errors.js';
import { consumeRateLimit, peekRateLimit, rateLimit, tooManyRequests } from '../lib/rateLimit.js';
import { isRateLimitEnabled } from '../config.js';
import { serializeMerchant, serializeUser } from '../lib/serialize.js';
import { enumValue, readBody, requiredEmail, requiredString } from '../lib/validate.js';

const router = Router();

const BCRYPT_ROUNDS = 12;
const PASSWORD_MIN_LENGTH = 8;
const PASSWORD_MAX_BYTES = 72; // bcrypt ignores anything beyond 72 bytes

function validateNewPassword(raw: unknown): string {
  if (typeof raw !== 'string' || raw.length === 0) throw badRequest('Password is required.');
  if (raw.length < PASSWORD_MIN_LENGTH) throw badRequest('Password must be at least 8 characters long.');
  if (Buffer.byteLength(raw, 'utf8') > PASSWORD_MAX_BYTES) throw badRequest('Password must be at most 72 bytes long.');
  return raw;
}

function slugify(name: string): string {
  const slug = name
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 60);
  return slug || 'merchant';
}

// Comparing against a real hash when the account does not exist keeps login
// timing identical for unknown and known emails (prevents user enumeration).
let timingHash: Promise<string> | null = null;
function getTimingHash(): Promise<string> {
  timingHash ??= bcrypt.hash('razorgrowth-timing-equalizer', BCRYPT_ROUNDS);
  return timingHash;
}


// POST /api/auth/signup
router.post(
  '/signup',
  rateLimit({ name: 'signup', limit: 20, windowSeconds: 3600, message: 'Too many sign-up attempts from this network. Please try again later.' }),
  async (req: Request, res: Response) => {
    getJwtSecret(); // fail on a misconfigured deployment before writing anything
    const body = readBody(req);
    const name = requiredString(body.name, 'Name', { max: 120 });
    const email = requiredEmail(body.email);
    const password = validateNewPassword(body.password);
    const merchantName = requiredString(body.merchantName, 'Merchant name', { max: 120 });
    const currency = body.currency === undefined ? 'USD' : enumValue(body.currency, 'Currency', CURRENCIES);

    const { users, merchants } = await getCollections();

    if (await users.findOne({ email }, { projection: { _id: 1 } })) {
      throw conflict('A user with this email already exists.');
    }

    const passwordHash = await bcrypt.hash(password, BCRYPT_ROUNDS);
    const now = new Date();
    const baseSlug = slugify(merchantName);

    const merchant: MerchantDoc = {
      _id: new ObjectId(),
      name: merchantName,
      slug: baseSlug,
      email,
      currency,
      settings: {},
      createdAt: now,
      updatedAt: now,
    };

    // The unique index on slug is the source of truth; retry with a numeric
    // suffix if the name is taken (also safe under concurrent sign-ups).
    for (let attempt = 0; ; attempt++) {
      try {
        await merchants.insertOne(merchant);
        break;
      } catch (err) {
        if (!isDuplicateKeyError(err) || attempt >= 5) throw err;
        const taken = await merchants.countDocuments({ slug: { $regex: `^${baseSlug}(-\\d+)?$` } });
        merchant.slug = attempt < 4 ? `${baseSlug}-${taken + attempt}` : `${baseSlug}-${new ObjectId().toHexString().slice(-6)}`;
      }
    }

    const user: UserDoc = {
      _id: new ObjectId(),
      merchantId: merchant._id,
      name,
      email,
      passwordHash,
      role: 'owner',
      lastLoginAt: now,
      createdAt: now,
      updatedAt: now,
    };

    try {
      await users.insertOne(user);
    } catch (err) {
      // Roll back the merchant so a failed sign-up leaves no orphan workspace.
      await merchants.deleteOne({ _id: merchant._id }).catch(() => undefined);
      if (isDuplicateKeyError(err) && duplicateKeyIndex(err).includes('email')) {
        throw conflict('A user with this email already exists.');
      }
      throw err;
    }

    await logAuditEvent({
      merchantId: merchant._id,
      actorType: 'USER',
      actorId: user._id.toHexString(),
      actorEmail: email,
      action: 'MERCHANT_SIGNUP',
      entityType: 'MERCHANT',
      entityId: merchant._id.toHexString(),
      details: `New merchant workspace '${merchantName}' created by ${name} (${email}).`,
      ipAddress: clientIp(req),
    });

    res.status(201).json({
      token: signAuthToken(user),
      user: serializeUser(user),
      merchant: serializeMerchant(merchant),
    });
  }
);

// Brute-force protection per account: after 10 failed passwords in a
// 15-minute window the account is temporarily throttled, from any IP.
// Only failures count, so a legitimate user is never throttled by success.
const FAILED_LOGIN_LIMIT = 10;
const FAILED_LOGIN_WINDOW_SECONDS = 900;
const failedLoginKey = (email: string) => `login-failed|${email}`;

async function recordFailedLogin(email: string): Promise<void> {
  if (!isRateLimitEnabled()) return;
  await consumeRateLimit(failedLoginKey(email), FAILED_LOGIN_LIMIT, FAILED_LOGIN_WINDOW_SECONDS).catch((err: unknown) => {
    console.error('[RateLimit] failed-login counter error:', err instanceof Error ? err.message : err);
  });
}

// POST /api/auth/login
router.post(
  '/login',
  rateLimit({ name: 'login-ip', limit: 50, windowSeconds: 900, message: 'Too many login attempts. Please wait a few minutes and try again.' }),
  async (req: Request, res: Response) => {
    getJwtSecret(); // fail on a misconfigured deployment before touching the account
    const body = readBody(req);
    if (typeof body.email !== 'string' || !body.email.trim() || typeof body.password !== 'string' || !body.password) {
      throw badRequest('Email and password are required.');
    }
    const email = body.email.trim().toLowerCase();
    const password = body.password;
    if (email.length > 254 || Buffer.byteLength(password, 'utf8') > 1024) {
      throw unauthorized('Invalid email or password.');
    }

    if (isRateLimitEnabled()) {
      const status = await peekRateLimit(failedLoginKey(email), FAILED_LOGIN_LIMIT, FAILED_LOGIN_WINDOW_SECONDS);
      if (!status.allowed) {
        throw tooManyRequests(status.retryAfterSeconds, 'Too many failed login attempts for this account. Please wait a few minutes and try again.');
      }
    }

    const { users, merchants } = await getCollections();
    const user = await users.findOne({ email });

    if (!user) {
      await bcrypt.compare(password, await getTimingHash());
      await recordFailedLogin(email);
      throw unauthorized('Invalid email or password.');
    }

    if (!(await bcrypt.compare(password, user.passwordHash))) {
      await recordFailedLogin(email);
      await logAuditEvent({
        merchantId: user.merchantId,
        actorType: 'USER',
        actorId: user._id.toHexString(),
        actorEmail: user.email,
        action: 'USER_LOGIN_FAILED',
        entityType: 'USER',
        entityId: user._id.toHexString(),
        details: `Failed login attempt for ${user.email}.`,
        ipAddress: clientIp(req),
      });
      throw unauthorized('Invalid email or password.');
    }

    const merchant = await merchants.findOne({ _id: user.merchantId });
    if (!merchant) {
      throw unauthorized('This account is no longer linked to a merchant workspace.');
    }

    const now = new Date();
    await users.updateOne({ _id: user._id }, { $set: { lastLoginAt: now } });

    await logAuditEvent({
      merchantId: user.merchantId,
      actorType: 'USER',
      actorId: user._id.toHexString(),
      actorEmail: user.email,
      action: 'USER_LOGIN',
      entityType: 'USER',
      entityId: user._id.toHexString(),
      details: `User ${user.name} logged in successfully.`,
      ipAddress: clientIp(req),
    });

    res.json({
      token: signAuthToken(user),
      user: serializeUser(user),
      merchant: serializeMerchant(merchant),
    });
  }
);

// GET /api/auth/me — restores the session after a page refresh.
router.get('/me', requireAuth, async (req: Request, res: Response) => {
  const auth = authOf(req);
  const { users, merchants } = await getCollections();
  const [user, merchant] = await Promise.all([
    users.findOne({ _id: auth.userId, merchantId: auth.merchantId }),
    merchants.findOne({ _id: auth.merchantId }),
  ]);
  if (!user || !merchant) {
    throw unauthorized('Your session is no longer valid. Please sign in again.');
  }
  res.json({ user: serializeUser(user), merchant: serializeMerchant(merchant) });
});

// POST /api/auth/logout — records the sign-out. Tokens are stateless JWTs, so
// the client discards its token; it expires on its own after 7 days.
router.post('/logout', requireAuth, async (req: Request, res: Response) => {
  const auth = authOf(req);
  await logAuditEvent({
    merchantId: auth.merchantId,
    actorType: 'USER',
    actorId: auth.userId.toHexString(),
    actorEmail: auth.email,
    action: 'USER_LOGOUT',
    entityType: 'USER',
    entityId: auth.userId.toHexString(),
    details: `User ${auth.email} signed out.`,
    ipAddress: clientIp(req),
  });
  res.json({ message: 'Signed out.' });
});

export default router;
