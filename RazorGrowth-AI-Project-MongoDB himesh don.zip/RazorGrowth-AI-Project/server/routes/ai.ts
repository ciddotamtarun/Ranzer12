import { Router, type Request, type Response } from 'express';
import { ObjectId } from 'mongodb';
import { getCollections, type Collections } from '../db/mongo.js';
import {
  INSIGHT_CATEGORIES,
  type AIInsightDoc,
  type AgentTaskDoc,
  type AgentType,
  type ApprovalDoc,
  type Currency,
  type InsightCategory,
} from '../db/models.js';
import { authOf, requireAuth } from '../middleware/auth.js';
import { clientIp, logAuditEvent } from '../middleware/audit.js';
import { notFound } from '../lib/errors.js';
import { formatMoney, fromCents } from '../lib/money.js';
import { serializeAgentTask, serializeApproval, serializeInsight, serializeProduct } from '../lib/serialize.js';
import { optionalEnum, readBody } from '../lib/validate.js';

const router = Router();
router.use(requireAuth);

const LOW_STOCK_THRESHOLD = 20;
const ABANDONED_CART_AGE_MS = 30 * 60 * 1000;

// Recovery assumptions used for the revenue-lift estimates. They are stored
// with every insight (metadata.assumptions) so the numbers are explainable.
const ASSUMPTIONS = {
  failedPaymentRecoveryRate: 0.3,
  abandonedCartRecoveryRate: 0.15,
  bundleAovUplift: 0.05,
};

// GET /api/ai/insights
router.get('/insights', async (req: Request, res: Response) => {
  const { merchantId } = authOf(req);
  const { aiInsights, transactions, products } = await getCollections();

  const [insights, failAgg, lowStock] = await Promise.all([
    aiInsights.find({ merchantId }).sort({ createdAt: -1, _id: -1 }).limit(200).toArray(),
    transactions
      .aggregate<{ count: number; cents: number }>([
        { $match: { merchantId, status: 'FAILED' } },
        { $group: { _id: null, count: { $sum: 1 }, cents: { $sum: '$amountCents' } } },
      ])
      .toArray(),
    products
      .find({ merchantId, inventory: { $lt: LOW_STOCK_THRESHOLD } })
      .sort({ inventory: 1, _id: 1 })
      .limit(3)
      .toArray(),
  ]);

  res.json({
    insights: insights.map(serializeInsight),
    liveAnalytics: {
      activeInsightsCount: insights.filter((i) => i.status === 'ACTIVE').length,
      revenueLeakageDetected: fromCents(failAgg[0]?.cents ?? 0),
      failedTransactionsCount: failAgg[0]?.count ?? 0,
      lowStockProductsCount: lowStock.length,
      lowStockItems: lowStock.map(serializeProduct),
    },
  });
});

interface MerchantSignals {
  currency: Currency;
  txCount: number;
  failedCount: number;
  failedCents: number;
  paidOrders: number;
  revenueCents: number;
  abandonedCarts: number;
  abandonedCartCents: number;
}

async function collectSignals(cols: Collections, merchantId: ObjectId): Promise<MerchantSignals> {
  const cartCutoff = new Date(Date.now() - ABANDONED_CART_AGE_MS);
  const [merchant, tx, orders, carts] = await Promise.all([
    cols.merchants.findOne({ _id: merchantId }, { projection: { currency: 1 } }),
    cols.transactions
      .aggregate<{ total: number; failed: number; failedCents: number }>([
        { $match: { merchantId } },
        {
          $group: {
            _id: null,
            total: { $sum: 1 },
            failed: { $sum: { $cond: [{ $eq: ['$status', 'FAILED'] }, 1, 0] } },
            failedCents: { $sum: { $cond: [{ $eq: ['$status', 'FAILED'] }, '$amountCents', 0] } },
          },
        },
      ])
      .toArray(),
    cols.orders
      .aggregate<{ paid: number; revenueCents: number }>([
        { $match: { merchantId, status: 'PAID' } },
        { $group: { _id: null, paid: { $sum: 1 }, revenueCents: { $sum: '$totalAmountCents' } } },
      ])
      .toArray(),
    cols.carts
      .aggregate<{ carts: number; cents: number }>([
        { $match: { merchantId, updatedAt: { $lt: cartCutoff }, 'items.0': { $exists: true } } },
        { $unwind: '$items' },
        {
          $group: {
            _id: null,
            cartIds: { $addToSet: '$_id' },
            cents: { $sum: { $multiply: ['$items.priceCents', '$items.quantity'] } },
          },
        },
        { $project: { _id: 0, carts: { $size: '$cartIds' }, cents: 1 } },
      ])
      .toArray(),
  ]);
  if (!merchant) throw notFound('Merchant not found.');

  return {
    currency: merchant.currency,
    txCount: tx[0]?.total ?? 0,
    failedCount: tx[0]?.failed ?? 0,
    failedCents: tx[0]?.failedCents ?? 0,
    paidOrders: orders[0]?.paid ?? 0,
    revenueCents: orders[0]?.revenueCents ?? 0,
    abandonedCarts: carts[0]?.carts ?? 0,
    abandonedCartCents: carts[0]?.cents ?? 0,
  };
}

interface Opportunity {
  title: string;
  category: InsightCategory;
  impactScore: number;
  summary: string;
  recommendation: string;
  liftCents: number;
  agentType: AgentType;
  agentTitle: string;
  triggerReason: string;
  proposedAction: string;
  impactMetric: string;
  basis: Record<string, number>;
}

const plural = (n: number, word: string) => `${n} ${word}${n === 1 ? '' : 's'}`;

function buildOpportunity(category: InsightCategory, s: MerchantSignals): Opportunity {
  const money = (cents: number) => formatMoney(cents, s.currency);

  if (category === 'PAYMENT_OPTIMIZATION') {
    const rate = s.txCount > 0 ? Math.round((s.failedCount / s.txCount) * 1000) / 10 : 0;
    const liftCents = Math.round(s.failedCents * ASSUMPTIONS.failedPaymentRecoveryRate);
    return {
      title: 'Autonomous Payment Cascading & Smart Retry Engine',
      category,
      impactScore: 96,
      summary:
        s.failedCount > 0
          ? `${plural(s.failedCount, 'failed payment attempt')} totalling ${money(s.failedCents)} (${rate}% of ${plural(s.txCount, 'attempt')}) are unrecovered in your transaction ledger.`
          : `No failed payments recorded yet across ${plural(s.txCount, 'payment attempt')}. A fallback routing policy protects future checkouts from gateway and 3DS timeouts.`,
      recommendation:
        'Deploy the Autonomous Payment Cascading Agent to dynamically route transactions through fallback gateways and trigger SMS verification when primary card rails fail.',
      liftCents,
      agentType: 'SMART_RETRY_OPTIMIZER',
      agentTitle: 'Autonomous Payment Routing & Retry Agent',
      triggerReason:
        s.failedCount > 0
          ? `Payment failure rate is ${rate}% (${s.failedCount}/${s.txCount} attempts).`
          : 'Proactive safeguard: no payment failure baseline yet.',
      proposedAction: 'Configure dynamic gateway cascade with instant OTP retry fallback on failed transactions.',
      impactMetric: `Projected recovery of ${money(liftCents)} (${ASSUMPTIONS.failedPaymentRecoveryRate * 100}% of failed payment value)`,
      basis: { failedCount: s.failedCount, failedAmount: fromCents(s.failedCents), attempts: s.txCount, failureRatePct: rate },
    };
  }

  if (category === 'CONVERSION_LIFT') {
    const liftCents = Math.round(s.abandonedCartCents * ASSUMPTIONS.abandonedCartRecoveryRate);
    return {
      title: 'AI Cart Abandonment & Dynamic Incentive Agent',
      category,
      impactScore: 91,
      summary:
        s.abandonedCarts > 0
          ? `${plural(s.abandonedCarts, 'storefront cart')} holding ${money(s.abandonedCartCents)} of merchandise have been idle for over 30 minutes without checkout.`
          : 'No abandoned storefront carts right now. Recovery triggers will engage automatically when carts go idle.',
      recommendation:
        'Activate Cart Recovery Agent to dispatch AI-tailored exit incentives and email triggers for high-intent abandoned carts.',
      liftCents,
      agentType: 'CART_RECOVERY_AGENT',
      agentTitle: 'AI Abandoned Cart Recovery Agent',
      triggerReason:
        s.abandonedCarts > 0
          ? `${plural(s.abandonedCarts, 'cart')} idle for 30+ minutes with ${money(s.abandonedCartCents)} in items.`
          : 'Proactive safeguard: no abandoned carts detected yet.',
      proposedAction: 'Trigger personalized 10% limited-time incentive email for checkouts abandoned past 15 minutes.',
      impactMetric: `Projected recovery of ${money(liftCents)} (${ASSUMPTIONS.abandonedCartRecoveryRate * 100}% of abandoned cart value)`,
      basis: { abandonedCarts: s.abandonedCarts, abandonedCartValue: fromCents(s.abandonedCartCents) },
    };
  }

  const aovCents = s.paidOrders > 0 ? Math.round(s.revenueCents / s.paidOrders) : 0;
  const liftCents = Math.round(s.revenueCents * ASSUMPTIONS.bundleAovUplift);
  return {
    title: 'Dynamic Bundle & Price Elasticity Optimizer',
    category: 'PRICING_ELASTICITY',
    impactScore: 87,
    summary:
      s.paidOrders > 0
        ? `Average order value is ${money(aovCents)} across ${plural(s.paidOrders, 'paid order')} (${money(s.revenueCents)} revenue). Complementary bundles at checkout can raise basket size.`
        : 'No paid orders yet, so there is no average-order-value baseline. Bundle recommendations will start from your first sales.',
    recommendation:
      'Launch Autonomous Bundle Optimizer to dynamically recommend complementary products during AI Buyer interactions.',
    liftCents,
    agentType: 'DYNAMIC_PRICING_AGENT',
    agentTitle: 'Autonomous Cross-Sell & Bundle Agent',
    triggerReason:
      s.paidOrders > 0
        ? `Average order value baseline: ${money(aovCents)} over ${plural(s.paidOrders, 'paid order')}.`
        : 'Proactive setup: no average-order-value baseline yet.',
    proposedAction: 'Inject context-aware complementary product recommendation during add-to-cart and checkout flows.',
    impactMetric: `Projected ${money(liftCents)} lift (${ASSUMPTIONS.bundleAovUplift * 100}% AOV uplift on current revenue)`,
    basis: { paidOrders: s.paidOrders, revenue: fromCents(s.revenueCents), aov: fromCents(aovCents) },
  };
}

// POST /api/ai/generate-opportunity  { focusArea?: InsightCategory }
router.post('/generate-opportunity', async (req: Request, res: Response) => {
  const auth = authOf(req);
  const body = readBody(req);
  const focusArea = optionalEnum(body.focusArea ?? undefined, 'focusArea', INSIGHT_CATEGORIES);

  const cols = await getCollections();
  const [signals, existingInsights] = await Promise.all([
    collectSignals(cols, auth.merchantId),
    cols.aiInsights.countDocuments({ merchantId: auth.merchantId }),
  ]);

  // Honour an explicit focus area; otherwise rotate through the three levers.
  const category = focusArea ?? INSIGHT_CATEGORIES[existingInsights % INSIGHT_CATEGORIES.length];
  const opp = buildOpportunity(category, signals);

  const now = new Date();
  const insightId = new ObjectId();
  const taskId = new ObjectId();

  const insight: AIInsightDoc = {
    _id: insightId,
    merchantId: auth.merchantId,
    title: opp.title,
    category: opp.category,
    impactScore: opp.impactScore,
    summary: opp.summary,
    recommendation: opp.recommendation,
    status: 'ACTIVE',
    potentialRevenueLiftCents: opp.liftCents,
    metadata: { basis: opp.basis, assumptions: ASSUMPTIONS, generatedAt: now.toISOString() },
    agentTaskId: taskId,
    createdAt: now,
    updatedAt: now,
  };
  const task: AgentTaskDoc = {
    _id: taskId,
    merchantId: auth.merchantId,
    title: opp.agentTitle,
    agentType: opp.agentType,
    status: 'PENDING_APPROVAL',
    triggerReason: opp.triggerReason,
    proposedAction: opp.proposedAction,
    executionResult: null,
    impactMetric: opp.impactMetric,
    insightId,
    createdAt: now,
    updatedAt: now,
  };
  const approval: ApprovalDoc = {
    _id: new ObjectId(),
    merchantId: auth.merchantId,
    agentTaskId: taskId,
    title: `Authorize Deployment: ${opp.agentTitle}`,
    description: `Approval needed to execute: ${opp.proposedAction} Potential revenue impact: ${opp.impactMetric}.`,
    status: 'PENDING',
    requestedBy: 'RazorGrowth AI Engine',
    resolvedBy: null,
    resolvedAt: null,
    notes: null,
    createdAt: now,
    updatedAt: now,
  };

  await cols.aiInsights.insertOne(insight);
  await cols.agentTasks.insertOne(task);
  await cols.approvals.insertOne(approval);

  await logAuditEvent({
    merchantId: auth.merchantId,
    actorType: 'AGENT',
    actorId: 'agent_ai_engine',
    actorEmail: 'system@razorgrowth.ai',
    action: 'AI_OPPORTUNITY_DISCOVERED',
    entityType: 'AI_INSIGHT',
    entityId: insightId.toHexString(),
    details: `Discovered opportunity: '${opp.title}' with projected revenue lift of ${formatMoney(opp.liftCents, signals.currency)}. Spawned Agent Task #${taskId.toHexString().slice(-10)}.`,
    ipAddress: clientIp(req),
  });

  res.status(201).json({
    insight: serializeInsight(insight),
    agentTask: serializeAgentTask(task, approval),
    approval: serializeApproval(approval, task),
  });
});

export default router;
