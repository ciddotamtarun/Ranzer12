import { Router, type Request, type Response } from 'express';
import { ObjectId } from 'mongodb';
import { getCollections } from '../db/mongo.js';
import { AGENT_TYPES, type AgentTaskDoc, type ApprovalDoc } from '../db/models.js';
import { authOf, requireAuth } from '../middleware/auth.js';
import { clientIp, logAuditEvent } from '../middleware/audit.js';
import { notFound } from '../lib/errors.js';
import { serializeAgentTask, serializeApproval } from '../lib/serialize.js';
import { enumValue, objectId, optionalString, pagination, readBody, requiredString } from '../lib/validate.js';

const router = Router();
router.use(requireAuth);

// GET /api/agents — agent tasks with their approval state (2 queries, no N+1)
router.get('/', async (req: Request, res: Response) => {
  const { merchantId } = authOf(req);
  const { limit, offset } = pagination(req, { limit: 200, max: 500 });
  const { agentTasks, approvals } = await getCollections();

  const tasks = await agentTasks.find({ merchantId }).sort({ createdAt: -1, _id: -1 }).skip(offset).limit(limit).toArray();
  const related = tasks.length
    ? await approvals.find({ merchantId, agentTaskId: { $in: tasks.map((t) => t._id) } }).toArray()
    : [];
  const approvalByTask = new Map(related.map((a) => [a.agentTaskId.toHexString(), a]));

  res.json({ agentTasks: tasks.map((t) => serializeAgentTask(t, approvalByTask.get(t._id.toHexString()))) });
});

// GET /api/agents/:id
router.get('/:id', async (req: Request, res: Response) => {
  const { merchantId } = authOf(req);
  const id = objectId(req.params.id, 'agent task id');
  const { agentTasks, approvals } = await getCollections();
  const task = await agentTasks.findOne({ _id: id, merchantId });
  if (!task) throw notFound('Agent task not found.');
  const approval = await approvals.findOne({ merchantId, agentTaskId: id });
  res.json({ agentTask: serializeAgentTask(task, approval) });
});

// POST /api/agents/run — stage a merchant-defined agent task for approval
router.post('/run', async (req: Request, res: Response) => {
  const auth = authOf(req);
  const body = readBody(req);
  const agentType = enumValue(body.agentType, 'agentType', AGENT_TYPES);
  const title = requiredString(body.title, 'title', { max: 200 });
  const proposedAction = requiredString(body.proposedAction, 'proposedAction', { max: 2_000 });
  const triggerReason = optionalString(body.triggerReason, 'triggerReason', { min: 0, max: 1_000 }) || 'Merchant initiated optimization routine.';
  const impactMetric = optionalString(body.impactMetric, 'impactMetric', { min: 0, max: 500 }) || 'Performance optimization in progress.';

  const now = new Date();
  const task: AgentTaskDoc = {
    _id: new ObjectId(),
    merchantId: auth.merchantId,
    title,
    agentType,
    status: 'PENDING_APPROVAL',
    triggerReason,
    proposedAction,
    executionResult: null,
    impactMetric,
    insightId: null,
    createdAt: now,
    updatedAt: now,
  };
  const approval: ApprovalDoc = {
    _id: new ObjectId(),
    merchantId: auth.merchantId,
    agentTaskId: task._id,
    title: `Authorize ${title}`,
    description: proposedAction,
    status: 'PENDING',
    requestedBy: auth.email,
    resolvedBy: null,
    resolvedAt: null,
    notes: null,
    createdAt: now,
    updatedAt: now,
  };

  const { agentTasks, approvals } = await getCollections();
  await agentTasks.insertOne(task);
  await approvals.insertOne(approval);

  await logAuditEvent({
    merchantId: auth.merchantId,
    actorType: 'AGENT',
    actorId: task._id.toHexString(),
    actorEmail: auth.email,
    action: 'AGENT_TASK_SCHEDULED',
    entityType: 'AGENT_TASK',
    entityId: task._id.toHexString(),
    details: `Agent Task '${title}' (${agentType}) created and awaiting human approval.`,
    ipAddress: clientIp(req),
  });

  res.status(201).json({ agentTask: serializeAgentTask(task, approval), approval: serializeApproval(approval, task) });
});

export default router;
