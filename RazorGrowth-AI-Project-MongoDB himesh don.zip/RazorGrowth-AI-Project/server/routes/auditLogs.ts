import { Router, type Request, type Response } from 'express';
import type { Filter } from 'mongodb';
import { getCollections } from '../db/mongo.js';
import type { AuditLogDoc } from '../db/models.js';
import { authOf, requireAuth } from '../middleware/auth.js';
import { badRequest } from '../lib/errors.js';
import { serializeAuditLog } from '../lib/serialize.js';
import { pagination, queryString } from '../lib/validate.js';

const router = Router();
router.use(requireAuth);

const CODE_RE = /^[A-Z_]{2,100}$/;

// GET /api/audit-logs?action=&entityType=&limit=&offset=
router.get('/', async (req: Request, res: Response) => {
  const { merchantId } = authOf(req);
  const action = queryString(req, 'action', 100);
  const entityType = queryString(req, 'entityType', 100);
  if (action && !CODE_RE.test(action)) throw badRequest('Invalid action filter.');
  if (entityType && !CODE_RE.test(entityType)) throw badRequest('Invalid entityType filter.');
  const { limit, offset } = pagination(req, { limit: 100, max: 500 });

  const filter: Filter<AuditLogDoc> = { merchantId };
  if (action) filter.action = action;
  if (entityType) filter.entityType = entityType;

  const { auditLogs } = await getCollections();
  const [docs, total] = await Promise.all([
    auditLogs.find(filter).sort({ createdAt: -1, _id: -1 }).skip(offset).limit(limit).toArray(),
    auditLogs.countDocuments(filter),
  ]);
  res.json({ auditLogs: docs.map(serializeAuditLog), pagination: { total, limit, offset } });
});

export default router;
