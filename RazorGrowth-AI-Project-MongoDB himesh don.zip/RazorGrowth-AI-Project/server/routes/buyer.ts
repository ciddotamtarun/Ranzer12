import { Router, type Request, type Response } from 'express';
import { ObjectId, type Filter } from 'mongodb';
import { getCollections } from '../db/mongo.js';
import type { ProductDoc } from '../db/models.js';
import { clientIp, logAuditEvent } from '../middleware/audit.js';
import { isDuplicateKeyError, notFound } from '../lib/errors.js';
import { formatMoney, fromCents, toCents } from '../lib/money.js';
import { rateLimit } from '../lib/rateLimit.js';
import { generateClientSecret } from '../lib/secrets.js';
import { serializeOrder, serializePayment, serializeProduct } from '../lib/serialize.js';
import {
  nullableString,
  objectId,
  objectIdArray,
  optionalMoney,
  optionalString,
  readBody,
  requiredEmail,
  requiredString,
  sessionId as parseSessionId,
} from '../lib/validate.js';
import { buildOrderItems, newOrderDoc, parseLineItems } from '../services/orders.js';
import { newPaymentDoc } from '../services/payments.js';

// Public AI Buyer storefront API (no merchant login). Every query is scoped to
// the merchantId in the request and only exposes active catalog products.
const router = Router();

const MAX_CATALOG_SCAN = 1_000;
const STOP_WORDS = new Set(['and', 'for', 'the', 'with', 'under', 'below', 'item', 'best', 'less', 'than']);

function rankProducts(products: ProductDoc[], rawQuery: string, maxPriceCents: number | null) {
  const lowerQuery = rawQuery.toLowerCase().trim();
  const tokens = lowerQuery
    .replace(/[^\w\s]/g, ' ')
    .split(/\s+/)
    .filter((t) => t.length > 2 && !STOP_WORDS.has(t) && !/^\d+$/.test(t));

  return products
    .map((p) => {
      let score = 0;
      const reasons: string[] = [];
      const title = p.title.toLowerCase();
      const desc = (p.description || '').toLowerCase();
      const cat = (p.category || '').toLowerCase();
      const inStock = p.inventory > 0;

      let matched = 0;
      for (const token of tokens) {
        if (title.includes(token)) {
          score += 25;
          matched++;
          reasons.push(`Title matches keyword "${token}"`);
        } else if (desc.includes(token)) {
          score += 15;
          matched++;
          reasons.push(`Features mention "${token}"`);
        } else if (cat.includes(token)) {
          score += 15;
          matched++;
          reasons.push(`Category matches "${token}"`);
        }
      }
      if (matched > 0) score += 20;

      if (lowerQuery && title.includes(lowerQuery)) {
        score += 40;
        reasons.push('High exact-phrase match on product title');
      }

      if (maxPriceCents !== null) {
        if (p.priceCents <= maxPriceCents) {
          score += 20;
          reasons.push(`Within budget: ${formatMoney(p.priceCents)} (under ${formatMoney(maxPriceCents)})`);
        } else {
          score -= 30;
        }
      }

      score += inStock ? 10 : -20;

      if (tokens.length === 0 && maxPriceCents === null) {
        score = 50 + (inStock ? 10 : 0);
        reasons.push('Recommended based on availability in the catalog');
      }

      return {
        ...serializeProduct(p),
        matchScore: Math.min(99, Math.max(45, score)),
        matchReason: reasons.length > 0 ? reasons.slice(0, 2).join(' • ') : 'Relevant item from merchant catalog',
        isInStock: inStock,
      };
    })
    .sort((a, b) => b.matchScore - a.matchScore || a.price - b.price);
}

// POST /api/buyer/search  { merchantId, query?, maxPrice?, category? }
router.post('/search', async (req: Request, res: Response) => {
  const body = readBody(req);
  const merchantId = objectId(body.merchantId, 'merchantId');
  const userQuery = optionalString(body.query, 'query', { min: 0, max: 200 }) ?? '';
  const category = optionalString(body.category, 'category', { min: 0, max: 100 });

  // Budget: explicit maxPrice wins, otherwise parse "under 500", "below $1000", "< 300".
  let maxPriceCents = optionalMoney(body.maxPrice, 'maxPrice') ?? null;
  const priceMatch = /(?:under|below|less than|<)\s*\$?(\d+(?:\.\d{1,2})?)/i.exec(userQuery);
  if (maxPriceCents === null && priceMatch) maxPriceCents = toCents(Number(priceMatch[1]));

  const filter: Filter<ProductDoc> = { merchantId, status: 'active' };
  if (category) filter.category = category;

  const { products } = await getCollections();
  const catalog = await products.find(filter).sort({ createdAt: -1 }).limit(MAX_CATALOG_SCAN).toArray();
  const results = rankProducts(catalog, userQuery, maxPriceCents);

  res.json({
    results,
    query: userQuery,
    totalMatches: results.length,
    extractedMaxPrice: maxPriceCents === null ? null : fromCents(maxPriceCents),
  });
});

// POST /api/buyer/compare  { merchantId, productIds: string[] (max 10) }
router.post('/compare', async (req: Request, res: Response) => {
  const body = readBody(req);
  const merchantId = objectId(body.merchantId, 'merchantId');
  const productIds = objectIdArray(body.productIds, 'productIds', { min: 1, max: 10 });

  const { products } = await getCollections();
  const docs = await products.find({ merchantId, status: 'active', _id: { $in: productIds } }).toArray();
  const order = new Map(productIds.map((id, i) => [id.toHexString(), i]));
  docs.sort((a, b) => (order.get(a._id.toHexString()) ?? 0) - (order.get(b._id.toHexString()) ?? 0));

  res.json({ products: docs.map(serializeProduct) });
});

// POST /api/buyer/checkout — validates cart against live price & inventory and creates the order.
router.post(
  '/checkout',
  rateLimit({ name: 'buyer-checkout', limit: 30, windowSeconds: 600, message: 'Too many checkout attempts. Please wait a few minutes and try again.' }),
  async (req: Request, res: Response) => {
    const body = readBody(req);
    const merchantId = objectId(body.merchantId, 'merchantId');
    const customerName = requiredString(body.customerName, 'Customer name', { max: 120 });
    const customerEmail = requiredEmail(body.customerEmail, 'Customer email');
    const customerPhone = nullableString(body.customerPhone, 'Phone', { max: 40 }) ?? null;
    const lineItems = parseLineItems(body.items, { allowCustomItems: false });
    const session = body.sessionId === undefined || body.sessionId === null || body.sessionId === ''
      ? undefined
      : parseSessionId(body.sessionId);

    const cols = await getCollections();
    const merchant = await cols.merchants.findOne({ _id: merchantId }, { projection: { currency: 1 } });
    if (!merchant) throw notFound('Merchant not found.');

    // Prices and titles come from the catalog, never from the client.
    const { items, totalCents } = await buildOrderItems(cols, merchantId, lineItems, { requireActive: true });

    const now = new Date();
    const upsertCustomer = () =>
      cols.customers.findOneAndUpdate(
        { merchantId, email: customerEmail },
        {
          $set: { updatedAt: now },
          $setOnInsert: {
            _id: new ObjectId(),
            name: customerName,
            phone: customerPhone,
            totalSpentCents: 0,
            ordersCount: 0,
            status: 'active',
            createdAt: now,
          },
        },
        { upsert: true, returnDocument: 'after' }
      );
    let customer;
    try {
      customer = await upsertCustomer();
    } catch (err) {
      // Concurrent first checkout by the same email: the retry finds the row.
      if (!isDuplicateKeyError(err)) throw err;
      customer = await upsertCustomer();
    }

    const order = newOrderDoc({
      merchantId,
      customerId: customer?._id ?? null,
      customerName,
      customerEmail,
      items,
      totalCents,
      currency: merchant.currency,
      source: 'BUYER',
    });
    await cols.orders.insertOne(order);

    const { secret, hash } = generateClientSecret();
    const payment = newPaymentDoc(order, 'card', hash);
    await cols.payments.insertOne(payment);

    if (session) {
      await cols.carts.deleteOne({ merchantId, sessionId: session });
    }

    await logAuditEvent({
      merchantId,
      actorType: 'BUYER',
      actorEmail: customerEmail,
      action: 'BUYER_CHECKOUT_COMPLETED',
      entityType: 'ORDER',
      entityId: order._id.toHexString(),
      details: `AI Buyer ${customerName} checked out Order #${order.reference} with ${items.length} item(s) for ${formatMoney(totalCents, merchant.currency)}.`,
      ipAddress: clientIp(req),
    });

    res.status(201).json({
      order: serializeOrder(order),
      // client_secret is returned exactly once; it authorises the buyer to
      // complete payment for this order via /api/payments/simulate.
      payment: { ...serializePayment(payment), client_secret: secret },
      message: 'Checkout validated and order initialized successfully.',
    });
  }
);

export default router;
