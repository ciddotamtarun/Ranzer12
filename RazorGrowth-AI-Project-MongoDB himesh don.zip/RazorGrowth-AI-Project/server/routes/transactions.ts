import { Router, type Request, type Response } from 'express';
import type { Filter } from 'mongodb';
import { getCollections } from '../db/mongo.js';
import { TRANSACTION_STATUSES, type TransactionDoc } from '../db/models.js';
import { authOf, requireAuth } from '../middleware/auth.js';
import { serializeTransaction } from '../lib/serialize.js';
import { objectId, optionalEnum, pagination, queryString } from '../lib/validate.js';

const router = Router();
router.use(requireAuth);

// GET /api/transactions?status=&orderId=&limit=&offset=
router.get('/', async (req: Request, res: Response) => {
  const { merchantId } = authOf(req);
  const status = optionalEnum(queryString(req, 'status', 20), 'status', TRANSACTION_STATUSES);
  const orderIdRaw = queryString(req, 'orderId', 24);
  const { limit, offset } = pagination(req, { limit: 200, max: 500 });

  const filter: Filter<TransactionDoc> = { merchantId };
  if (status) filter.status = status;
  if (orderIdRaw) filter.orderId = objectId(orderIdRaw, 'orderId');

  const { transactions } = await getCollections();
  const [docs, total] = await Promise.all([
    transactions.find(filter).sort({ createdAt: -1, _id: -1 }).skip(offset).limit(limit).toArray(),
    transactions.countDocuments(filter),
  ]);
  res.json({ transactions: docs.map(serializeTransaction), pagination: { total, limit, offset } });
});

export default router;
