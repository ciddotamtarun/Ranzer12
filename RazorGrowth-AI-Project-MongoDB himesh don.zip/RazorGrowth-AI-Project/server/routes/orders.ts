import { Router, type Request, type Response } from 'express';
import type { Filter } from 'mongodb';
import { getCollections } from '../db/mongo.js';
import { ORDER_STATUSES, type OrderDoc } from '../db/models.js';
import { authOf, requireAuth } from '../middleware/auth.js';
import { clientIp, logAuditEvent } from '../middleware/audit.js';
import { badRequest, conflict, notFound } from '../lib/errors.js';
import { formatMoney } from '../lib/money.js';
import { serializeOrder, serializeTransaction } from '../lib/serialize.js';
import {
  enumValue,
  escapeRegex,
  isObjectIdString,
  objectId,
  optionalEnum,
  optionalObjectId,
  pagination,
  queryString,
  readBody,
  requiredEmail,
  requiredString,
} from '../lib/validate.js';
import { buildOrderItems, newOrderDoc, parseLineItems } from '../services/orders.js';

const router = Router();
router.use(requireAuth);

// GET /api/orders?status=&search=&limit=&offset=
router.get('/', async (req: Request, res: Response) => {
  const { merchantId } = authOf(req);
  const status = optionalEnum(queryString(req, 'status', 20), 'status', ORDER_STATUSES);
  const search = queryString(req, 'search', 100);
  const { limit, offset } = pagination(req, { limit: 200, max: 500 });

  const filter: Filter<OrderDoc> = { merchantId };
  if (status) filter.status = status;
  if (search) {
    const term = search.replace(/^#/, '');
    const regex = { $regex: escapeRegex(term), $options: 'i' };
    const or: Filter<OrderDoc>[] = [{ customerName: regex }, { customerEmail: regex }, { reference: regex }];
    if (isObjectIdString(term)) or.push({ _id: objectId(term) });
    filter.$or = or;
  }

  const { orders } = await getCollections();
  const [docs, total] = await Promise.all([
    orders.find(filter).sort({ createdAt: -1, _id: -1 }).skip(offset).limit(limit).toArray(),
    orders.countDocuments(filter),
  ]);
  res.json({ orders: docs.map(serializeOrder), pagination: { total, limit, offset } });
});

// GET /api/orders/:id — order with its payment transaction history
router.get('/:id', async (req: Request, res: Response) => {
  const { merchantId } = authOf(req);
  const id = objectId(req.params.id, 'order id');
  const { orders, transactions } = await getCollections();
  const order = await orders.findOne({ _id: id, merchantId });
  if (!order) throw notFound('Order not found.');
  const txs = await transactions.find({ orderId: id, merchantId }).sort({ createdAt: -1 }).toArray();
  res.json({ order: serializeOrder(order), transactions: txs.map(serializeTransaction) });
});

// POST /api/orders — merchant-created order
router.post('/', async (req: Request, res: Response) => {
  const auth = authOf(req);
  const body = readBody(req);
  const customerName = requiredString(body.customerName, 'Customer name', { max: 120 });
  const customerEmail = requiredEmail(body.customerEmail, 'Customer email');
  const customerId = optionalObjectId(body.customerId, 'customerId');
  const lineItems = parseLineItems(body.items, { allowCustomItems: true });

  const cols = await getCollections();

  // The customer must belong to this merchant (prevents cross-tenant links).
  if (customerId && !(await cols.customers.findOne({ _id: customerId, merchantId: auth.merchantId }, { projection: { _id: 1 } }))) {
    throw notFound('Customer not found.');
  }

  const [merchant, built] = await Promise.all([
    cols.merchants.findOne({ _id: auth.merchantId }, { projection: { currency: 1 } }),
    buildOrderItems(cols, auth.merchantId, lineItems, { requireActive: false }),
  ]);
  if (!merchant) throw notFound('Merchant not found.');

  const order = newOrderDoc({
    merchantId: auth.merchantId,
    customerId: customerId ?? null,
    customerName,
    customerEmail,
    items: built.items,
    totalCents: built.totalCents,
    currency: merchant.currency,
    source: 'MERCHANT',
  });
  await cols.orders.insertOne(order);

  await logAuditEvent({
    merchantId: auth.merchantId,
    actorType: 'USER',
    actorId: auth.userId.toHexString(),
    actorEmail: auth.email,
    action: 'ORDER_CREATED',
    entityType: 'ORDER',
    entityId: order._id.toHexString(),
    details: `Order #${order.reference} created for ${customerName} (${formatMoney(order.totalAmountCents, order.currency)}).`,
    ipAddress: clientIp(req),
  });

  res.status(201).json({ order: serializeOrder(order) });
});

// PATCH /api/orders/:id — currently supports cancelling an unpaid order.
router.patch('/:id', async (req: Request, res: Response) => {
  const auth = authOf(req);
  const id = objectId(req.params.id, 'order id');
  const body = readBody(req);
  if (body.status === undefined) throw badRequest('status is required.');
  const status = enumValue(body.status, 'status', ['CANCELLED'] as const);

  const { orders } = await getCollections();
  const updated = await orders.findOneAndUpdate(
    { _id: id, merchantId: auth.merchantId, status: { $in: ['PENDING', 'FAILED'] } },
    { $set: { status, updatedAt: new Date() } },
    { returnDocument: 'after' }
  );
  if (!updated) {
    const existing = await orders.findOne({ _id: id, merchantId: auth.merchantId }, { projection: { status: 1 } });
    if (!existing) throw notFound('Order not found.');
    throw conflict(
      existing.status === 'PAID' ? 'Paid orders cannot be cancelled.' : `Order is already ${existing.status.toLowerCase()}.`
    );
  }

  await logAuditEvent({
    merchantId: auth.merchantId,
    actorType: 'USER',
    actorId: auth.userId.toHexString(),
    actorEmail: auth.email,
    action: 'ORDER_CANCELLED',
    entityType: 'ORDER',
    entityId: id.toHexString(),
    details: `Order #${updated.reference} cancelled.`,
    ipAddress: clientIp(req),
  });

  res.json({ order: serializeOrder(updated) });
});

export default router;
