import { Router, type Request, type Response } from 'express';
import { getCollections } from '../db/mongo.js';
import { authOf, requireAuth } from '../middleware/auth.js';
import { fromCents } from '../lib/money.js';
import { serializeOrder, serializeTransaction } from '../lib/serialize.js';

const router = Router();
router.use(requireAuth);

const DAY_MS = 24 * 60 * 60 * 1000;
const WEEKDAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

const round1 = (n: number) => Math.round(n * 10) / 10;

interface OrderTotals {
  gmvCents: number;
  totalOrders: number;
  revenueCents: number;
  paidOrders: number;
}
interface TxTotals {
  successCount: number;
  failureCount: number;
  failureCents: number;
}
interface InsightTotals {
  count: number;
  liftCents: number;
}
interface DayBucket {
  _id: string;
  gmvCents: number;
  revenueCents: number;
}

// GET /api/dashboard/stats  (alias: /api/dashboard/metrics)
// All figures are aggregated in MongoDB from the merchant's own documents;
// the independent queries run in parallel.
router.get(['/stats', '/metrics'], async (req: Request, res: Response) => {
  const { merchantId } = authOf(req);
  const { orders, transactions, aiInsights } = await getCollections();

  const today = new Date();
  const chartStart = new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), today.getUTCDate()) - 6 * DAY_MS);
  const isPaid = { $eq: ['$status', 'PAID'] };

  const [orderAgg, txAgg, insightAgg, dailyAgg, recentTx, recentOrders] = await Promise.all([
    orders
      .aggregate<OrderTotals>([
        { $match: { merchantId } },
        {
          $group: {
            _id: null,
            gmvCents: { $sum: '$totalAmountCents' },
            totalOrders: { $sum: 1 },
            revenueCents: { $sum: { $cond: [isPaid, '$totalAmountCents', 0] } },
            paidOrders: { $sum: { $cond: [isPaid, 1, 0] } },
          },
        },
      ])
      .toArray(),
    transactions
      .aggregate<TxTotals>([
        { $match: { merchantId } },
        {
          $group: {
            _id: null,
            successCount: { $sum: { $cond: [{ $eq: ['$status', 'SUCCESS'] }, 1, 0] } },
            failureCount: { $sum: { $cond: [{ $eq: ['$status', 'FAILED'] }, 1, 0] } },
            failureCents: { $sum: { $cond: [{ $eq: ['$status', 'FAILED'] }, '$amountCents', 0] } },
          },
        },
      ])
      .toArray(),
    aiInsights
      .aggregate<InsightTotals>([
        { $match: { merchantId, status: 'ACTIVE' } },
        { $group: { _id: null, count: { $sum: 1 }, liftCents: { $sum: '$potentialRevenueLiftCents' } } },
      ])
      .toArray(),
    orders
      .aggregate<DayBucket>([
        { $match: { merchantId, createdAt: { $gte: chartStart } } },
        {
          $group: {
            _id: { $dateToString: { format: '%Y-%m-%d', date: '$createdAt', timezone: 'UTC' } },
            gmvCents: { $sum: '$totalAmountCents' },
            revenueCents: { $sum: { $cond: [isPaid, '$totalAmountCents', 0] } },
          },
        },
      ])
      .toArray(),
    transactions.find({ merchantId }).sort({ createdAt: -1, _id: -1 }).limit(5).toArray(),
    orders.find({ merchantId }).sort({ createdAt: -1, _id: -1 }).limit(5).toArray(),
  ]);

  const o = orderAgg[0] ?? { gmvCents: 0, totalOrders: 0, revenueCents: 0, paidOrders: 0 };
  const t = txAgg[0] ?? { successCount: 0, failureCount: 0, failureCents: 0 };
  const ai = insightAgg[0] ?? { count: 0, liftCents: 0 };

  const gmv = fromCents(o.gmvCents);
  const revenue = fromCents(o.revenueCents);
  const aov = o.paidOrders > 0 ? fromCents(Math.round(o.revenueCents / o.paidOrders)) : 0;
  const attempts = t.successCount + t.failureCount;
  const paymentSuccessRate = attempts > 0 ? round1((t.successCount / attempts) * 100) : 0;
  const paymentFailureRate = attempts > 0 ? round1((t.failureCount / attempts) * 100) : 0;
  // Checkout conversion: share of created orders that were paid.
  const conversionRate = o.totalOrders > 0 ? round1((o.paidOrders / o.totalOrders) * 100) : 0;

  const byDay = new Map(dailyAgg.map((d) => [d._id, d]));
  const chartData = Array.from({ length: 7 }, (_, i) => {
    const day = new Date(chartStart.getTime() + i * DAY_MS);
    const bucket = byDay.get(day.toISOString().slice(0, 10));
    return {
      day: WEEKDAYS[day.getUTCDay()],
      date: day.toISOString().slice(0, 10),
      revenue: Math.round(fromCents(bucket?.revenueCents ?? 0)),
      gmv: Math.round(fromCents(bucket?.gmvCents ?? 0)),
    };
  });

  res.json({
    metrics: {
      gmv,
      totalGmv: gmv,
      revenue,
      orders: o.totalOrders,
      totalOrders: o.totalOrders,
      paidOrders: o.paidOrders,
      paidOrdersCount: o.paidOrders,
      aov,
      conversionRate,
      paymentSuccess: t.successCount,
      paymentSuccessCount: t.successCount,
      paymentSuccessRate,
      paymentFailure: t.failureCount,
      paymentFailureCount: t.failureCount,
      paymentFailureRate,
      failedTransactionsCount: t.failureCount,
      revenueLeakage: fromCents(t.failureCents),
      aiOpportunities: ai.count,
      aiPotentialLift: fromCents(ai.liftCents),
    },
    recentTransactions: recentTx.map(serializeTransaction),
    recentOrders: recentOrders.map(serializeOrder),
    chartData,
  });
});

export default router;
