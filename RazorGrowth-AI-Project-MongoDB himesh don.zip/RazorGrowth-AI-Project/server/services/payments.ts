import { ObjectId, type AnyBulkWriteOperation } from 'mongodb';
import type { Collections } from '../db/mongo.js';
import type { ActorType, OrderDoc, PaymentDoc, ProductDoc, TransactionDoc } from '../db/models.js';
import { conflict, isDuplicateKeyError } from '../lib/errors.js';
import { formatMoney } from '../lib/money.js';
import { gatewayReference } from '../lib/secrets.js';
import { logAuditEvent } from '../middleware/audit.js';

export interface PaymentActor {
  type: ActorType;
  id: string | null;
  email: string | null;
  ip: string;
}

export interface PaymentOutcomeResult {
  success: boolean;
  status: 'SUCCESS' | 'FAILED';
  message: string;
  order: OrderDoc;
  payment: PaymentDoc;
  transaction: TransactionDoc;
}

export function newPaymentDoc(order: OrderDoc, method: string, clientSecretHash: string | null): PaymentDoc {
  const now = new Date();
  return {
    _id: new ObjectId(),
    merchantId: order.merchantId,
    orderId: order._id,
    amountCents: order.totalAmountCents,
    currency: order.currency,
    status: 'PENDING',
    attemptCount: 0,
    method,
    errorCode: null,
    errorMessage: null,
    clientSecretHash,
    createdAt: now,
    updatedAt: now,
  };
}

function newTransactionDoc(
  order: OrderDoc,
  payment: PaymentDoc,
  status: TransactionDoc['status'],
  paymentMethod: string,
  failureReason: string | null
): TransactionDoc {
  const now = new Date();
  return {
    _id: new ObjectId(),
    merchantId: order.merchantId,
    orderId: order._id,
    paymentId: payment._id,
    amountCents: order.totalAmountCents,
    currency: order.currency,
    status,
    paymentMethod,
    gatewayReference: gatewayReference(status === 'SUCCESS' ? 'gw_succ' : 'gw_err'),
    failureReason,
    customerName: order.customerName,
    customerEmail: order.customerEmail,
    createdAt: now,
    updatedAt: now,
  };
}

/** Records a declined payment attempt. The order stays payable (retry). */
export async function recordPaymentFailure(
  cols: Collections,
  order: OrderDoc,
  payment: PaymentDoc,
  opts: { failureReason: string; paymentMethod: string; actor: PaymentActor }
): Promise<PaymentOutcomeResult> {
  const now = new Date();
  const updatedPayment = await cols.payments.findOneAndUpdate(
    { _id: payment._id, status: { $ne: 'SUCCESS' } },
    {
      $set: {
        status: 'FAILED',
        errorCode: 'GATEWAY_ERROR',
        errorMessage: opts.failureReason,
        method: opts.paymentMethod,
        updatedAt: now,
      },
      $inc: { attemptCount: 1 },
    },
    { returnDocument: 'after' }
  );
  if (!updatedPayment) throw conflict('This payment has already been completed.');

  const transaction = newTransactionDoc(order, updatedPayment, 'FAILED', opts.paymentMethod, opts.failureReason);
  await cols.transactions.insertOne(transaction);

  const updatedOrder =
    (await cols.orders.findOneAndUpdate(
      { _id: order._id, status: { $nin: ['PAID', 'CANCELLED'] } },
      { $set: { status: 'FAILED', paymentStatus: 'FAILED', updatedAt: now } },
      { returnDocument: 'after' }
    )) ?? (await cols.orders.findOne({ _id: order._id })) ?? order;

  await logAuditEvent({
    merchantId: order.merchantId,
    actorType: opts.actor.type,
    actorId: opts.actor.id,
    actorEmail: opts.actor.email,
    action: 'PAYMENT_FAILED',
    entityType: 'PAYMENT',
    entityId: payment._id.toHexString(),
    details: `Payment attempt of ${formatMoney(order.totalAmountCents, order.currency)} failed for Order #${order.reference}. Reason: ${opts.failureReason}`,
    ipAddress: opts.actor.ip,
  });

  return {
    success: false,
    status: 'FAILED',
    message: opts.failureReason,
    order: updatedOrder,
    payment: updatedPayment,
    transaction,
  };
}

/**
 * Settles an order. MongoDB multi-document transactions are not assumed (they
 * are unavailable on some deployments), so correctness comes from an atomic
 * state transition instead: exactly one request can move the order from an
 * unpaid state to PAID. Only that request applies the side effects
 * (transaction ledger entry, inventory decrement, customer lifetime value), so
 * double submissions and concurrent retries can never double-count.
 */
export async function recordPaymentSuccess(
  cols: Collections,
  order: OrderDoc,
  payment: PaymentDoc,
  opts: { paymentMethod: string; actor: PaymentActor }
): Promise<PaymentOutcomeResult> {
  const now = new Date();

  const paidOrder = await cols.orders.findOneAndUpdate(
    { _id: order._id, merchantId: order.merchantId, status: { $nin: ['PAID', 'CANCELLED'] } },
    { $set: { status: 'PAID', paymentStatus: 'PAID', paidAt: now, updatedAt: now } },
    { returnDocument: 'after' }
  );
  if (!paidOrder) throw conflict('This order has already been paid or cancelled.');

  const updatedPayment =
    (await cols.payments.findOneAndUpdate(
      { _id: payment._id },
      {
        $set: { status: 'SUCCESS', errorCode: null, errorMessage: null, method: opts.paymentMethod, updatedAt: now },
        $inc: { attemptCount: 1 },
      },
      { returnDocument: 'after' }
    )) ?? payment;

  const transaction = newTransactionDoc(paidOrder, updatedPayment, 'SUCCESS', opts.paymentMethod, null);
  await cols.transactions.insertOne(transaction);

  await decrementInventory(cols, paidOrder);
  await recordCustomerPurchase(cols, paidOrder);

  await logAuditEvent({
    merchantId: order.merchantId,
    actorType: opts.actor.type,
    actorId: opts.actor.id,
    actorEmail: opts.actor.email,
    action: 'PAYMENT_SUCCEEDED',
    entityType: 'PAYMENT',
    entityId: payment._id.toHexString(),
    details: `Payment of ${formatMoney(order.totalAmountCents, order.currency)} completed successfully via ${opts.paymentMethod} for Order #${order.reference}.`,
    ipAddress: opts.actor.ip,
  });

  return {
    success: true,
    status: 'SUCCESS',
    message: 'Payment processed and verified successfully.',
    order: paidOrder,
    payment: updatedPayment,
    transaction,
  };
}

/** Decrements stock for every catalog line, never below zero, in one round trip. */
async function decrementInventory(cols: Collections, order: OrderDoc): Promise<void> {
  const quantities = new Map<string, { id: ObjectId; qty: number }>();
  for (const item of order.items) {
    if (!item.productId) continue;
    const key = item.productId.toHexString();
    const entry = quantities.get(key) ?? { id: item.productId, qty: 0 };
    entry.qty += item.quantity;
    quantities.set(key, entry);
  }
  if (quantities.size === 0) return;

  const now = new Date();
  const operations: AnyBulkWriteOperation<ProductDoc>[] = Array.from(quantities.values()).map(({ id, qty }) => ({
    updateOne: {
      filter: { _id: id, merchantId: order.merchantId },
      update: [{ $set: { inventory: { $max: [0, { $subtract: ['$inventory', qty] }] }, updatedAt: now } }],
    },
  }));
  await cols.products.bulkWrite(operations, { ordered: false });
}

/** Adds the order to the customer's lifetime value, creating the customer if needed. */
async function recordCustomerPurchase(cols: Collections, order: OrderDoc): Promise<void> {
  const now = new Date();
  const inc = { totalSpentCents: order.totalAmountCents, ordersCount: 1 };

  if (order.customerId) {
    const result = await cols.customers.updateOne(
      { _id: order.customerId, merchantId: order.merchantId },
      { $inc: inc, $set: { updatedAt: now } }
    );
    if (result.matchedCount > 0) return;
  }

  const upsert = () =>
    cols.customers.findOneAndUpdate(
      { merchantId: order.merchantId, email: order.customerEmail },
      {
        $inc: inc,
        $set: { updatedAt: now },
        $setOnInsert: { _id: new ObjectId(), name: order.customerName, phone: null, status: 'active', createdAt: now },
      },
      { upsert: true, returnDocument: 'after' }
    );

  let customer;
  try {
    customer = await upsert();
  } catch (err) {
    // Concurrent first purchase by the same email: the retry updates instead.
    if (!isDuplicateKeyError(err)) throw err;
    customer = await upsert();
  }

  if (customer && !order.customerId) {
    await cols.orders.updateOne({ _id: order._id }, { $set: { customerId: customer._id } });
    order.customerId = customer._id;
  }
}
