import { ObjectId } from 'mongodb';
import type { Collections } from '../db/mongo.js';
import type { Currency, OrderDoc, OrderItemDoc, ProductDoc } from '../db/models.js';
import { badRequest, conflict, notFound } from '../lib/errors.js';
import { objectId, optionalInt, requiredMoney, requiredString } from '../lib/validate.js';

export const MAX_ORDER_LINES = 100;
export const MAX_LINE_QUANTITY = 10_000;

export interface LineItemInput {
  productId?: ObjectId;
  title?: string;
  priceCents?: number;
  quantity: number;
}

/**
 * Validates an `items` array from a request body. Catalog items reference a
 * productId (price and title always come from the database, never the client);
 * custom items (merchant-created orders only) carry their own title and price.
 */
export function parseLineItems(raw: unknown, opts: { allowCustomItems: boolean }): LineItemInput[] {
  if (!Array.isArray(raw) || raw.length === 0) throw badRequest('At least one order item is required.');
  if (raw.length > MAX_ORDER_LINES) throw badRequest(`An order can contain at most ${MAX_ORDER_LINES} items.`);

  return raw.map((entry: unknown, index) => {
    if (!entry || typeof entry !== 'object' || Array.isArray(entry)) {
      throw badRequest(`items[${index}] must be an object.`);
    }
    const item = entry as Record<string, unknown>;
    const quantity = optionalInt(item.quantity, `items[${index}].quantity`, { min: 1, max: MAX_LINE_QUANTITY }) ?? 1;
    const rawProductId = item.productId ?? item.id;
    if (rawProductId !== undefined && rawProductId !== null && rawProductId !== '') {
      return { productId: objectId(rawProductId, `items[${index}].productId`), quantity };
    }
    if (!opts.allowCustomItems) throw badRequest(`items[${index}].productId is required.`);
    const title = requiredString(item.title, `items[${index}].title`, { max: 200 });
    const priceCents = requiredMoney(item.price, `items[${index}].price`);
    if (priceCents <= 0) throw badRequest(`items[${index}].price must be greater than 0.`);
    return { title, priceCents, quantity };
  });
}

/**
 * Resolves line items against the merchant's catalog in a single query,
 * merges duplicate product lines, and checks combined quantities against
 * available inventory.
 */
export async function buildOrderItems(
  cols: Pick<Collections, 'products'>,
  merchantId: ObjectId,
  inputs: LineItemInput[],
  opts: { requireActive: boolean }
): Promise<{ items: OrderItemDoc[]; totalCents: number }> {
  const productIds = Array.from(
    new Map(inputs.filter((i) => i.productId).map((i) => [i.productId!.toHexString(), i.productId!])).values()
  );
  const products = productIds.length
    ? await cols.products.find({ merchantId, _id: { $in: productIds } }).toArray()
    : [];
  const byId = new Map<string, ProductDoc>(products.map((p) => [p._id.toHexString(), p]));

  const merged = new Map<string, OrderItemDoc>();
  const items: OrderItemDoc[] = [];

  for (const input of inputs) {
    if (input.productId) {
      const key = input.productId.toHexString();
      const product = byId.get(key);
      if (!product) throw notFound(`Product with ID '${key}' was not found in the catalog.`);
      if (opts.requireActive && product.status !== 'active') {
        throw conflict(`'${product.title}' is not currently available for purchase.`);
      }
      const existing = merged.get(key);
      if (existing) {
        existing.quantity += input.quantity;
        existing.subtotalCents = existing.priceCents * existing.quantity;
      } else {
        const line: OrderItemDoc = {
          productId: product._id,
          title: product.title,
          priceCents: product.priceCents,
          quantity: input.quantity,
          subtotalCents: product.priceCents * input.quantity,
          sku: product.sku,
          imageUrl: product.imageUrl,
        };
        merged.set(key, line);
        items.push(line);
      }
    } else {
      items.push({
        productId: null,
        title: input.title!,
        priceCents: input.priceCents!,
        quantity: input.quantity,
        subtotalCents: input.priceCents! * input.quantity,
        sku: null,
        imageUrl: null,
      });
    }
  }

  for (const [key, line] of merged) {
    const product = byId.get(key)!;
    if (product.inventory < line.quantity) {
      throw conflict(
        `Insufficient inventory for '${product.title}'. Requested: ${line.quantity}, Available: ${product.inventory}.`
      );
    }
  }

  return { items, totalCents: items.reduce((sum, i) => sum + i.subtotalCents, 0) };
}

export function newOrderDoc(params: {
  merchantId: ObjectId;
  customerId: ObjectId | null;
  customerName: string;
  customerEmail: string;
  items: OrderItemDoc[];
  totalCents: number;
  currency: Currency;
  source: OrderDoc['source'];
}): OrderDoc {
  const _id = new ObjectId();
  const now = new Date();
  return {
    _id,
    merchantId: params.merchantId,
    reference: orderReference(_id),
    customerId: params.customerId,
    customerName: params.customerName,
    customerEmail: params.customerEmail,
    totalAmountCents: params.totalCents,
    currency: params.currency,
    status: 'PENDING',
    paymentStatus: 'UNPAID',
    itemsCount: params.items.length,
    items: params.items,
    source: params.source,
    paidAt: null,
    createdAt: now,
    updatedAt: now,
  };
}

/** Short reference shown in the UI: the per-document-unique tail of the ObjectId. */
export function orderReference(id: ObjectId): string {
  return id.toHexString().slice(-10);
}
