import 'dotenv/config';
import { app } from './app.js';
import { closeMongoClient, getDb } from './db/mongo.js';

// Local development / traditional Node hosting entry point ONLY.
// On Vercel the app is served by api/[...path].ts and this file is never used.

const PORT = Number(process.env.PORT) || 5000;

export async function startServer(): Promise<void> {
  try {
    // Fail fast with a clear message if MongoDB is missing or unreachable.
    await getDb();
    console.log('[Database] Connected to MongoDB and verified indexes.');
  } catch (err) {
    console.error('[Startup Error] Could not connect to MongoDB:', err instanceof Error ? err.message : err);
    console.error('Check MONGODB_URI (and MONGODB_DB) in your .env file. See README "MongoDB setup".');
    process.exit(1);
  }

  const server = app.listen(PORT, () => {
    console.log(`[RazorGrowth AI] Backend server running on http://localhost:${PORT}`);
  });

  const shutdown = (signal: string) => {
    console.log(`[RazorGrowth AI] ${signal} received, shutting down...`);
    server.close(() => {
      closeMongoClient()
        .catch(() => undefined)
        .finally(() => process.exit(0));
    });
  };
  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));
}

void startServer();
