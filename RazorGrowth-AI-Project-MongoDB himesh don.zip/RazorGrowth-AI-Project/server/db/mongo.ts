import {
  MongoClient,
  MongoNetworkError,
  MongoServerSelectionError,
  MongoTopologyClosedError,
  type Collection,
  type Db,
  type MongoClientOptions,
} from 'mongodb';
import { attachDatabasePool } from '@vercel/functions';
import { DEFAULT_DB_NAME, IS_VERCEL, getMongoDbName, getMongoUri } from '../config.js';
import { ensureIndexes } from './indexes.js';
import type {
  AIInsightDoc,
  AgentTaskDoc,
  ApprovalDoc,
  AuditLogDoc,
  CartDoc,
  CustomerDoc,
  MerchantDoc,
  OrderDoc,
  PaymentDoc,
  ProductDoc,
  RateLimitDoc,
  TransactionDoc,
  UserDoc,
} from './models.js';

// ---------------------------------------------------------------------------
// Serverless-safe MongoDB connection
//
// One MongoClient (and therefore one connection pool) is created per warm
// function instance and cached on globalThis, so it is reused across
// invocations on Vercel and across hot reloads in local development. A new
// connection is NOT opened per request.
//
// If connecting fails, the cached promise is cleared so the next request
// retries instead of being stuck with a permanently rejected promise.
// ---------------------------------------------------------------------------

interface MongoCache {
  client: MongoClient | null;
  clientPromise: Promise<MongoClient> | null;
  indexesPromise: Promise<void> | null;
}

const globalWithMongo = globalThis as typeof globalThis & { __razorgrowthMongo?: MongoCache };
const cache: MongoCache = (globalWithMongo.__razorgrowthMongo ??= {
  client: null,
  clientPromise: null,
  indexesPromise: null,
});

function clientOptions(): MongoClientOptions {
  return {
    appName: 'razorgrowth-ai',
    // Serverless: every concurrent function instance has its own pool, so
    // keep pools small to stay well inside Atlas connection limits.
    maxPoolSize: IS_VERCEL ? 5 : 10,
    minPoolSize: 0,
    // Let idle sockets close so suspended instances don't hold connections;
    // attachDatabasePool() uses this to keep the function alive just long enough.
    maxIdleTimeMS: 5_000,
    // Fail fast instead of hanging until the function times out.
    serverSelectionTimeoutMS: 8_000,
    connectTimeoutMS: 10_000,
    socketTimeoutMS: 30_000,
    retryWrites: true,
    retryReads: true,
  };
}

export async function getMongoClient(): Promise<MongoClient> {
  if (cache.client) return cache.client;
  if (!cache.clientPromise) {
    const uri = getMongoUri();
    const client = new MongoClient(uri, clientOptions());
    // On Vercel (Fluid compute) this keeps the instance alive until idle pool
    // connections are released, preventing leaked connections. No-op locally.
    attachDatabasePool(client);
    cache.clientPromise = client
      .connect()
      .then((connected) => {
        cache.client = connected;
        return connected;
      })
      .catch((err: unknown) => {
        cache.clientPromise = null;
        void client.close().catch(() => undefined);
        throw err;
      });
  }
  return cache.clientPromise;
}

function resolveDbName(client: MongoClient): string {
  const fromEnv = getMongoDbName();
  if (fromEnv) return fromEnv;
  // client.db() with no argument uses the database from the URI path (if any).
  const fromUri = client.options.dbName;
  return fromUri && fromUri !== 'test' ? fromUri : DEFAULT_DB_NAME;
}

/**
 * Returns the application database. Also makes sure all indexes exist (once
 * per warm instance), so unique constraints such as users.email are always
 * enforced before the first write.
 */
export async function getDb(): Promise<Db> {
  const client = await getMongoClient();
  const db = client.db(resolveDbName(client));
  if (!cache.indexesPromise) {
    cache.indexesPromise = ensureIndexes(db).catch((err: unknown) => {
      cache.indexesPromise = null;
      throw err;
    });
  }
  await cache.indexesPromise;
  return db;
}

/** Lightweight connectivity check used by /api/health. */
export async function pingDatabase(timeoutMs = 3_000): Promise<boolean> {
  // The timeout covers connecting as well as the ping itself, so the health
  // check answers promptly even while the driver is still selecting a server.
  const attempt = (async () => {
    const client = await getMongoClient();
    await client.db(resolveDbName(client)).command({ ping: 1 });
    return true;
  })();
  attempt.catch(() => undefined);
  const timeout = new Promise<boolean>((resolve) => {
    setTimeout(() => resolve(false), timeoutMs).unref();
  });
  try {
    return await Promise.race([attempt, timeout]);
  } catch {
    return false;
  }
}

/** True for errors meaning "MongoDB is unreachable" (as opposed to a bad query). */
export function isDatabaseUnavailableError(err: unknown): boolean {
  return (
    err instanceof MongoServerSelectionError ||
    err instanceof MongoNetworkError ||
    err instanceof MongoTopologyClosedError
  );
}

/** Closes the cached client (used by scripts and graceful shutdown). */
export async function closeMongoClient(): Promise<void> {
  const client = cache.client;
  cache.client = null;
  cache.clientPromise = null;
  cache.indexesPromise = null;
  if (client) await client.close();
}

// ---------------------------------------------------------------------------
// Typed collection accessors
// ---------------------------------------------------------------------------

export const COLLECTIONS = {
  merchants: 'merchants',
  users: 'users',
  customers: 'customers',
  products: 'products',
  orders: 'orders',
  payments: 'payments',
  transactions: 'transactions',
  aiInsights: 'aiInsights',
  agentTasks: 'agentTasks',
  approvals: 'approvals',
  auditLogs: 'auditLogs',
  carts: 'carts',
  rateLimits: 'rateLimits',
} as const;

export interface Collections {
  merchants: Collection<MerchantDoc>;
  users: Collection<UserDoc>;
  customers: Collection<CustomerDoc>;
  products: Collection<ProductDoc>;
  orders: Collection<OrderDoc>;
  payments: Collection<PaymentDoc>;
  transactions: Collection<TransactionDoc>;
  aiInsights: Collection<AIInsightDoc>;
  agentTasks: Collection<AgentTaskDoc>;
  approvals: Collection<ApprovalDoc>;
  auditLogs: Collection<AuditLogDoc>;
  carts: Collection<CartDoc>;
  rateLimits: Collection<RateLimitDoc>;
}

export function collectionsFor(db: Db): Collections {
  return {
    merchants: db.collection<MerchantDoc>(COLLECTIONS.merchants),
    users: db.collection<UserDoc>(COLLECTIONS.users),
    customers: db.collection<CustomerDoc>(COLLECTIONS.customers),
    products: db.collection<ProductDoc>(COLLECTIONS.products),
    orders: db.collection<OrderDoc>(COLLECTIONS.orders),
    payments: db.collection<PaymentDoc>(COLLECTIONS.payments),
    transactions: db.collection<TransactionDoc>(COLLECTIONS.transactions),
    aiInsights: db.collection<AIInsightDoc>(COLLECTIONS.aiInsights),
    agentTasks: db.collection<AgentTaskDoc>(COLLECTIONS.agentTasks),
    approvals: db.collection<ApprovalDoc>(COLLECTIONS.approvals),
    auditLogs: db.collection<AuditLogDoc>(COLLECTIONS.auditLogs),
    carts: db.collection<CartDoc>(COLLECTIONS.carts),
    rateLimits: db.collection<RateLimitDoc>(COLLECTIONS.rateLimits),
  };
}

/** Convenience: connected, index-ready typed collections. */
export async function getCollections(): Promise<Collections> {
  return collectionsFor(await getDb());
}
