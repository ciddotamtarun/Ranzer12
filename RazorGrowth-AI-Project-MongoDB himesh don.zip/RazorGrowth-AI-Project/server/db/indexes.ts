import type { Db, IndexDescription } from 'mongodb';

// Index plan. Every query in the API is scoped by merchantId, so most indexes
// lead with it. Unique indexes enforce the integrity rules the API relies on
// (one account per email, one SKU per merchant, one customer per email per
// merchant, one cart per storefront session). createIndexes is idempotent, so
// this runs safely on every cold start (see db/mongo.ts) and via
// `npm run db:indexes`.

const CART_TTL_SECONDS = 60 * 60 * 24 * 30; // abandoned anonymous carts expire after 30 days

export const INDEXES: Record<string, IndexDescription[]> = {
  merchants: [
    { key: { slug: 1 }, name: 'uniq_slug', unique: true },
  ],
  users: [
    { key: { email: 1 }, name: 'uniq_email', unique: true },
  ],
  customers: [
    { key: { merchantId: 1, email: 1 }, name: 'uniq_merchant_email', unique: true },
    { key: { merchantId: 1, createdAt: -1 }, name: 'merchant_createdAt' },
  ],
  products: [
    { key: { merchantId: 1, sku: 1 }, name: 'uniq_merchant_sku', unique: true },
    { key: { merchantId: 1, createdAt: -1 }, name: 'merchant_createdAt' },
    { key: { merchantId: 1, category: 1 }, name: 'merchant_category' },
  ],
  orders: [
    { key: { merchantId: 1, createdAt: -1 }, name: 'merchant_createdAt' },
    { key: { merchantId: 1, status: 1, createdAt: -1 }, name: 'merchant_status_createdAt' },
    { key: { merchantId: 1, reference: 1 }, name: 'merchant_reference' },
  ],
  payments: [
    { key: { orderId: 1, createdAt: -1 }, name: 'order_createdAt' },
  ],
  transactions: [
    { key: { merchantId: 1, createdAt: -1 }, name: 'merchant_createdAt' },
    { key: { merchantId: 1, status: 1, createdAt: -1 }, name: 'merchant_status_createdAt' },
    { key: { orderId: 1, createdAt: -1 }, name: 'order_createdAt' },
  ],
  aiInsights: [
    { key: { merchantId: 1, createdAt: -1 }, name: 'merchant_createdAt' },
  ],
  agentTasks: [
    { key: { merchantId: 1, createdAt: -1 }, name: 'merchant_createdAt' },
  ],
  approvals: [
    { key: { merchantId: 1, createdAt: -1 }, name: 'merchant_createdAt' },
    { key: { agentTaskId: 1 }, name: 'uniq_agentTask', unique: true },
  ],
  auditLogs: [
    { key: { merchantId: 1, createdAt: -1 }, name: 'merchant_createdAt' },
    { key: { merchantId: 1, action: 1, createdAt: -1 }, name: 'merchant_action_createdAt' },
  ],
  carts: [
    { key: { merchantId: 1, sessionId: 1 }, name: 'uniq_merchant_session', unique: true },
    { key: { updatedAt: 1 }, name: 'ttl_updatedAt', expireAfterSeconds: CART_TTL_SECONDS },
  ],
  rateLimits: [
    { key: { expiresAt: 1 }, name: 'ttl_expiresAt', expireAfterSeconds: 0 },
  ],
};

export async function ensureIndexes(db: Db): Promise<void> {
  await Promise.all(
    Object.entries(INDEXES).map(([collection, indexes]) => db.collection(collection).createIndexes(indexes))
  );
}
