import type { ObjectId } from 'mongodb';

// MongoDB document shapes. Field names are camelCase in the database; the API
// layer (server/lib/serialize.ts) converts them to the snake_case JSON the
// frontend already consumes. Money is stored as integer cents (see lib/money.ts).

export const CURRENCIES = ['USD', 'EUR', 'GBP', 'CAD'] as const;
export type Currency = (typeof CURRENCIES)[number];

export const USER_ROLES = ['owner'] as const;
export type UserRole = (typeof USER_ROLES)[number];

export const CUSTOMER_STATUSES = ['active', 'inactive'] as const;
export type CustomerStatus = (typeof CUSTOMER_STATUSES)[number];

export const PRODUCT_STATUSES = ['active', 'archived'] as const;
export type ProductStatus = (typeof PRODUCT_STATUSES)[number];

export const ORDER_STATUSES = ['PENDING', 'PAID', 'FAILED', 'CANCELLED'] as const;
export type OrderStatus = (typeof ORDER_STATUSES)[number];

export const ORDER_PAYMENT_STATUSES = ['UNPAID', 'PAID', 'FAILED', 'REFUNDED'] as const;
export type OrderPaymentStatus = (typeof ORDER_PAYMENT_STATUSES)[number];

export const PAYMENT_STATUSES = ['PENDING', 'SUCCESS', 'FAILED'] as const;
export type PaymentStatus = (typeof PAYMENT_STATUSES)[number];

export const TRANSACTION_STATUSES = ['SUCCESS', 'FAILED', 'PENDING'] as const;
export type TransactionStatus = (typeof TRANSACTION_STATUSES)[number];

export const INSIGHT_STATUSES = ['ACTIVE', 'ACTIONED', 'DISMISSED'] as const;
export type InsightStatus = (typeof INSIGHT_STATUSES)[number];

export const INSIGHT_CATEGORIES = ['PAYMENT_OPTIMIZATION', 'CONVERSION_LIFT', 'PRICING_ELASTICITY'] as const;
export type InsightCategory = (typeof INSIGHT_CATEGORIES)[number];

export const AGENT_TYPES = [
  'SMART_RETRY_OPTIMIZER',
  'CART_RECOVERY_AGENT',
  'DYNAMIC_PRICING_AGENT',
  'CHECKOUT_FRICTION_KILLER',
] as const;
export type AgentType = (typeof AGENT_TYPES)[number];

export const AGENT_TASK_STATUSES = ['PENDING_APPROVAL', 'APPROVED', 'REJECTED', 'EXECUTING', 'COMPLETED', 'FAILED'] as const;
export type AgentTaskStatus = (typeof AGENT_TASK_STATUSES)[number];

export const APPROVAL_STATUSES = ['PENDING', 'APPROVED', 'REJECTED'] as const;
export type ApprovalStatus = (typeof APPROVAL_STATUSES)[number];

export const ACTOR_TYPES = ['USER', 'AGENT', 'SYSTEM', 'BUYER'] as const;
export type ActorType = (typeof ACTOR_TYPES)[number];

export interface MerchantDoc {
  _id: ObjectId;
  name: string;
  slug: string;
  email: string;
  currency: Currency;
  settings: Record<string, unknown>;
  createdAt: Date;
  updatedAt: Date;
}

export interface UserDoc {
  _id: ObjectId;
  merchantId: ObjectId;
  name: string;
  email: string;
  passwordHash: string;
  role: UserRole;
  lastLoginAt: Date | null;
  createdAt: Date;
  updatedAt: Date;
}

export interface CustomerDoc {
  _id: ObjectId;
  merchantId: ObjectId;
  name: string;
  email: string;
  phone: string | null;
  totalSpentCents: number;
  ordersCount: number;
  status: CustomerStatus;
  createdAt: Date;
  updatedAt: Date;
}

export interface ProductDoc {
  _id: ObjectId;
  merchantId: ObjectId;
  title: string;
  description: string;
  priceCents: number;
  compareAtPriceCents: number | null;
  category: string;
  inventory: number;
  sku: string;
  imageUrl: string;
  status: ProductStatus;
  createdAt: Date;
  updatedAt: Date;
}

export interface OrderItemDoc {
  productId: ObjectId | null;
  title: string;
  priceCents: number;
  quantity: number;
  subtotalCents: number;
  sku: string | null;
  imageUrl: string | null;
}

export interface OrderDoc {
  _id: ObjectId;
  merchantId: ObjectId;
  /** Short, human-facing order reference (last 10 hex chars of _id). */
  reference: string;
  customerId: ObjectId | null;
  customerName: string;
  customerEmail: string;
  totalAmountCents: number;
  currency: Currency;
  status: OrderStatus;
  paymentStatus: OrderPaymentStatus;
  itemsCount: number;
  items: OrderItemDoc[];
  source: 'MERCHANT' | 'BUYER';
  paidAt: Date | null;
  createdAt: Date;
  updatedAt: Date;
}

export interface PaymentDoc {
  _id: ObjectId;
  merchantId: ObjectId;
  orderId: ObjectId;
  amountCents: number;
  currency: Currency;
  status: PaymentStatus;
  attemptCount: number;
  method: string;
  errorCode: string | null;
  errorMessage: string | null;
  /** SHA-256 of the one-time client secret handed to the buyer at checkout. */
  clientSecretHash: string | null;
  createdAt: Date;
  updatedAt: Date;
}

export interface TransactionDoc {
  _id: ObjectId;
  merchantId: ObjectId;
  orderId: ObjectId;
  paymentId: ObjectId;
  amountCents: number;
  currency: Currency;
  status: TransactionStatus;
  paymentMethod: string;
  gatewayReference: string;
  failureReason: string | null;
  // Denormalised from the order so ledgers render without a join.
  customerName: string;
  customerEmail: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface AIInsightDoc {
  _id: ObjectId;
  merchantId: ObjectId;
  title: string;
  category: InsightCategory;
  impactScore: number;
  summary: string;
  recommendation: string;
  status: InsightStatus;
  potentialRevenueLiftCents: number;
  metadata: Record<string, unknown>;
  agentTaskId: ObjectId | null;
  createdAt: Date;
  updatedAt: Date;
}

export interface AgentTaskDoc {
  _id: ObjectId;
  merchantId: ObjectId;
  title: string;
  agentType: AgentType;
  status: AgentTaskStatus;
  triggerReason: string;
  proposedAction: string;
  executionResult: string | null;
  impactMetric: string | null;
  insightId: ObjectId | null;
  createdAt: Date;
  updatedAt: Date;
}

export interface ApprovalDoc {
  _id: ObjectId;
  merchantId: ObjectId;
  agentTaskId: ObjectId;
  title: string;
  description: string;
  status: ApprovalStatus;
  requestedBy: string;
  resolvedBy: string | null;
  resolvedAt: Date | null;
  notes: string | null;
  createdAt: Date;
  updatedAt: Date;
}

export interface AuditLogDoc {
  _id: ObjectId;
  merchantId: ObjectId;
  actorType: ActorType;
  actorId: string | null;
  actorEmail: string | null;
  action: string;
  entityType: string;
  entityId: string | null;
  details: string;
  ipAddress: string;
  createdAt: Date;
}

export interface CartItemDoc {
  productId: ObjectId;
  title: string;
  priceCents: number;
  imageUrl: string;
  quantity: number;
  sku: string;
}

export interface CartDoc {
  _id: ObjectId;
  merchantId: ObjectId;
  sessionId: string;
  items: CartItemDoc[];
  createdAt: Date;
  updatedAt: Date;
}

export interface RateLimitDoc {
  _id: string;
  count: number;
  expiresAt: Date;
}
