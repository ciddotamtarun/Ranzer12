// Centralised, lazily-read server configuration.
//
// Values are read from process.env at call time (not import time) so that:
//  - `dotenv` in server/index.ts can populate them before first use, and
//  - a missing variable on Vercel produces a clear JSON error on the request
//    that needs it instead of crashing the whole function at cold start.

export const IS_VERCEL = process.env.VERCEL === '1' || Boolean(process.env.VERCEL_ENV);

export function isProduction(): boolean {
  return process.env.NODE_ENV === 'production' || IS_VERCEL;
}

export class ConfigError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'ConfigError';
  }
}

export function getMongoUri(): string {
  const uri = process.env.MONGODB_URI?.trim();
  if (!uri) {
    throw new ConfigError(
      'MONGODB_URI is not set. Add your MongoDB Atlas connection string as the MONGODB_URI environment variable.'
    );
  }
  if (!uri.startsWith('mongodb://') && !uri.startsWith('mongodb+srv://')) {
    throw new ConfigError('MONGODB_URI must start with mongodb:// or mongodb+srv://');
  }
  return uri;
}

/**
 * Database name. MONGODB_DB wins; otherwise the driver uses the database in the
 * connection string path (e.g. ...mongodb.net/razorgrowth?...), and finally
 * falls back to "razorgrowth".
 */
export function getMongoDbName(): string | undefined {
  const name = process.env.MONGODB_DB?.trim();
  return name ? name : undefined;
}

export const DEFAULT_DB_NAME = 'razorgrowth';

/** Minimum JWT secret length (HS256 should use >= 256 bits of key material). */
export const MIN_JWT_SECRET_LENGTH = 32;

/**
 * Allowed browser origins for cross-origin API calls (comma-separated
 * CORS_ORIGINS). The deployed frontend calls the API on the same origin, so in
 * production this is normally empty. In development the Vite dev server origin
 * is always allowed.
 */
export function getCorsOrigins(): string[] {
  const fromEnv = (process.env.CORS_ORIGINS || '')
    .split(',')
    .map((o) => o.trim().replace(/\/+$/, ''))
    .filter(Boolean);
  if (!isProduction()) {
    fromEnv.push('http://localhost:5173', 'http://127.0.0.1:5173');
  }
  return Array.from(new Set(fromEnv));
}

export function isRateLimitEnabled(): boolean {
  return process.env.RATE_LIMIT_ENABLED !== 'false';
}
