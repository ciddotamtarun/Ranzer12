import type { NextFunction, Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import crypto from 'node:crypto';
import { ObjectId } from 'mongodb';
import { ConfigError, MIN_JWT_SECRET_LENGTH, isProduction } from '../config.js';
import { HttpError, forbidden, unauthorized } from '../lib/errors.js';
import { isObjectIdString } from '../lib/validate.js';
import { USER_ROLES, type UserRole } from '../db/models.js';

const JWT_ISSUER = 'razorgrowth-ai';
const JWT_AUDIENCE = 'razorgrowth-ai-app';
const JWT_EXPIRES_IN = '7d';

export interface AuthContext {
  userId: ObjectId;
  merchantId: ObjectId;
  email: string;
  role: UserRole;
}

declare module 'express-serve-static-core' {
  interface Request {
    auth?: AuthContext;
  }
}

// SECURITY: the signing secret always comes from the JWT_SECRET environment
// variable. It is resolved lazily so a misconfiguration yields a clear JSON
// error instead of crashing the serverless function at load. In production a
// missing/short secret is a hard error (a per-instance random secret would
// differ between serverless instances and randomly invalidate sessions).
let cachedSecret: string | null = null;

export function getJwtSecret(): string {
  if (cachedSecret) return cachedSecret;
  const fromEnv = process.env.JWT_SECRET?.trim();
  if (fromEnv && fromEnv.length >= MIN_JWT_SECRET_LENGTH) {
    cachedSecret = fromEnv;
    return cachedSecret;
  }
  if (isProduction()) {
    throw new ConfigError(
      `JWT_SECRET is not set or shorter than ${MIN_JWT_SECRET_LENGTH} characters. ` +
        'Generate one with `openssl rand -hex 48` and add it to the environment variables.'
    );
  }
  console.warn('[Security Warning] JWT_SECRET not set; using a temporary random secret for this process (development only).');
  cachedSecret = crypto.randomBytes(48).toString('hex');
  return cachedSecret;
}

export function signAuthToken(user: { _id: ObjectId; merchantId: ObjectId; email: string; role: UserRole }): string {
  return jwt.sign(
    { merchantId: user.merchantId.toHexString(), email: user.email, role: user.role },
    getJwtSecret(),
    {
      algorithm: 'HS256',
      subject: user._id.toHexString(),
      issuer: JWT_ISSUER,
      audience: JWT_AUDIENCE,
      expiresIn: JWT_EXPIRES_IN,
    }
  );
}

function verifyToken(token: string): AuthContext {
  // Resolved before the try/catch so a missing JWT_SECRET surfaces as a
  // server configuration error rather than being mistaken for a bad token.
  const secret = getJwtSecret();
  let decoded: string | jwt.JwtPayload;
  try {
    decoded = jwt.verify(token, secret, {
      algorithms: ['HS256'],
      issuer: JWT_ISSUER,
      audience: JWT_AUDIENCE,
    });
  } catch (err) {
    const expired = err instanceof jwt.TokenExpiredError;
    throw unauthorized(expired ? 'Session expired. Please sign in again.' : 'Invalid or expired token.');
  }
  if (typeof decoded === 'string') throw unauthorized('Invalid or expired token.');

  const { sub, merchantId, email, role } = decoded as jwt.JwtPayload & Record<string, unknown>;
  if (
    !isObjectIdString(sub) ||
    !isObjectIdString(merchantId) ||
    typeof email !== 'string' ||
    typeof role !== 'string' ||
    !(USER_ROLES as readonly string[]).includes(role)
  ) {
    throw unauthorized('Invalid or expired token.');
  }
  return {
    userId: new ObjectId(sub),
    merchantId: new ObjectId(merchantId),
    email,
    role: role as UserRole,
  };
}

function bearerToken(req: Request): string | null {
  const header = req.headers.authorization;
  if (!header) return null;
  const match = /^Bearer\s+(\S+)$/i.exec(header);
  return match ? match[1] : null;
}

/** Rejects the request with 401 unless it carries a valid access token. */
export function requireAuth(req: Request, _res: Response, next: NextFunction): void {
  const token = bearerToken(req);
  if (!token) {
    next(unauthorized('Authentication required. Missing Bearer token.'));
    return;
  }
  try {
    req.auth = verifyToken(token);
    next();
  } catch (err) {
    next(err);
  }
}

/**
 * Attaches the auth context when a valid token is present; anonymous requests
 * continue. A present-but-invalid token is still rejected so clients notice.
 */
export function optionalAuth(req: Request, _res: Response, next: NextFunction): void {
  const token = bearerToken(req);
  if (!token) {
    next();
    return;
  }
  try {
    req.auth = verifyToken(token);
    next();
  } catch (err) {
    next(err);
  }
}

/** Restricts a route to the given roles. Must run after requireAuth. */
export function requireRole(...roles: UserRole[]) {
  return (req: Request, _res: Response, next: NextFunction): void => {
    if (!req.auth) {
      next(unauthorized());
      return;
    }
    if (!roles.includes(req.auth.role)) {
      next(forbidden());
      return;
    }
    next();
  };
}

/** Typed accessor for routes mounted behind requireAuth. */
export function authOf(req: Request): AuthContext {
  if (!req.auth) throw new HttpError(401, 'Authentication required.');
  return req.auth;
}
