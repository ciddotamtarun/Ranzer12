import type { Request } from 'express';
import { ObjectId } from 'mongodb';
import { getCollections } from '../db/mongo.js';
import type { ActorType } from '../db/models.js';

export interface CreateAuditLogParams {
  merchantId: ObjectId;
  actorType: ActorType;
  actorId?: string | null;
  actorEmail?: string | null;
  action: string;
  entityType: string;
  entityId?: string | null;
  details: string;
  ipAddress?: string;
}

/** Best-effort client IP (Express resolves X-Forwarded-For per "trust proxy"). */
export function clientIp(req: Request): string {
  const ip = req.ip || req.socket.remoteAddress || 'unknown';
  return ip.startsWith('::ffff:') ? ip.slice(7) : ip;
}

/**
 * Appends an audit event. Audit logging must never break the business action
 * it describes, so failures are logged and swallowed.
 */
export async function logAuditEvent(params: CreateAuditLogParams): Promise<void> {
  try {
    const { auditLogs } = await getCollections();
    await auditLogs.insertOne({
      _id: new ObjectId(),
      merchantId: params.merchantId,
      actorType: params.actorType,
      actorId: params.actorId ?? null,
      actorEmail: params.actorEmail ?? null,
      action: params.action,
      entityType: params.entityType,
      entityId: params.entityId ?? null,
      details: params.details.slice(0, 2_000),
      ipAddress: params.ipAddress ?? 'unknown',
      createdAt: new Date(),
    });
  } catch (err) {
    console.error('[Audit Log] Failed to write audit event:', err instanceof Error ? err.message : err);
  }
}
